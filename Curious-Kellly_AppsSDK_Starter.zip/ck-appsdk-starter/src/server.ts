// Curious Kellly — Apps SDK / MCP starter server
// Uses Streamable HTTP transport and exposes three tools:
// 1) daily_plan_generate  2) coach_feedback  3) lesson_board
// See: https://developers.openai.com/apps-sdk/ (Apps SDK) and MCP reference.

import express from "express";
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import { z } from "zod";
import fs from "node:fs";

const app = express();
app.use(express.json({limit: "1mb"}));

// ---- Build/load the component HTML (simple inline bundle) ----
const LESSON_HTML = fs.readFileSync(new URL("../ui/lesson-board.html", import.meta.url), "utf8");

// ---- Create an MCP server per request (stateless pattern) ----
async function buildServer() {
  const server = new McpServer({ name: "curious-kellly", version: "0.1.0" });

  // Register UI resource that ChatGPT will render in an iframe.
  server.registerResource(
    "lesson-board",
    "ui://widget/lesson-board.html",
    {},
    async () => ({
      contents: [{
        uri: "ui://widget/lesson-board.html",
        mimeType: "text/html+skybridge",
        text: LESSON_HTML,
        _meta: {
          "openai/widgetDescription": "Shows today's plan and progress for Curious Kellly. Users can mark steps as done or request a new plan.",
          "openai/widgetPrefersBorder": true,
          "openai/widgetCSP": {
            connect_domains: [],
            resource_domains: []
          }
        }
      }]
    })
  );

  // Tool: generate a daily plan
  server.registerTool(
    "daily_plan_generate",
    {
      title: "Generate daily plan",
      description: "Creates Spark, Sprint, and Reflection for the day.",
      inputSchema: {
        type: "object",
        properties: {
          focus: { type: "string", description: "Skill focus, e.g., 'Spanish A1: greetings'."},
          time_minutes: { type: "number", minimum: 3, maximum: 20, description: "Available minutes."},
          level: { type: "string", enum: ["beginner","intermediate","advanced"], default: "beginner" }
        },
        required: ["focus","time_minutes"],
        additionalProperties: false
      },
      _meta: {
        "openai/outputTemplate": "ui://widget/lesson-board.html",
        "openai/toolInvocation/invoking": "Designing a plan…",
        "openai/toolInvocation/invoked": "Plan ready"
      }
    },
    async ({ focus, time_minutes, level = "beginner" }) => {
      const minutes = Math.max(3, Math.min(20, Number(time_minutes||10)));
      const spark = `Warm-up on ${focus} (${Math.min(2, minutes-1)} min)`;
      const sprint = `Practice: ${focus} (${Math.max(2, minutes-2)} min)`;
      const reflection = "1 insight + 1 question";
      return {
        content: [{ type: "text", text: `I built a ${minutes}‑minute plan on ${focus}.` }],
        structuredContent: {
          plan: {
            focus, level, minutes,
            steps: [
              {"id":"spark","title":"Spark","done":false,"detail":spark},
              {"id":"sprint","title":"Sprint","done":false,"detail":sprint},
              {"id":"reflect","title":"Reflection","done":false,"detail":reflection}
            ]
          }
        },
        _meta: { rubric: { check1: "Teach back in 20s", check2: "Apply once" } }
      };
    }
  );

  // Tool: provide feedback on text (writing) or short phonetic hint (pronunciation)
  server.registerTool(
    "coach_feedback",
    {
      title: "Coach feedback",
      description: "Returns suggestions on writing or quick pronunciation hints.",
      inputSchema: {
        type: "object",
        properties: {
          mode: { type: "string", enum: ["writing","pronunciation"], default: "writing" },
          text: { type: "string", description: "User text or phonetic attempt." }
        },
        required: ["text"],
        additionalProperties: false
      },
      _meta: {
        "openai/toolInvocation/invoking": "Reviewing…",
        "openai/toolInvocation/invoked": "Feedback ready"
      }
    },
    async ({ mode="writing", text }) => {
      if (mode === "writing") {
        const tips = [
          "Lead with the claim, then support it.",
          "Prefer concrete verbs; trim adverbs.",
          "One idea per sentence; keep it short."
        ];
        return {
          content: [{ type: "text", text: "Here are three concise writing tips based on your sample." }],
          structuredContent: { feedback: { mode, items: tips, sample: text.slice(0,180) } }
        };
      }
      // pronunciation
      return {
        content: [{ type: "text", text: "Pronunciation tip: stress the penultimate syllable; slow down on vowels." }],
        structuredContent: { feedback: { mode, ipa: "/hɛˈloʊ/", sample: text.slice(0,64) } }
      };
    }
  );

  // Tool: emit the current board without recomputing (read-only)
  server.registerTool(
    "lesson_board",
    {
      title: "Show lesson board",
      description: "Renders the current lesson board without modifying data.",
      inputSchema: { type: "object", properties: {}, additionalProperties: false },
      annotations: { readOnlyHint: true },
      _meta: {
        "openai/outputTemplate": "ui://widget/lesson-board.html",
        "openai/toolInvocation/invoking": "Opening board…",
        "openai/toolInvocation/invoked": "Board shown"
      }
    },
    async () => ({
      content: [{ type: "text", text: "Here is today’s board." }],
      structuredContent: { plan: { focus: "Warm start", minutes: 5, steps: [] } }
    })
  );

  return server;
}

// Expose Streamable HTTP endpoint at /mcp
app.all("/mcp", async (req, res) => {
  try {
    const transport = new StreamableHTTPServerTransport();
    const server = await buildServer();
    await server.connect(transport);
    await transport.handleRequest(req, res, req.body);
  } catch (err) {
    console.error(err);
    if (!res.headersSent) res.status(500).json({ jsonrpc: "2.0", error: {"code": -32603, "message":"Internal error"}, id: None });
  }
});

const PORT = process.env.PORT ? Number(process.env.PORT) : 3000;
app.listen(PORT, () => console.log(`[Curious Kellly MCP] listening on :${PORT} /mcp`));
