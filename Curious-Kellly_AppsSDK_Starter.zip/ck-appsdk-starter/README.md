# Curious Kellly — Apps SDK / MCP Starter

This is a minimal starter you can paste into your repo to expose **Curious Kellly** as a ChatGPT app via **OpenAI Apps SDK** (built on **MCP**).

## What you get
- Streamable HTTP `/mcp` endpoint (Express + `@modelcontextprotocol/sdk`)
- Three tools: `daily_plan_generate`, `coach_feedback`, `lesson_board`
- A simple **Lesson Board** widget rendered with `text/html+skybridge` and the `window.openai` bridge
- TypeScript config and scripts

## Run locally
```bash
npm i
npm run dev
# server on http://localhost:3000/mcp
```

## Connect from ChatGPT (Developer Mode)
1. In ChatGPT: **Settings → Apps & Connectors → Advanced** → enable *Developer mode*.
2. **Settings → Connectors → Create** → Name: *Curious Kellly*, URL: `https://YOUR-NGROK-DOMAIN.ngrok.app/mcp` (or any HTTPS tunnel).
3. Start a new chat → `+` → **More** → pick *Curious Kellly*.
4. Prompt: “Design a 6‑minute Spanish warm‑up.” You should see the Lesson Board component render inline.

## Where these APIs come from
- Apps SDK server & resource metadata like `openai/outputTemplate`, `text/html+skybridge`, `openai/widgetCSP`: see the official docs.  
  Docs: https://developers.openai.com/apps-sdk/build/mcp-server (metadata)  
  Reference: https://developers.openai.com/apps-sdk/reference
- Connecting from ChatGPT: https://developers.openai.com/apps-sdk/deploy/connect-chatgpt

## Notes
- This starter is **stateless** per HTTP request. For persistence, attach a DB and hydrate `structuredContent` from it.
- Keep tool outputs compact (the model reads them); put bulky UI-only data in `_meta`.
