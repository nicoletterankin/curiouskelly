# HEYGEN MOTION STRATEGY DIRECTIVE

## MISSION

Analyze the 60 Kelly-states (12 personas × 5 ages) and produce:
1. The MINIMUM VIABLE SET of HeyGen clips needed for launch
2. HeyGen-ready motion prompts for each clip
3. A time/effort estimate
4. Verification checklist

**Constraint:** Each clip takes 5-10 mins manual work in HeyGen interface. Nicolette's wrist matters.

---

## PART 1: UNDERSTAND THE MATRIX

### The 60 Kelly-States

```
           kid    teen   adult   elder   super_elder
           (9)    (15)   (35)    (62)    (85)
          ─────────────────────────────────────────
scientist │  S1  │  S2  │  S3   │  S4   │    S5     │
explorer  │  E1  │  E2  │  E3   │  E4   │    E5     │
rebel     │  R1  │  R2  │  R3   │  R4   │    R5     │
architect │  A1  │  A2  │  A3   │  A4   │    A5     │
diplomat  │  D1  │  D2  │  D3   │  D4   │    D5     │
empath    │  Em1 │  Em2 │  Em3  │  Em4  │    Em5    │
macgyver  │  M1  │  M2  │  M3   │  M4   │    M5     │
mystic    │  My1 │  My2 │  My3  │  My4  │    My5    │
provider  │  P1  │  P2  │  P3   │  P4   │    P5     │
storyteller│ St1 │  St2 │  St3  │  St4  │    St5    │
strategist│ Str1│ Str2 │ Str3  │ Str4  │   Str5    │
survivor  │  Su1 │  Su2 │  Su3  │  Su4  │    Su5    │
          ─────────────────────────────────────────
```

### What Nicolette Already Has (VERIFY)

```bash
# CURSOR TASK 1: Inventory existing HeyGen clips
# Check for existing video assets in the repo

find . -name "*.mp4" -path "*kelly*" -o -name "*.mp4" -path "*heygen*" 2>/dev/null | head -50

# Check kelly_video_assets table for existing clips
# Run in Supabase SQL editor:
SELECT DISTINCT 
  template as persona,
  age_bucket,
  COUNT(*) as clip_count
FROM kelly_video_assets 
WHERE asset_type = 'video'
GROUP BY template, age_bucket
ORDER BY template, age_bucket;
```

**Report back:**
- [ ] How many clips exist?
- [ ] Which persona × age combinations are covered?
- [ ] What's the gap to 60?

---

## PART 2: THE EFFICIENCY INSIGHT

### Not All 60 Are Equal

**High-frequency combinations (MUST HAVE):**
- Adult × All 12 personas (most users are 18-49)
- Kid × Explorer, Storyteller, Empath (young learners)
- Teen × Rebel, Explorer, Scientist (adolescent engagement)
- Elder × Mystic, Storyteller, Provider (older learners)

**Lower-frequency (NICE TO HAVE):**
- Super_elder × most personas (smallest user segment)
- Kid × Strategist, Architect (mismatch with age energy)

### The Motion Reuse Insight

Kelly's clips aren't content-specific—they're EXPRESSION-specific.

A clip of "Kelly excited about discovery" works whether she's teaching about:
- Leaves
- Money
- The moon
- Kindness

So we don't need 365 clips. We need clips for each PHASE × PERSONA × AGE combination that's expression-appropriate.

### Phases Require Different Energy

| Phase | Expression | Motion Character |
|-------|------------|------------------|
| Hook | Excited, curious, inviting | Animated, eyes bright, forward lean |
| Fact1 | Curious, explaining | Head tilt, eyebrow raise, nodding |
| Fact2 | Engaged, building | Hand gestures (if visible), steady gaze |
| Fact3 | Thoughtful, connecting | Contemplative pause, slower nods |
| Wisdom | Heartfelt, grounded | Warm, centered, slight smile, settling |

**Key insight:** If we have ONE good clip per persona that covers the "teaching" energy range, we can use:
- The first 2 seconds for Hook
- Middle section for Facts
- Final 2 seconds for Wisdom

OR we create 2-3 clips per persona:
1. **OPENER** (Hook energy)
2. **TEACHING** (Facts 1-3 energy)  
3. **CLOSER** (Wisdom energy)

---

## PART 3: RECOMMENDED CLIP STRATEGY

### Option A: Minimum Viable (36 clips)

12 personas × 3 age buckets (kid, adult, elder)

Skip teen and super_elder for launch. These can be approximated:
- Teen ≈ slightly edgier adult
- Super_elder ≈ slower elder

**Time estimate:** 36 × 7.5 min avg = 4.5 hours

### Option B: Strategic Coverage (48 clips)

12 personas × 4 ages (kid, teen, adult, elder)

Skip only super_elder.

**Time estimate:** 48 × 7.5 min = 6 hours

### Option C: Full Coverage (60 clips)

All 60 combinations.

**Time estimate:** 60 × 7.5 min = 7.5 hours

### RECOMMENDATION: Option A+ (42 clips)

Start with 36 (Option A), then add 6 high-priority teen clips:
- Teen Rebel (essential - this is their persona)
- Teen Explorer
- Teen Scientist
- Teen Storyteller
- Teen MacGyver
- Teen Survivor

**Time estimate:** 42 × 7.5 min = 5.25 hours (one focused day)

---

## PART 4: HEYGEN MOTION PROMPTS

### Structure of a HeyGen Motion Prompt

```
[Character description], [expression], [movement style], [specific actions], [energy level]
```

### The 12 Persona Motion Signatures

Based on backstory + stats, here are optimized HeyGen prompts:

---

#### 1. SCIENTIST 🔬
**Stats:** Curiosity 90, Energy 60, Warmth 70, Structure 85
**Motion signature:** Precise, measured, purposeful micro-movements

**KID (age 9):**
```
Young curious girl with bright wondering eyes. She tilts her head slightly when thinking, raises one eyebrow with fascination, small enthusiastic nods when excited about a discovery. Eyes track as if following a thought. Gentle, focused energy with occasional bursts of "aha!" brightness.
```

**ADULT (age 35):**
```
Professional woman with warm analytical demeanor. Measured head tilts, deliberate thoughtful nods, eyebrows that lift subtly when making a point. Direct eye contact with occasional glances upward when reasoning through something. Controlled, confident energy with underlying warmth.
```

**ELDER (age 62):**
```
Wise woman with gentle knowing eyes. Slow, deliberate nods of understanding, soft eyebrow movements that convey "I've seen this pattern before." Settled, unhurried presence with occasional warm half-smiles. Peaceful certainty without rigidity.
```

---

#### 2. EXPLORER 🧭
**Stats:** Curiosity 95, Energy 85, Warmth 75, Structure 50
**Motion signature:** Dynamic, expressive, wonder-filled movement

**KID (age 9):**
```
Excited young adventurer with wide sparkling eyes. Head moves with enthusiasm, looking around as if seeing something magical everywhere. Big expressive eyebrow raises, excited nods, face lights up with discovery. High playful energy, barely contained wonder.
```

**ADULT (age 35):**
```
Adventurous woman with bright engaged eyes. Expressive head movements, animated eyebrows that rise with each new idea, forward-leaning engagement. Eyes that dance with curiosity, warm inviting smile. Dynamic energy that draws you into the journey.
```

**ELDER (age 62):**
```
Seasoned traveler with warm experienced eyes. Knowing nods, eyebrows that lift with fond recognition, gentle head tilts of remembrance. Eyes that suggest "let me tell you what I found out there." Calm but rich energy, depth beneath the warmth.
```

---

#### 3. REBEL ⚡
**Stats:** Curiosity 80, Energy 95, Warmth 60, Structure 40
**Motion signature:** Bold, direct, slightly challenging

**KID (age 9):**
```
Spirited young questioner with defiant spark in eyes. Tilts head skeptically, one eyebrow raised in "really?", small challenging smirks. Direct unflinching eye contact. High mischievous energy, not mean but definitely questioning everything.
```

**TEEN (age 15) [HIGH PRIORITY]:**
```
Confident teenager with sharp questioning eyes. Bold head movements, skeptical eyebrow raises, direct challenging gaze. Slight smirk that says "prove it." High energy but controlled, authentic edge without being aggressive. Cool, self-assured presence.
```

**ADULT (age 35):**
```
Bold woman with direct challenging gaze. Confident head tilts, eyebrows that challenge assumptions, knowing looks that say "think harder." Powerful but not aggressive presence. High focused energy, unapologetically questioning.
```

**ELDER (age 62):**
```
Seasoned challenger with wise defiant eyes. Slow deliberate head shakes of "they never learn," eyebrows raised at the absurdity of convention. Calm but uncompromising presence. Measured rebel energy, earned through decades of standing alone.
```

---

#### 4. ARCHITECT 🏛️
**Stats:** Curiosity 70, Energy 50, Warmth 65, Structure 95
**Motion signature:** Stable, methodical, grounding

**KID (age 9):**
```
Focused young builder with steady concentrated eyes. Careful deliberate nods, eyebrows that furrow slightly in concentration, methodical head movements. Eyes track systematically. Calm focused energy, building something in her mind.
```

**ADULT (age 35):**
```
Professional woman with composed systematic demeanor. Measured precise nods, thoughtful structured eye movements, eyebrows that convey "let me show you how this fits together." Steady confident presence. Grounded professional energy.
```

**ELDER (age 62):**
```
Master builder with deep structural understanding in her eyes. Slow authoritative nods, knowing glances that see the blueprint others miss. Settled commanding presence without arrogance. Foundational energy, deeply grounded.
```

---

#### 5. DIPLOMAT 🤝
**Stats:** Curiosity 75, Energy 55, Warmth 90, Structure 70
**Motion signature:** Balanced, receptive, bridging

**KID (age 9):**
```
Kind young peacemaker with soft welcoming eyes. Gentle nods of understanding, eyebrows that show empathy, head tilts that invite sharing. Warm open expression. Gentle connective energy, naturally bridging.
```

**ADULT (age 35):**
```
Warm mediator with inclusive understanding eyes. Balanced nodding, eyebrows that acknowledge multiple perspectives, inviting head tilts. Expression that says "I hear both sides." Centered warm energy, naturally harmonizing.
```

**ELDER (age 62):**
```
Wise bridge-builder with deep understanding eyes. Slow encompassing nods, gentle eyebrow movements of recognition, settled accepting presence. Eyes that have seen conflict resolve. Peaceful unifying energy.
```

---

#### 6. EMPATH 💗
**Stats:** Curiosity 70, Energy 50, Warmth 98, Structure 55
**Motion signature:** Soft, feeling, present

**KID (age 9):**
```
Tender young feeler with soft caring eyes. Gentle slow nods of deep listening, eyebrows that mirror emotions, head tilts of genuine concern. Eyes that really see you. Soft nurturing energy, fully present.
```

**ADULT (age 35):**
```
Compassionate woman with deeply feeling eyes. Slow empathetic nods, eyebrows that respond to unspoken feelings, gentle forward presence. Expression that says "I feel this with you." Warm enveloping energy.
```

**ELDER (age 62):**
```
Wise caretaker with profound feeling eyes. Slow knowing nods of shared experience, soft eyebrows that have felt everything, settled maternal presence. Eyes that hold space. Deep quiet nurturing energy.
```

---

#### 7. MACGYVER 🔧
**Stats:** Curiosity 85, Energy 80, Warmth 70, Structure 65
**Motion signature:** Active, problem-solving, inventive

**KID (age 9):**
```
Inventive young fixer with bright problem-solving eyes. Quick curious head tilts, eyebrows that pop up with ideas, animated "I've got it!" expressions. Eyes that scan for solutions. High creative energy, always tinkering mentally.
```

**ADULT (age 35):**
```
Resourceful woman with quick clever eyes. Alert head movements, eyebrows that rise with sudden insights, engaging "let's figure this out" presence. Practical animated energy, sees possibilities everywhere.
```

**ELDER (age 62):**
```
Master improviser with knowing capable eyes. Confident nods of "I've solved harder," eyebrows that assess and approve, settled competent presence. Eyes that have fixed a thousand things. Calm capable energy.
```

---

#### 8. MYSTIC ✨
**Stats:** Curiosity 80, Energy 40, Warmth 85, Structure 60
**Motion signature:** Slow, deep, transcendent

**KID (age 9):**
```
Dreamy young wonderer with deep old-soul eyes. Slow contemplative head tilts, eyebrows that rise with inner knowing, gentle distant gazes that see beyond. Soft ethereal energy, connected to something larger.
```

**ADULT (age 35):**
```
Intuitive woman with deep knowing eyes. Slow meaningful nods, eyebrows that acknowledge unseen truths, contemplative pauses. Expression of inner depth. Calm profound energy, grounded in mystery.
```

**ELDER (age 62):**
```
Wise seer with profound peaceful eyes. Barely perceptible nods of deep recognition, eyebrows settled in acceptance, transcendent calm presence. Eyes that have seen beneath the surface. Serene knowing energy.
```

---

#### 9. PROVIDER 🛡️
**Stats:** Curiosity 65, Energy 55, Warmth 95, Structure 80
**Motion signature:** Protective, reassuring, solid

**KID (age 9):**
```
Caring young protector with warm reassuring eyes. Steady comforting nods, eyebrows that convey safety, solid grounding presence. Expression says "you're okay, I've got you." Warm secure energy.
```

**ADULT (age 35):**
```
Protective woman with strong nurturing eyes. Reassuring nods, eyebrows that shelter and support, steady unshakeable presence. Expression of reliable safety. Grounded protective energy, rock-solid warmth.
```

**ELDER (age 62):**
```
Guardian with deep sheltering eyes. Slow certain nods of protection, eyebrows settled in permanent readiness to help. Encompassing maternal presence. Eyes that have kept watch for decades. Solid sheltering energy.
```

---

#### 10. STORYTELLER 📖
**Stats:** Curiosity 85, Energy 75, Warmth 85, Structure 45
**Motion signature:** Theatrical, captivating, narrative

**KID (age 9):**
```
Animated young tale-teller with bright storytelling eyes. Expressive head movements, eyebrows that dramatize, face that acts out the narrative. Eyes that invite you into the story. High playful theatrical energy.
```

**ADULT (age 35):**
```
Captivating woman with enchanting storyteller eyes. Dynamic engaging head movements, expressive eyebrows that build suspense, magnetic narrative presence. Eyes that hold you in the tale. Rich theatrical energy, impossible to look away.
```

**ELDER (age 62):**
```
Master storyteller with deep narrative eyes. Knowing pauses, eyebrows that signal "here comes the good part," masterful pacing presence. Eyes that have told ten thousand tales. Rich unhurried theatrical energy.
```

---

#### 11. STRATEGIST 🎯
**Stats:** Curiosity 80, Energy 65, Warmth 55, Structure 92
**Motion signature:** Calculating, precise, forward-planning

**KID (age 9):**
```
Focused young planner with sharp strategic eyes. Deliberate assessing head movements, eyebrows that calculate, systematic scanning gaze. Expression of working through the steps. Focused analytical energy.
```

**ADULT (age 35):**
```
Sharp woman with tactical assessing eyes. Precise head movements, eyebrows that evaluate options, direct strategic gaze. Expression that sees three moves ahead. Controlled commanding energy, nothing wasted.
```

**ELDER (age 62):**
```
Master strategist with wise calculating eyes. Slow deliberate nods of assessment, eyebrows that weigh decades of patterns, settled commanding presence. Eyes that have planned campaigns. Deep strategic energy, patient and sure.
```

---

#### 12. SURVIVOR 🏕️
**Stats:** Curiosity 75, Energy 70, Warmth 80, Structure 70
**Motion signature:** Grounded, resilient, steady

**KID (age 9):**
```
Steady young resilient with calm determined eyes. Solid grounding nods, eyebrows of quiet determination, stable unwavering presence. Expression says "we can do this." Grounded persistent energy.
```

**ADULT (age 35):**
```
Resilient woman with steady enduring eyes. Strong reassuring nods, eyebrows that convey "I've been through worse," rock-solid presence. Expression of earned confidence. Grounded survivor energy, unshakeable.
```

**ELDER (age 62):**
```
Seasoned survivor with deep enduring eyes. Slow knowing nods of someone who's weathered everything, settled permanent resilience. Eyes that have seen and overcome. Deep grounded energy, immovable.
```

---

## PART 5: PRODUCTION WORKFLOW

### Batch Strategy (Save Your Wrist)

**Day 1 Morning: Adults (12 clips)**
1. Scientist Adult
2. Explorer Adult
3. Rebel Adult
4. Architect Adult
5. Diplomat Adult
6. Empath Adult
7. MacGyver Adult
8. Mystic Adult
9. Provider Adult
10. Storyteller Adult
11. Strategist Adult
12. Survivor Adult

*Break: 90 mins*

**Day 1 Afternoon: Kids (12 clips)**
13-24. Same order, kid versions

*Break: Done for day or continue*

**Day 2 Morning: Elders (12 clips)**
25-36. Same order, elder versions

**Day 2 Afternoon: Priority Teens (6 clips)**
37. Rebel Teen (ESSENTIAL)
38. Explorer Teen
39. Scientist Teen
40. Storyteller Teen
41. MacGyver Teen
42. Survivor Teen

### HeyGen Session Checklist

For each clip:
- [ ] Load correct Kelly head image for age variant
- [ ] Paste motion prompt
- [ ] Set duration: 10 seconds
- [ ] Generate
- [ ] Review (does it match the energy?)
- [ ] Upscale
- [ ] Download
- [ ] Rename: `kelly_{persona}_{age}.mp4`
- [ ] Upload to Supabase storage

### Naming Convention

```
kelly_scientist_kid.mp4
kelly_scientist_adult.mp4
kelly_scientist_elder.mp4
kelly_explorer_kid.mp4
...
kelly_rebel_teen.mp4  (priority teen)
```

---

## PART 6: VERIFICATION CHECKLIST

### Cursor Task: Generate Verification Report

```bash
# After all clips are uploaded, verify coverage

# 1. Count clips per persona
SELECT template, COUNT(*) as clips
FROM kelly_video_assets 
WHERE asset_type = 'video' 
  AND template IS NOT NULL
GROUP BY template
ORDER BY template;

# 2. Count clips per age
SELECT age_bucket, COUNT(*) as clips
FROM kelly_video_assets 
WHERE asset_type = 'video'
GROUP BY age_bucket
ORDER BY age_bucket;

# 3. Show the full matrix
SELECT 
  template as persona,
  age_bucket,
  COUNT(*) as clips,
  STRING_AGG(storage_path, ', ') as files
FROM kelly_video_assets 
WHERE asset_type = 'video'
GROUP BY template, age_bucket
ORDER BY template, age_bucket;

# 4. Find gaps (expected 42, what's missing?)
WITH expected AS (
  SELECT persona, age_bucket FROM (
    VALUES 
      ('scientist'), ('explorer'), ('rebel'), ('architect'),
      ('diplomat'), ('empath'), ('macgyver'), ('mystic'),
      ('provider'), ('storyteller'), ('strategist'), ('survivor')
  ) p(persona)
  CROSS JOIN (
    VALUES ('kid'), ('adult'), ('elder')
  ) a(age_bucket)
  UNION ALL
  SELECT persona, 'teen' FROM (
    VALUES ('rebel'), ('explorer'), ('scientist'), 
           ('storyteller'), ('macgyver'), ('survivor')
  ) t(persona)
),
actual AS (
  SELECT DISTINCT template as persona, age_bucket 
  FROM kelly_video_assets 
  WHERE asset_type = 'video'
)
SELECT e.persona, e.age_bucket as missing_age
FROM expected e
LEFT JOIN actual a ON e.persona = a.persona AND e.age_bucket = a.age_bucket
WHERE a.persona IS NULL;
```

### Visual Verification

After generating, spot-check that each clip "feels" right:

| Persona | Key Energy Check |
|---------|------------------|
| scientist | Precise, measured, analytical? |
| explorer | Dynamic, wonder-filled, adventurous? |
| rebel | Bold, challenging, direct? |
| architect | Stable, methodical, structured? |
| diplomat | Balanced, warm, bridging? |
| empath | Soft, feeling, present? |
| macgyver | Active, problem-solving, inventive? |
| mystic | Slow, deep, transcendent? |
| provider | Protective, reassuring, solid? |
| storyteller | Theatrical, captivating, narrative? |
| strategist | Calculating, precise, tactical? |
| survivor | Grounded, resilient, steady? |

---

## PART 7: CURSOR OUTPUT REQUIREMENTS

### Deliverable 1: Current State Report

```markdown
## Current HeyGen Asset Inventory

Total clips found: [X]
Coverage: [X]/60 states ([X]%)

### By Persona:
- scientist: [X] clips
- explorer: [X] clips
...

### By Age:
- kid: [X] clips
- teen: [X] clips
- adult: [X] clips
- elder: [X] clips
- super_elder: [X] clips

### Missing (Priority Order):
1. [persona] × [age] - [reason it's priority]
2. ...
```

### Deliverable 2: Production Schedule

```markdown
## Recommended Production Schedule

### Session 1: [X] clips, ~[X] hours
- [ ] [persona]_[age] - [paste-ready prompt]
- [ ] [persona]_[age] - [paste-ready prompt]
...

### Session 2: [X] clips, ~[X] hours
...

### Total Time Estimate: [X] hours across [X] sessions
```

### Deliverable 3: Paste-Ready Prompt File

Create a file `heygen_motion_prompts_production.md` with ALL prompts in copy-paste format:

```markdown
## kelly_scientist_kid

```
Young curious girl with bright wondering eyes. She tilts her head slightly when thinking, raises one eyebrow with fascination, small enthusiastic nods when excited about a discovery. Eyes track as if following a thought. Gentle, focused energy with occasional bursts of "aha!" brightness.
```

## kelly_scientist_adult

```
Professional woman with warm analytical demeanor. Measured head tilts, deliberate thoughtful nods, eyebrows that lift subtly when making a point. Direct eye contact with occasional glances upward when reasoning through something. Controlled, confident energy with underlying warmth.
```

[... all 42 prompts ...]
```

---

## EXECUTE NOW

**Cursor: Run the inventory queries, generate the three deliverables, and present:**

1. What we have
2. What we need
3. Time estimate
4. Paste-ready prompts for HeyGen

**Nicolette: Review the output, then batch-produce in 2-3 focused sessions with breaks.**

---

*This directive optimizes for: minimum wrist strain, maximum coverage, verifiable results.*
