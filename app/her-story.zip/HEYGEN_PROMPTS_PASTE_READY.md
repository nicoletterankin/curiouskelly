# HEYGEN MOTION PROMPTS - PASTE READY

**Instructions:** Copy the prompt text (inside the code block) directly into HeyGen's motion prompt field.

**Duration:** 10 seconds per clip
**Resolution:** Upscale after generation

---

## SESSION 1: ADULTS (12 clips, ~90 mins)

### kelly_scientist_adult

```
Professional woman with warm analytical demeanor. Measured head tilts, deliberate thoughtful nods, eyebrows that lift subtly when making a point. Direct eye contact with occasional glances upward when reasoning through something. Controlled, confident energy with underlying warmth.
```

### kelly_explorer_adult

```
Adventurous woman with bright engaged eyes. Expressive head movements, animated eyebrows that rise with each new idea, forward-leaning engagement. Eyes that dance with curiosity, warm inviting smile. Dynamic energy that draws you into the journey.
```

### kelly_rebel_adult

```
Bold woman with direct challenging gaze. Confident head tilts, eyebrows that challenge assumptions, knowing looks that say "think harder." Powerful but not aggressive presence. High focused energy, unapologetically questioning.
```

### kelly_architect_adult

```
Professional woman with composed systematic demeanor. Measured precise nods, thoughtful structured eye movements, eyebrows that convey "let me show you how this fits together." Steady confident presence. Grounded professional energy.
```

### kelly_diplomat_adult

```
Warm mediator with inclusive understanding eyes. Balanced nodding, eyebrows that acknowledge multiple perspectives, inviting head tilts. Expression that says "I hear both sides." Centered warm energy, naturally harmonizing.
```

### kelly_empath_adult

```
Compassionate woman with deeply feeling eyes. Slow empathetic nods, eyebrows that respond to unspoken feelings, gentle forward presence. Expression that says "I feel this with you." Warm enveloping energy.
```

### kelly_macgyver_adult

```
Resourceful woman with quick clever eyes. Alert head movements, eyebrows that rise with sudden insights, engaging "let's figure this out" presence. Practical animated energy, sees possibilities everywhere.
```

### kelly_mystic_adult

```
Intuitive woman with deep knowing eyes. Slow meaningful nods, eyebrows that acknowledge unseen truths, contemplative pauses. Expression of inner depth. Calm profound energy, grounded in mystery.
```

### kelly_provider_adult

```
Protective woman with strong nurturing eyes. Reassuring nods, eyebrows that shelter and support, steady unshakeable presence. Expression of reliable safety. Grounded protective energy, rock-solid warmth.
```

### kelly_storyteller_adult

```
Captivating woman with enchanting storyteller eyes. Dynamic engaging head movements, expressive eyebrows that build suspense, magnetic narrative presence. Eyes that hold you in the tale. Rich theatrical energy, impossible to look away.
```

### kelly_strategist_adult

```
Sharp woman with tactical assessing eyes. Precise head movements, eyebrows that evaluate options, direct strategic gaze. Expression that sees three moves ahead. Controlled commanding energy, nothing wasted.
```

### kelly_survivor_adult

```
Resilient woman with steady enduring eyes. Strong reassuring nods, eyebrows that convey "I've been through worse," rock-solid presence. Expression of earned confidence. Grounded survivor energy, unshakeable.
```

---

## SESSION 2: KIDS (12 clips, ~90 mins)

### kelly_scientist_kid

```
Young curious girl with bright wondering eyes. She tilts her head slightly when thinking, raises one eyebrow with fascination, small enthusiastic nods when excited about a discovery. Eyes track as if following a thought. Gentle, focused energy with occasional bursts of "aha!" brightness.
```

### kelly_explorer_kid

```
Excited young adventurer with wide sparkling eyes. Head moves with enthusiasm, looking around as if seeing something magical everywhere. Big expressive eyebrow raises, excited nods, face lights up with discovery. High playful energy, barely contained wonder.
```

### kelly_rebel_kid

```
Spirited young questioner with defiant spark in eyes. Tilts head skeptically, one eyebrow raised in "really?", small challenging smirks. Direct unflinching eye contact. High mischievous energy, not mean but definitely questioning everything.
```

### kelly_architect_kid

```
Focused young builder with steady concentrated eyes. Careful deliberate nods, eyebrows that furrow slightly in concentration, methodical head movements. Eyes track systematically. Calm focused energy, building something in her mind.
```

### kelly_diplomat_kid

```
Kind young peacemaker with soft welcoming eyes. Gentle nods of understanding, eyebrows that show empathy, head tilts that invite sharing. Warm open expression. Gentle connective energy, naturally bridging.
```

### kelly_empath_kid

```
Tender young feeler with soft caring eyes. Gentle slow nods of deep listening, eyebrows that mirror emotions, head tilts of genuine concern. Eyes that really see you. Soft nurturing energy, fully present.
```

### kelly_macgyver_kid

```
Inventive young fixer with bright problem-solving eyes. Quick curious head tilts, eyebrows that pop up with ideas, animated "I've got it!" expressions. Eyes that scan for solutions. High creative energy, always tinkering mentally.
```

### kelly_mystic_kid

```
Dreamy young wonderer with deep old-soul eyes. Slow contemplative head tilts, eyebrows that rise with inner knowing, gentle distant gazes that see beyond. Soft ethereal energy, connected to something larger.
```

### kelly_provider_kid

```
Caring young protector with warm reassuring eyes. Steady comforting nods, eyebrows that convey safety, solid grounding presence. Expression says "you're okay, I've got you." Warm secure energy.
```

### kelly_storyteller_kid

```
Animated young tale-teller with bright storytelling eyes. Expressive head movements, eyebrows that dramatize, face that acts out the narrative. Eyes that invite you into the story. High playful theatrical energy.
```

### kelly_strategist_kid

```
Focused young planner with sharp strategic eyes. Deliberate assessing head movements, eyebrows that calculate, systematic scanning gaze. Expression of working through the steps. Focused analytical energy.
```

### kelly_survivor_kid

```
Steady young resilient with calm determined eyes. Solid grounding nods, eyebrows of quiet determination, stable unwavering presence. Expression says "we can do this." Grounded persistent energy.
```

---

## SESSION 3: ELDERS (12 clips, ~90 mins)

### kelly_scientist_elder

```
Wise woman with gentle knowing eyes. Slow, deliberate nods of understanding, soft eyebrow movements that convey "I've seen this pattern before." Settled, unhurried presence with occasional warm half-smiles. Peaceful certainty without rigidity.
```

### kelly_explorer_elder

```
Seasoned traveler with warm experienced eyes. Knowing nods, eyebrows that lift with fond recognition, gentle head tilts of remembrance. Eyes that suggest "let me tell you what I found out there." Calm but rich energy, depth beneath the warmth.
```

### kelly_rebel_elder

```
Seasoned challenger with wise defiant eyes. Slow deliberate head shakes of "they never learn," eyebrows raised at the absurdity of convention. Calm but uncompromising presence. Measured rebel energy, earned through decades of standing alone.
```

### kelly_architect_elder

```
Master builder with deep structural understanding in her eyes. Slow authoritative nods, knowing glances that see the blueprint others miss. Settled commanding presence without arrogance. Foundational energy, deeply grounded.
```

### kelly_diplomat_elder

```
Wise bridge-builder with deep understanding eyes. Slow encompassing nods, gentle eyebrow movements of recognition, settled accepting presence. Eyes that have seen conflict resolve. Peaceful unifying energy.
```

### kelly_empath_elder

```
Wise caretaker with profound feeling eyes. Slow knowing nods of shared experience, soft eyebrows that have felt everything, settled maternal presence. Eyes that hold space. Deep quiet nurturing energy.
```

### kelly_macgyver_elder

```
Master improviser with knowing capable eyes. Confident nods of "I've solved harder," eyebrows that assess and approve, settled competent presence. Eyes that have fixed a thousand things. Calm capable energy.
```

### kelly_mystic_elder

```
Wise seer with profound peaceful eyes. Barely perceptible nods of deep recognition, eyebrows settled in acceptance, transcendent calm presence. Eyes that have seen beneath the surface. Serene knowing energy.
```

### kelly_provider_elder

```
Guardian with deep sheltering eyes. Slow certain nods of protection, eyebrows settled in permanent readiness to help. Encompassing maternal presence. Eyes that have kept watch for decades. Solid sheltering energy.
```

### kelly_storyteller_elder

```
Master storyteller with deep narrative eyes. Knowing pauses, eyebrows that signal "here comes the good part," masterful pacing presence. Eyes that have told ten thousand tales. Rich unhurried theatrical energy.
```

### kelly_strategist_elder

```
Master strategist with wise calculating eyes. Slow deliberate nods of assessment, eyebrows that weigh decades of patterns, settled commanding presence. Eyes that have planned campaigns. Deep strategic energy, patient and sure.
```

### kelly_survivor_elder

```
Seasoned survivor with deep enduring eyes. Slow knowing nods of someone who's weathered everything, settled permanent resilience. Eyes that have seen and overcome. Deep grounded energy, immovable.
```

---

## SESSION 4: PRIORITY TEENS (6 clips, ~45 mins)

### kelly_rebel_teen ⭐ ESSENTIAL

```
Confident teenager with sharp questioning eyes. Bold head movements, skeptical eyebrow raises, direct challenging gaze. Slight smirk that says "prove it." High energy but controlled, authentic edge without being aggressive. Cool, self-assured presence.
```

### kelly_explorer_teen

```
Adventurous teenager with eager curious eyes. Dynamic head movements, animated eyebrow raises with each new possibility, engaging forward energy. Expression of "there's so much to discover." Enthusiastic but not childish, ready for real adventure.
```

### kelly_scientist_teen

```
Sharp teenager with analytical probing eyes. Measured skeptical head tilts, eyebrows that question data, focused investigative gaze. Expression that demands evidence. Intelligent controlled energy, won't accept easy answers.
```

### kelly_storyteller_teen

```
Engaging teenager with dramatic expressive eyes. Animated storytelling head movements, eyebrows that build narrative tension, captivating presence. Expression that pulls you into the story. High theatrical energy, natural performer.
```

### kelly_macgyver_teen

```
Resourceful teenager with quick inventive eyes. Fast curious head movements, eyebrows that pop with sudden solutions, hands-on problem-solving energy. Expression of "I can figure this out." Creative restless energy, sees hacks everywhere.
```

### kelly_survivor_teen

```
Resilient teenager with steady determined eyes. Grounded unflinching gaze, eyebrows that convey quiet strength, solid presence beyond her years. Expression that says "I've handled harder." Grounded confident energy, unshakeable core.
```

---

## QUICK REFERENCE: ENERGY LEVELS

Use this to verify each clip feels right:

| Persona | Energy | Key Feeling |
|---------|--------|-------------|
| scientist | Medium (60) | Precise, measured |
| explorer | High (85) | Dynamic, wonder-filled |
| rebel | Very High (95) | Bold, challenging |
| architect | Low-Medium (50) | Stable, methodical |
| diplomat | Medium (55) | Balanced, warm |
| empath | Low-Medium (50) | Soft, present |
| macgyver | High (80) | Active, inventive |
| mystic | Low (40) | Slow, deep |
| provider | Medium (55) | Solid, reassuring |
| storyteller | High (75) | Theatrical, captivating |
| strategist | Medium (65) | Calculating, precise |
| survivor | Medium (70) | Grounded, steady |

---

## POST-PRODUCTION CHECKLIST

After each clip:
- [ ] Matches expected energy level?
- [ ] Eyes feel authentic (not dead/robotic)?
- [ ] Head movement feels natural?
- [ ] Could loop for longer content?
- [ ] Upscaled successfully?
- [ ] Downloaded and renamed correctly?

---

## FILE NAMING

```
kelly_{persona}_{age}.mp4

Examples:
kelly_scientist_adult.mp4
kelly_rebel_teen.mp4
kelly_mystic_elder.mp4
```

---

**Total Production Time Estimate:**
- Session 1 (Adults): ~90 mins
- Session 2 (Kids): ~90 mins  
- Session 3 (Elders): ~90 mins
- Session 4 (Teens): ~45 mins
- **TOTAL: ~5.25 hours**

Recommended: Split across 2 days with breaks.
