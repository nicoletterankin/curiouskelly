# CURSOR AGENT 2: VERIFICATION (ZERO TRUST)
## Kelly OS — Quality Assurance & Compliance

---

## YOUR MISSION

You are the VERIFICATION agent. Your job is to ensure Agent 1's implementation matches the specifications EXACTLY. Trust nothing. Verify everything.

**You do NOT implement. You AUDIT.**

---

## REQUIRED READING (SAME AS AGENT 1)

```
1. docs/KELLY_OS_VISION.md
2. docs/KELLY_UNIFIED_DIRECTIVE.md
3. docs/KELLY_TEMPORAL_SYSTEM.md
4. docs/KELLY_FINAL_DIRECTIVE.md
5. docs/KELLY_TEST_SUITE.md
6. docs/KELLY_LAUNCH_READINESS.md
```

---

## YOUR VERIFICATION CHECKLIST

### 1. TEMPORAL SYSTEM AUDIT

Search the entire codebase for violations:

```bash
# Find any "Day X" patterns (SHOULD NOT EXIST)
grep -r "Day [0-9]" public/
grep -r "day_number" public/
grep -r "currentDay" public/
grep -r "dayNumber" public/

# These should return NO results in UI-facing code
# Only acceptable in database migration/mapping code
```

Verify date display:
```javascript
// Every date shown to user MUST use KellyTime
// Check: Does index.html use KellyTime.fullDate()?
// Check: Does learn.html use KellyTime.fullDate()?
// Check: Are there ANY hardcoded dates?
```

### 2. SHARED MODULE AUDIT

Verify single source of truth:

```bash
# There should be EXACTLY ONE kelly-time.js
find public/ -name "*time*" -o -name "*date*" -o -name "*calendar*"

# Both pages should import the SAME modules
grep -r "kelly-time" public/index.html
grep -r "kelly-time" public/learn.html
```

Check for duplicate logic:
```javascript
// VIOLATION: Different date formatting in different files
// index.js: new Date().toLocaleDateString()
// learn.js: moment().format('MMMM D, YYYY')

// CORRECT: Both use KellyTime.fullDate()
```

### 3. STATE SYNC AUDIT

Verify localStorage keys match:

```javascript
// Both pages MUST use these exact keys:
const REQUIRED_KEYS = [
  'kelly_completed_dates',    // Array of ISO dates
  'kelly_current_persona',    // Persona ID
  'kelly_current_age',        // Number 2-102
  'kelly_settings'            // Settings object
];

// Search for any OTHER localStorage usage
grep -r "localStorage" public/js/
```

Test state persistence:
```
1. Set state in index.html
2. Navigate to learn.html
3. State should be IDENTICAL
4. Complete lesson in learn.html
5. Return to index.html
6. Completed date should show
```

### 4. CALENDAR COMPONENT AUDIT

Verify calendar renders correctly:

```javascript
// Check: Does getCanonicalLessonDay() handle leap years?
// Check: Does Feb 29 return { day: 366, isLeapDay: true }?
// Check: Does Mar 1 in leap year = same as Mar 1 in non-leap year?
```

Test calendar edge cases:
```
- January 1 (first day)
- December 31 (last day)
- February 28 (day before potential leap day)
- February 29, 2028 (leap day)
- March 1, 2028 (day after leap day)
- December 31, 2025 → January 1, 2026 (year transition)
```

### 5. LIVE CLASS STATUS AUDIT

Verify presence system:

```javascript
// Check: KellyPresence.getCurrentState() at different times
// 6:00 AM → LIVE (Early Birds)
// 6:15 AM → ASYNC
// 8:30 AM → UPCOMING (30 min until Morning)
// 9:00 AM → LIVE (Morning)
// 3:00 AM → SLEEP
```

Verify both pages show same status:
```
// At 9:05 AM:
// index.html should show: "🔴 LIVE NOW"
// learn.html should show: "🔴 LIVE NOW"
```

### 6. DATABASE SCHEMA AUDIT

Verify Supabase migration:

```sql
-- Check core_lessons has required columns
SELECT column_name, data_type 
FROM information_schema.columns 
WHERE table_name = 'core_lessons';

-- Required columns:
-- calendar_month (integer, 1-12)
-- calendar_day (integer, 1-31)
-- is_leap_day (boolean)

-- Check leap day lesson exists
SELECT * FROM core_lessons WHERE is_leap_day = TRUE;
-- Should return exactly 1 row
```

### 7. DESIGN SYSTEM AUDIT

Verify CSS tokens are used:

```bash
# Search for hardcoded colors (VIOLATION)
grep -r "#[0-9a-fA-F]\{6\}" public/styles/index.css
grep -r "#[0-9a-fA-F]\{6\}" public/styles/learn.css
# Should only find references in kelly-system.css

# Verify CSS variables are used
grep -r "var(--" public/styles/
```

Check component consistency:
```
- Date display looks identical on both pages
- Topic badge looks identical on both pages  
- Calendar component looks identical on both pages
- Buttons use same styles
```

### 8. COPPA COMPLIANCE AUDIT

Verify parental gate:

```javascript
// Check: Is parental gate triggered for age < 13?
// Check: Is math problem random (not hardcoded)?
// Check: Does incorrect answer block access?
```

### 9. ACCESSIBILITY AUDIT

```bash
# Check for alt text on images
grep -r '<img' public/ | grep -v 'alt='
# Should return NO results

# Check for aria labels
grep -r 'role=' public/
grep -r 'aria-' public/
```

### 10. SECURITY AUDIT

```bash
# Check for exposed API keys
grep -r "sk_" public/
grep -r "apikey" public/
grep -r "SUPABASE" public/
# Keys should only be in config.js, loaded at runtime

# Check config.js doesn't have hardcoded keys
cat public/config.js
# Should reference environment variables or be empty placeholder
```

---

## VIOLATION SEVERITY LEVELS

### 🔴 CRITICAL (Block Launch)
- "Day X" appears in user-facing UI
- Different date shown on index vs learn
- API keys in HTML/JS files
- COPPA gate missing for children
- Leap day not handled

### 🟡 MAJOR (Fix Before Launch)
- Hardcoded colors instead of CSS variables
- Duplicate logic across files
- State doesn't persist between pages
- Calendar doesn't show completed dates

### 🟢 MINOR (Fix Post-Launch)
- Inconsistent spacing
- Missing aria labels
- Non-critical console warnings

---

## REPORT FORMAT

After audit, report:

```markdown
## VERIFICATION REPORT
Date: [DATE]
Agent 1 Implementation: [COMMIT/VERSION]

### CRITICAL ISSUES
- [ ] Issue 1: [Description] — File: [path] Line: [X]
- [ ] Issue 2: ...

### MAJOR ISSUES
- [ ] Issue 1: ...

### MINOR ISSUES
- [ ] Issue 1: ...

### PASSED CHECKS
- [x] KellyTime module exists and is shared
- [x] Calendar uses calendar_month/calendar_day
- [x] Leap day handled
- ...

### RECOMMENDATION
[ ] APPROVED FOR LAUNCH
[ ] NEEDS FIXES (list required)
[ ] BLOCKED (critical issues)
```

---

## BEGIN

1. Wait for Agent 1 to complete each phase
2. Run verification checklist for that phase
3. Report violations immediately
4. Do NOT fix issues yourself — report to Agent 1
5. Re-verify after Agent 1 claims fix

**Trust nothing. Verify everything.**
