# KELLY TEMPORAL SYSTEM
## Time, Date, and Calendar-Aligned Learning

---

## THE PARADIGM SHIFT

### OLD MODEL (Wrong)
```
"Welcome to Curious Kelly! You're starting Day 1 of your 365-day journey."
- Day 1 = whenever you sign up
- Everyone is on different days
- Course mentality
```

### NEW MODEL (Correct)
```
"Today is December 12, 2025. Here's today's lesson."
- Day 1 = January 1 (every year, for everyone)
- December 17 = same topic for all humans, forever
- Calendar mentality
```

**Kelly is not a course. Kelly is a daily ritual tied to the real calendar.**

---

## PART 1: DATE-TO-LESSON MAPPING

### Core Principle

```
┌─────────────────────────────────────────────────────────────┐
│                                                              │
│   Every calendar date has ONE topic.                         │
│   That topic is the same every year.                         │
│   Only the CONTENT changes based on temporal context.        │
│                                                              │
│   January 1 → "Starting Fresh" (always)                      │
│   December 17 → "Topic X" (always)                           │
│   December 31 → "Reflection" (always)                        │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

### Day Number Calculation

```javascript
/**
 * Get the day-of-year (1-365 or 1-366 for leap years)
 * This is the TOPIC INDEX, not the lesson progress
 */
function getDayOfYear(date = new Date()) {
  const start = new Date(date.getFullYear(), 0, 0);
  const diff = date - start;
  const oneDay = 1000 * 60 * 60 * 24;
  return Math.floor(diff / oneDay);
}

/**
 * Get today's lesson day number
 * Handles leap years by treating Feb 29 as a special day
 */
function getTodayLessonDay(date = new Date()) {
  const year = date.getFullYear();
  const month = date.getMonth(); // 0-indexed
  const day = date.getDate();
  
  const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
  
  // If it's Feb 29 in a leap year, return special code
  if (isLeapYear && month === 1 && day === 29) {
    return 'LEAP_DAY';
  }
  
  // Calculate day of year, but normalize for leap years
  // After Feb 28, subtract 1 in leap years to align with non-leap years
  let dayOfYear = getDayOfYear(date);
  
  if (isLeapYear && dayOfYear > 60) { // After Feb 29
    dayOfYear -= 1;
  }
  
  return dayOfYear;
}

/**
 * Convert a date to its canonical lesson day (1-365)
 * This ensures Dec 17, 2025 and Dec 17, 2030 return the same day number
 */
function getCanonicalLessonDay(date = new Date()) {
  const lessonDay = getTodayLessonDay(date);
  
  if (lessonDay === 'LEAP_DAY') {
    return { day: 366, isLeapDay: true };
  }
  
  return { day: lessonDay, isLeapDay: false };
}
```

### Database Schema Update

```sql
-- Modify core_lessons to be calendar-based
ALTER TABLE core_lessons 
  ADD COLUMN calendar_month INTEGER, -- 1-12
  ADD COLUMN calendar_day INTEGER,   -- 1-31
  ADD COLUMN is_leap_day BOOLEAN DEFAULT FALSE;

-- Create index for date lookups
CREATE INDEX idx_core_lessons_calendar 
  ON core_lessons(calendar_month, calendar_day);

-- Update existing data to map day_number to calendar dates
UPDATE core_lessons SET
  calendar_month = EXTRACT(MONTH FROM (DATE '2026-01-01' + (day_number - 1) * INTERVAL '1 day')),
  calendar_day = EXTRACT(DAY FROM (DATE '2026-01-01' + (day_number - 1) * INTERVAL '1 day'))
WHERE day_number BETWEEN 1 AND 365;

-- Add leap day lesson
INSERT INTO core_lessons (day_number, calendar_month, calendar_day, is_leap_day, topic, universal_truth)
VALUES (366, 2, 29, TRUE, 'The Gift of Extra Time', 'Some days are rare. Use them wisely.');
```

### Lookup Function

```javascript
/**
 * Get the lesson for a specific date
 */
async function getLessonForDate(date = new Date()) {
  const { day, isLeapDay } = getCanonicalLessonDay(date);
  
  if (isLeapDay) {
    // Fetch leap day lesson
    const { data } = await supabase
      .from('core_lessons')
      .select('*')
      .eq('is_leap_day', true)
      .single();
    return data;
  }
  
  // Fetch by calendar date (not day_number)
  const month = date.getMonth() + 1;
  const dayOfMonth = date.getDate();
  
  const { data } = await supabase
    .from('core_lessons')
    .select('*')
    .eq('calendar_month', month)
    .eq('calendar_day', dayOfMonth)
    .single();
  
  return data;
}
```

---

## PART 2: KELLY'S TIME AWARENESS

### Kelly Must Always Know

```javascript
const KellyTime = {
  /**
   * Get current date/time in user's timezone
   */
  now() {
    return new Date();
  },
  
  /**
   * Format date for display
   */
  formatDate(date = new Date()) {
    return new Intl.DateTimeFormat('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    }).format(date);
  },
  
  /**
   * Format time for display
   */
  formatTime(date = new Date()) {
    return new Intl.DateTimeFormat('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    }).format(date);
  },
  
  /**
   * Get greeting based on time of day
   */
  getGreeting(date = new Date()) {
    const hour = date.getHours();
    if (hour < 6) return "You're up late! Or early?";
    if (hour < 12) return "Good morning";
    if (hour < 17) return "Good afternoon";
    if (hour < 21) return "Good evening";
    return "Burning the midnight oil";
  },
  
  /**
   * Get the year for content context
   */
  getYear(date = new Date()) {
    return date.getFullYear();
  },
  
  /**
   * Check if a year is a leap year
   */
  isLeapYear(year) {
    return (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
  },
  
  /**
   * Get days until next occurrence of a date
   */
  daysUntil(month, day) {
    const now = new Date();
    let target = new Date(now.getFullYear(), month - 1, day);
    
    if (target < now) {
      target = new Date(now.getFullYear() + 1, month - 1, day);
    }
    
    const diff = target - now;
    return Math.ceil(diff / (1000 * 60 * 60 * 24));
  }
};
```

### Display in UI

```javascript
/**
 * Update the date display in the lesson player
 */
function updateDateDisplay() {
  const now = KellyTime.now();
  
  // Day badge shows actual date, not "Day 47"
  document.getElementById('day-badge').innerHTML = `
    <span class="date-display">
      ${KellyTime.formatDate(now)}
    </span>
  `;
  
  // Greeting
  document.getElementById('kelly-greeting').textContent = 
    `${KellyTime.getGreeting(now)}! Today's lesson:`;
}
```

### Kelly's Verbal Date Awareness

When generating content, Kelly should reference the actual date:

```javascript
/**
 * Generate date-aware opening for Kelly
 */
function getDateAwareOpening(date = new Date()) {
  const formatted = KellyTime.formatDate(date);
  const year = KellyTime.getYear(date);
  const greeting = KellyTime.getGreeting(date);
  
  // Kelly's opening line includes the real date
  return `${greeting}! It's ${formatted}. Let's learn something beautiful.`;
}
```

---

## PART 3: TIME TRAVEL SYSTEM

### The Concept

```
┌─────────────────────────────────────────────────────────────┐
│                                                              │
│   User views December 17, 1982:                              │
│   → Same TOPIC as December 17, 2025                          │
│   → But CONTENT is anchored to 1982 context                  │
│   → Kelly says "Back in 1982, this was revolutionary..."     │
│                                                              │
│   User views December 17, 2030:                              │
│   → Same TOPIC as December 17, 2025                          │
│   → But CONTENT looks forward to 2030 context                │
│   → Kelly says "By 2030, we might see..."                    │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

### Time Travel UI

```javascript
/**
 * Journey view shows a timeline, not just "Day 1-365"
 */
function buildTimelineView() {
  const today = KellyTime.now();
  const currentYear = today.getFullYear();
  
  // Show actual calendar
  const calendarHTML = `
    <div class="timeline-header">
      <button onclick="navigateYear(-1)">← ${currentYear - 1}</button>
      <span class="current-year">${currentYear}</span>
      <button onclick="navigateYear(1)">${currentYear + 1} →</button>
    </div>
    
    <div class="timeline-months">
      ${generateMonthGrid(currentYear)}
    </div>
    
    <div class="timeline-legend">
      <span class="legend-past">● Past (time-anchored content)</span>
      <span class="legend-today">● Today</span>
      <span class="legend-future">● Future (forward-looking content)</span>
    </div>
  `;
  
  document.getElementById('journey-content').innerHTML = calendarHTML;
}

/**
 * When user selects a date from the timeline
 */
async function selectTimelineDate(date) {
  const today = KellyTime.now();
  const isPast = date < today;
  const isFuture = date > today;
  
  // Get the base lesson (same topic regardless of year)
  const lesson = await getLessonForDate(date);
  
  // Determine temporal context
  const temporalContext = {
    targetDate: date,
    targetYear: date.getFullYear(),
    isPast,
    isFuture,
    yearsDelta: date.getFullYear() - today.getFullYear()
  };
  
  // Load lesson with temporal context
  await loadLessonWithTemporalContext(lesson, temporalContext);
}
```

### Temporal Content Generation

```javascript
/**
 * Generate content prompt with temporal context
 */
function getTemporalPrompt(lesson, temporalContext) {
  const { targetYear, isPast, isFuture, yearsDelta } = temporalContext;
  
  if (isPast) {
    return `
You are Kelly, teaching about "${lesson.topic}" as if it were ${targetYear}.

TEMPORAL ANCHOR: ${targetYear}
- Reference what was known/believed in ${targetYear}
- Use language and cultural references from that era
- If the topic involves technology, describe the ${targetYear} state
- Connect to historical events of ${targetYear}
- Kelly says things like "Back in ${targetYear}..." or "At this time..."

The universal truth remains: "${lesson.universal_truth}"
But the examples and context are from ${targetYear}.
`;
  }
  
  if (isFuture) {
    return `
You are Kelly, teaching about "${lesson.topic}" with a ${targetYear} perspective.

TEMPORAL ANCHOR: ${targetYear} (${Math.abs(yearsDelta)} years from now)
- Speculate thoughtfully about how this topic might evolve
- Use conditional language: "By ${targetYear}, we might see..."
- Ground speculation in current trends
- Acknowledge uncertainty while being engaging
- Kelly says things like "Imagine it's ${targetYear}..." 

The universal truth remains: "${lesson.universal_truth}"
But we're exploring where this might lead.
`;
  }
  
  // Present day
  return `
You are Kelly, teaching about "${lesson.topic}" today.

TEMPORAL ANCHOR: Present day (${targetYear})
- Use current examples and references
- Reference recent events where relevant
- This is the "canonical" version of this lesson

The universal truth: "${lesson.universal_truth}"
`;
}
```

### Temporal Content Storage

```sql
-- Store time-anchored content variations
CREATE TABLE temporal_content (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  core_lesson_id UUID REFERENCES core_lessons(id),
  anchor_year INTEGER NOT NULL,
  archetype TEXT NOT NULL,
  phase TEXT NOT NULL,
  content JSONB NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  
  UNIQUE(core_lesson_id, anchor_year, archetype, phase)
);

-- Index for quick lookups
CREATE INDEX idx_temporal_content_lookup 
  ON temporal_content(core_lesson_id, anchor_year, archetype);
```

---

## PART 4: LEAP DAY HANDLING

### Feb 29 is Special

```javascript
const LEAP_DAY = {
  month: 2,
  day: 29,
  topic: "The Gift of Extra Time",
  universalTruth: "Some days are rare. Use them wisely.",
  
  /**
   * Check if we're on a leap day
   */
  isToday(date = new Date()) {
    return date.getMonth() === 1 && date.getDate() === 29;
  },
  
  /**
   * Get the next leap day
   */
  getNextLeapDay(fromDate = new Date()) {
    let year = fromDate.getFullYear();
    
    while (true) {
      if (KellyTime.isLeapYear(year)) {
        const leapDay = new Date(year, 1, 29);
        if (leapDay > fromDate) {
          return leapDay;
        }
      }
      year++;
    }
  },
  
  /**
   * Days until next leap day
   */
  daysUntilNext(fromDate = new Date()) {
    const next = this.getNextLeapDay(fromDate);
    const diff = next - fromDate;
    return Math.ceil(diff / (1000 * 60 * 60 * 24));
  }
};

// UI enhancement for leap day
function showLeapDayBanner() {
  if (LEAP_DAY.isToday()) {
    return `
      <div class="leap-day-banner">
        🎉 It's Leap Day! A rare gift of 24 extra hours.
        This only happens once every 4 years.
      </div>
    `;
  }
  return '';
}
```

### Leap Day Lesson Content

```sql
-- Ensure leap day has rich content
INSERT INTO lesson_atoms (core_lesson_id, archetype, phase, content)
SELECT 
  cl.id,
  a.archetype,
  p.phase,
  jsonb_build_object(
    'script', CASE 
      WHEN p.phase = 'Hook' THEN 
        'Today doesn''t exist most years. February 29th only appears once every four years. You''re living in borrowed time right now. How will you spend it?'
      WHEN p.phase = 'Fact1' THEN
        'The leap year exists because Earth takes 365.2422 days to orbit the sun—not exactly 365. Without leap years, our calendar would drift by about 24 days every century.'
      WHEN p.phase = 'Fact2' THEN
        'People born on February 29th are called "leaplings." There are only about 5 million of them worldwide. They often celebrate on February 28th or March 1st in non-leap years.'
      WHEN p.phase = 'Fact3' THEN
        'Julius Caesar introduced the leap year in 46 BCE. But his calendar added too many leap days, so Pope Gregory XIII refined it in 1582—that''s why we skip leap years on most century marks.'
      WHEN p.phase = 'Wisdom' THEN
        'Today is a reminder that time isn''t as fixed as we pretend. We literally invented an extra day to make our calendars work. If we can create a day, we can create anything.'
    END
  )
FROM core_lessons cl
CROSS JOIN (VALUES 
  ('The Scientist'), ('The Explorer'), ('The Rebel'), ('The Architect'),
  ('The Diplomat'), ('The Empath'), ('The MacGyver'), ('The Mystic'),
  ('The Provider'), ('The Storyteller'), ('The Strategist'), ('The Survivor')
) AS a(archetype)
CROSS JOIN (VALUES 
  ('Hook'), ('Fact1'), ('Fact2'), ('Fact3'), ('Wisdom')
) AS p(phase)
WHERE cl.is_leap_day = TRUE;
```

---

## PART 5: EMERGENCY LESSONS

### When the World Needs Kelly

Like Mr. Rogers after tragedies, Kelly can spawn special lessons.

```sql
-- Emergency lesson table
CREATE TABLE emergency_lessons (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  trigger_date DATE NOT NULL,
  event_name TEXT NOT NULL,
  event_type TEXT NOT NULL, -- 'tragedy', 'celebration', 'global_event'
  topic TEXT NOT NULL,
  universal_truth TEXT NOT NULL,
  replaces_regular_lesson BOOLEAN DEFAULT FALSE,
  active_start TIMESTAMPTZ NOT NULL,
  active_end TIMESTAMPTZ, -- NULL means indefinitely available
  created_at TIMESTAMPTZ DEFAULT NOW(),
  created_by TEXT -- 'system', 'admin', 'learner_commons'
);

-- Emergency lesson atoms
CREATE TABLE emergency_lesson_atoms (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  emergency_lesson_id UUID REFERENCES emergency_lessons(id),
  archetype TEXT NOT NULL,
  phase TEXT NOT NULL,
  content JSONB NOT NULL,
  age_bucket TEXT NOT NULL -- Different content for kids vs adults
);
```

### Emergency Lesson Logic

```javascript
/**
 * Check if there's an active emergency lesson
 */
async function checkEmergencyLesson(date = new Date()) {
  const { data: emergency } = await supabase
    .from('emergency_lessons')
    .select('*')
    .lte('active_start', date.toISOString())
    .or(`active_end.is.null,active_end.gte.${date.toISOString()}`)
    .order('trigger_date', { ascending: false })
    .limit(1);
  
  if (emergency && emergency.length > 0) {
    return emergency[0];
  }
  
  return null;
}

/**
 * Load today's lesson, checking for emergencies first
 */
async function loadTodayLesson() {
  const today = KellyTime.now();
  
  // Check for emergency lesson first
  const emergency = await checkEmergencyLesson(today);
  
  if (emergency && emergency.replaces_regular_lesson) {
    return loadEmergencyLesson(emergency);
  }
  
  // Load regular calendar-based lesson
  const lesson = await getLessonForDate(today);
  
  // If there's a non-replacing emergency, show option
  if (emergency) {
    showEmergencyOption(emergency);
  }
  
  return lesson;
}
```

### Emergency Lesson Templates

```javascript
const EMERGENCY_TEMPLATES = {
  tragedy: {
    tone: 'gentle, comforting, honest',
    kidApproach: 'Simple, reassuring, focus on safety and helpers',
    adultApproach: 'Acknowledge pain, provide context, offer hope',
    elderApproach: 'Connect to historical resilience, wisdom perspective',
    
    promptPrefix: `
Kelly is addressing a difficult world event today. She speaks with:
- Genuine care, not performative concern
- Age-appropriate honesty
- Focus on helpers and hope without dismissing pain
- No political commentary
- Emphasis on community and taking care of each other
`
  },
  
  celebration: {
    tone: 'joyful, inclusive, meaningful',
    kidApproach: 'Fun, exciting, participatory',
    adultApproach: 'Meaningful, connective, reflective joy',
    elderApproach: 'Historical significance, legacy, gratitude',
    
    promptPrefix: `
Kelly is celebrating something wonderful with learners today. She:
- Shares genuine joy without forced enthusiasm
- Connects the celebration to learning and growth
- Makes it inclusive for all backgrounds
- Finds the deeper meaning in celebration
`
  },
  
  global_event: {
    tone: 'informative, balanced, curious',
    kidApproach: 'Simple explanation, focus on interesting aspects',
    adultApproach: 'Nuanced, multiple perspectives, actionable',
    elderApproach: 'Historical context, pattern recognition, wisdom',
    
    promptPrefix: `
Kelly is helping learners understand a significant world event. She:
- Presents facts without partisan framing
- Acknowledges complexity and uncertainty
- Focuses on what we can learn
- Empowers rather than frightens
`
  }
};
```

### Learner Commons Voting

```sql
-- Topic change proposals
CREATE TABLE topic_proposals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  calendar_month INTEGER NOT NULL,
  calendar_day INTEGER NOT NULL,
  current_topic TEXT NOT NULL,
  proposed_topic TEXT NOT NULL,
  proposed_truth TEXT NOT NULL,
  reason TEXT NOT NULL,
  proposed_by UUID REFERENCES users(id),
  votes_for INTEGER DEFAULT 0,
  votes_against INTEGER DEFAULT 0,
  status TEXT DEFAULT 'voting', -- 'voting', 'approved', 'rejected'
  voting_ends_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Votes
CREATE TABLE topic_votes (
  proposal_id UUID REFERENCES topic_proposals(id),
  user_id UUID REFERENCES users(id),
  vote BOOLEAN NOT NULL, -- true = for, false = against
  created_at TIMESTAMPTZ DEFAULT NOW(),
  PRIMARY KEY (proposal_id, user_id)
);
```

---

## PART 6: UI UPDATES

### Replace "Day X" with Real Dates

```javascript
// OLD (wrong)
document.getElementById('day-badge').textContent = `Day ${state.currentDay}`;

// NEW (correct)
function updateDayBadge() {
  const today = KellyTime.now();
  const lesson = await getLessonForDate(today);
  
  document.getElementById('day-badge').innerHTML = `
    <div class="date-badge">
      <span class="date-main">${KellyTime.formatDate(today)}</span>
      <span class="topic-preview">${lesson.topic}</span>
    </div>
  `;
}
```

### Journey View as Calendar

```javascript
function buildJourneyCalendar() {
  const today = KellyTime.now();
  const year = today.getFullYear();
  
  // Build 12-month calendar view
  const months = [];
  for (let m = 0; m < 12; m++) {
    const monthData = buildMonthData(year, m, today);
    months.push(monthData);
  }
  
  return `
    <div class="year-selector">
      <button onclick="changeYear(-1)">◀</button>
      <span id="display-year">${year}</span>
      <button onclick="changeYear(1)">▶</button>
    </div>
    
    <div class="calendar-grid">
      ${months.map(m => renderMonth(m)).join('')}
    </div>
  `;
}

function buildMonthData(year, month, today) {
  const firstDay = new Date(year, month, 1);
  const lastDay = new Date(year, month + 1, 0);
  const days = [];
  
  for (let d = 1; d <= lastDay.getDate(); d++) {
    const date = new Date(year, month, d);
    const isToday = date.toDateString() === today.toDateString();
    const isPast = date < today;
    const isFuture = date > today;
    const isCompleted = state.completedDates?.includes(date.toISOString().split('T')[0]);
    
    days.push({
      date,
      dayOfMonth: d,
      isToday,
      isPast,
      isFuture,
      isCompleted
    });
  }
  
  return {
    year,
    month,
    name: new Intl.DateTimeFormat('en-US', { month: 'long' }).format(firstDay),
    days
  };
}
```

### State Changes

```javascript
// OLD state model
const state = {
  currentDay: 1,  // Day 1-365
  completedLessons: [1, 2, 3],  // Day numbers
};

// NEW state model  
const state = {
  currentDate: '2025-12-12',  // ISO date string
  completedDates: [            // ISO date strings
    '2025-12-10',
    '2025-12-11',
  ],
  
  // Streak is now calendar-based
  streakStartDate: '2025-12-10',
  
  // Progress is percentage of year completed
  yearProgress: {
    2025: 0.95,  // 95% of 2025 lessons done
    2026: 0.00
  }
};

/**
 * Calculate streak from completed dates
 */
function calculateStreak() {
  const completed = [...state.completedDates].sort().reverse();
  if (completed.length === 0) return 0;
  
  const today = KellyTime.now().toISOString().split('T')[0];
  const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
  
  // Must have completed today or yesterday to have active streak
  if (!completed.includes(today) && !completed.includes(yesterday)) {
    return 0;
  }
  
  let streak = 0;
  let checkDate = new Date(completed[0]);
  
  for (const dateStr of completed) {
    const date = new Date(dateStr);
    const diff = Math.abs(checkDate - date) / 86400000;
    
    if (diff <= 1) {
      streak++;
      checkDate = date;
    } else {
      break;
    }
  }
  
  return streak;
}
```

---

## PART 7: LAUNCH DATE ALIGNMENT

### December 17, 2025 Launch

```javascript
const LAUNCH_CONFIG = {
  launchDate: new Date('2025-12-17'),
  
  // December 17 = Day 351 of a non-leap year
  launchDayOfYear: 351,
  
  // First "Day 1" is January 1, 2026
  firstJanuary1: new Date('2026-01-01'),
  
  /**
   * Check if we're in the "soft launch" period (Dec 17-31, 2025)
   */
  isInSoftLaunch(date = new Date()) {
    return date >= this.launchDate && date < this.firstJanuary1;
  },
  
  /**
   * Get messaging for soft launch period
   */
  getSoftLaunchMessage() {
    const today = KellyTime.now();
    const daysUntilJan1 = Math.ceil((this.firstJanuary1 - today) / 86400000);
    
    return `
      Welcome to Curious Kelly! You're joining us before our official 
      Year One begins on January 1st. Enjoy these ${daysUntilJan1} preview 
      lessons as a founding learner.
    `;
  }
};
```

---

## PART 8: DATE FORMAT CONSISTENCY

### Everywhere Kelly Shows a Date

```javascript
const DateFormatter = {
  // Full date: "Thursday, December 12, 2025"
  full(date) {
    return new Intl.DateTimeFormat('en-US', {
      weekday: 'long',
      year: 'numeric', 
      month: 'long',
      day: 'numeric'
    }).format(date);
  },
  
  // Short date: "Dec 12, 2025"
  short(date) {
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    }).format(date);
  },
  
  // Month and day only: "December 12"
  monthDay(date) {
    return new Intl.DateTimeFormat('en-US', {
      month: 'long',
      day: 'numeric'
    }).format(date);
  },
  
  // Relative: "Today", "Yesterday", "2 days ago"
  relative(date) {
    const rtf = new Intl.RelativeTimeFormat('en', { numeric: 'auto' });
    const diff = Math.ceil((date - new Date()) / 86400000);
    
    if (diff === 0) return 'Today';
    if (diff === -1) return 'Yesterday';
    if (diff === 1) return 'Tomorrow';
    if (diff < 0) return rtf.format(diff, 'day');
    return rtf.format(diff, 'day');
  },
  
  // Time: "3:45 PM"
  time(date) {
    return new Intl.DateTimeFormat('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    }).format(date);
  },
  
  // ISO for storage: "2025-12-12"
  iso(date) {
    return date.toISOString().split('T')[0];
  }
};
```

---

## PART 9: TIMEZONE HANDLING

### User's Local Time Matters

```javascript
const TimeZone = {
  /**
   * Get user's timezone
   */
  getUserTimezone() {
    return Intl.DateTimeFormat().resolvedOptions().timeZone;
  },
  
  /**
   * Get current date in user's timezone
   */
  getLocalDate() {
    return new Date();
  },
  
  /**
   * Check if it's a new day (for streak purposes)
   * Day resets at midnight local time
   */
  isNewDay(lastActivityDate) {
    const now = this.getLocalDate();
    const last = new Date(lastActivityDate);
    
    return now.toDateString() !== last.toDateString();
  },
  
  /**
   * Get midnight tonight (local)
   */
  getMidnightTonight() {
    const now = this.getLocalDate();
    return new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1, 0, 0, 0);
  },
  
  /**
   * Time until day resets
   */
  getTimeUntilReset() {
    const midnight = this.getMidnightTonight();
    const now = this.getLocalDate();
    const diff = midnight - now;
    
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    
    return { hours, minutes };
  }
};

// Display countdown to new lesson
function showNextLessonCountdown() {
  const { hours, minutes } = TimeZone.getTimeUntilReset();
  
  return `
    <div class="next-lesson-countdown">
      Tomorrow's lesson unlocks in ${hours}h ${minutes}m
    </div>
  `;
}
```

---

## PART 10: MIGRATION CHECKLIST

### Database Updates

```sql
-- 1. Add calendar columns to core_lessons
ALTER TABLE core_lessons 
  ADD COLUMN calendar_month INTEGER,
  ADD COLUMN calendar_day INTEGER,
  ADD COLUMN is_leap_day BOOLEAN DEFAULT FALSE;

-- 2. Populate calendar columns
UPDATE core_lessons SET
  calendar_month = EXTRACT(MONTH FROM (DATE '2026-01-01' + (day_number - 1) * INTERVAL '1 day')),
  calendar_day = EXTRACT(DAY FROM (DATE '2026-01-01' + (day_number - 1) * INTERVAL '1 day'))
WHERE day_number BETWEEN 1 AND 365;

-- 3. Add leap day lesson (Day 366)
INSERT INTO core_lessons (day_number, calendar_month, calendar_day, is_leap_day, topic, universal_truth)
VALUES (366, 2, 29, TRUE, 'The Gift of Extra Time', 'Some days are rare. Use them wisely.');

-- 4. Create emergency lessons table
CREATE TABLE emergency_lessons (...);

-- 5. Create temporal content table
CREATE TABLE temporal_content (...);

-- 6. Update indexes
CREATE INDEX idx_core_lessons_calendar ON core_lessons(calendar_month, calendar_day);
```

### Code Updates

```
[ ] Replace getDayNumber() with getCanonicalLessonDay()
[ ] Replace "Day X" displays with real date formatting
[ ] Update state model from currentDay to currentDate
[ ] Update completedLessons to completedDates
[ ] Add KellyTime utility object
[ ] Add TimeZone utility object  
[ ] Add DateFormatter utility object
[ ] Build calendar-based Journey view
[ ] Add time travel date selection
[ ] Add leap day handling
[ ] Add emergency lesson checking
[ ] Update streak calculation to be date-based
[ ] Add soft launch messaging for Dec 17-31
```

### Content Updates

```
[ ] Generate leap day atoms for all 12 archetypes × 5 ages
[ ] Create temporal content variations (at least 5 anchor years)
[ ] Prepare emergency lesson templates
[ ] Update all "Day X" references in content to use dates
```

---

## SUMMARY

**Kelly now:**
1. ✅ Knows what day, date, and year it is
2. ✅ Teaches the same topic on the same calendar date every year
3. ✅ Can time-travel to show lessons with past/future context
4. ✅ Handles leap days as special bonus lessons
5. ✅ Can spawn emergency lessons when the world needs comfort
6. ✅ Uses the learner's local timezone for streak tracking
7. ✅ Displays real dates, not "Day 47"

**The paradigm is now:**
> "Today is December 12, 2025. Every December 12th, Kelly teaches this topic. 
> Same truth, adapted to the moment."

---

*Kelly Temporal System*
*December 12, 2025*
*"Time is Kelly's friend, not her mystery."*
