# COPY-PASTE PROMPTS FOR CURSOR AGENTS

---

## AGENT 1: IMPLEMENTATION

Copy this entire block and paste into a new Cursor agent:

```
You are building Kelly OS — the operating system for human learning.

BEFORE WRITING ANY CODE, read these files in order:
1. docs/KELLY_OS_VISION.md — The complete vision (Kelly is an OS, not an app)
2. docs/KELLY_UNIFIED_DIRECTIVE.md — Shared design system + components
3. docs/KELLY_TEMPORAL_SYSTEM.md — Calendar-based lessons (NOT "Day 1, Day 2")
4. docs/KELLY_FINAL_DIRECTIVE.md — COPPA, PWA, native app setup
5. docs/CURSOR_AGENT_1_IMPLEMENTATION.md — Your full implementation brief

KEY RULES:
- NEVER show "Day X" to users — always show real dates like "December 12, 2025"
- Create SHARED modules: kelly-time.js, kelly-calendar.js, kelly-lesson.js, kelly-presence.js
- index.html and learn.html MUST use the same shared modules
- Every date operation goes through KellyTime
- Launch date: December 17, 2025

START with Phase 1: Create the shared foundation in /public/js/ and /public/styles/

Report what you're doing and ask if unclear.
```

---

## AGENT 2: VERIFICATION (Zero Trust)

Copy this entire block and paste into a SECOND Cursor agent:

```
You are the VERIFICATION agent for Kelly OS. Your job is to audit Agent 1's work.

BEFORE AUDITING, read these files:
1. docs/KELLY_OS_VISION.md
2. docs/KELLY_UNIFIED_DIRECTIVE.md
3. docs/KELLY_TEMPORAL_SYSTEM.md
4. docs/KELLY_TEST_SUITE.md
5. docs/CURSOR_AGENT_2_VERIFICATION.md — Your full verification brief

YOUR JOB:
- Trust NOTHING. Verify EVERYTHING.
- Search for violations: grep -r "Day [0-9]" public/
- Verify both pages use KellyTime (not different date logic)
- Verify state syncs between index.html and learn.html
- Verify leap day (Feb 29) is handled correctly
- Check for exposed API keys
- Check COPPA parental gate exists

DO NOT FIX issues — report them to Agent 1.

SEVERITY LEVELS:
🔴 CRITICAL = Block launch
🟡 MAJOR = Fix before launch  
🟢 MINOR = Fix post-launch

Wait for Agent 1 to complete Phase 1, then run your audit.
Report in this format:

## VERIFICATION REPORT
### CRITICAL: [list]
### MAJOR: [list]
### PASSED: [list]
### RECOMMENDATION: [APPROVED / NEEDS FIXES / BLOCKED]
```

---

## WORKFLOW

1. Close all existing Cursor agents
2. Open Agent 1 — paste the Implementation prompt
3. Open Agent 2 — paste the Verification prompt
4. Agent 1 works on Phase 1
5. Agent 1 reports "Phase 1 complete"
6. Tell Agent 2: "Audit Phase 1"
7. Agent 2 reports violations
8. Agent 1 fixes
9. Repeat for Phase 2, 3, 4

---

## FILES AGENT 1 SHOULD CREATE

Phase 1:
```
/public/styles/kelly-system.css
/public/js/kelly-time.js
/public/js/kelly-calendar.js
/public/js/kelly-lesson.js
/public/js/kelly-presence.js
```

Phase 2:
```
/public/index.html (rewrite)
/public/styles/index.css
/public/js/index.js
```

Phase 3:
```
/public/learn.html (update to use shared modules)
/public/styles/learn.css
/public/js/learn.js (update)
```

Phase 4:
```
Supabase migration SQL
Update API calls to use calendar_month/calendar_day
```

---

## QUICK VERIFICATION COMMANDS

Agent 2 should run these:

```bash
# Find "Day X" violations
grep -rn "Day [0-9]" public/ --include="*.html" --include="*.js"

# Find duplicate date logic
grep -rn "new Date()" public/js/
grep -rn "toLocaleDateString" public/js/

# Find hardcoded colors (should only be in kelly-system.css)
grep -rn "#[0-9a-fA-F]\{3,6\}" public/styles/index.css
grep -rn "#[0-9a-fA-F]\{3,6\}" public/styles/learn.css

# Check for API key exposure
grep -rn "sk_" public/
grep -rn "supabase" public/ --include="*.html"

# Verify shared modules are imported
grep -rn "kelly-time" public/index.html
grep -rn "kelly-time" public/learn.html
```

---

## SUCCESS = LAUNCH READY

When Agent 2 reports:
```
### RECOMMENDATION: ✅ APPROVED FOR LAUNCH
```

You're ready to submit to App Store.
