# CURSOR AGENT 1: IMPLEMENTATION
## Kelly OS — Calendar-First Learning Platform

---

## YOUR MISSION

You are building Kelly OS — the operating system for human learning. Kelly is not an app. Kelly is the daily calendar interface that makes humanity smarter every day.

**Launch date: December 17, 2025 (5 days)**

---

## REQUIRED READING (IN THIS ORDER)

Read these files BEFORE writing any code:

```
1. docs/KELLY_OS_VISION.md
   - Understand: Kelly is an OS, not an app
   - Understand: 60 simultaneous live classes (12 personas × 5 ages)
   - Understand: iLearn hardware coming 2026
   - Understand: SDG 4 mission — education for all

2. docs/KELLY_UNIFIED_DIRECTIVE.md
   - Shared design system (CSS tokens, components)
   - Shared JS modules (KellyTime, KellyCalendar, KellyLesson, KellyPresence)
   - index.html structure
   - learn.html structure
   - File organization

3. docs/KELLY_TEMPORAL_SYSTEM.md
   - Calendar-based lessons (NOT "Day 1, Day 2")
   - Every date = one topic forever
   - Leap day handling (Feb 29 = Day 366)
   - Time travel feature
   - Emergency lessons

4. docs/KELLY_FINAL_DIRECTIVE.md
   - COPPA parental gate
   - PWA setup
   - Capacitor native wrappers
   - Screenshot generation
   - App store submission prep
```

---

## IMPLEMENTATION PRIORITY

### Phase 1: Shared Foundation (DO FIRST)
```
/public/styles/kelly-system.css    ← Design tokens + shared components
/public/js/kelly-time.js           ← Time/date utilities (CRITICAL)
/public/js/kelly-calendar.js       ← Calendar component
/public/js/kelly-lesson.js         ← Supabase lesson fetching
/public/js/kelly-presence.js       ← Live class status
```

### Phase 2: Index.html (Landing Page)
```
/public/index.html                 ← Calendar-first hero
/public/styles/index.css           ← Page-specific styles
/public/js/index.js                ← Page-specific logic
```

### Phase 3: Learn.html (App)
```
/public/learn.html                 ← Update to use shared modules
/public/styles/learn.css           ← Page-specific styles  
/public/js/learn.js                ← Update to use shared modules
```

### Phase 4: Database Migration
```
Run in Supabase:
- Add calendar_month, calendar_day columns to core_lessons
- Add is_leap_day boolean
- Create leap day lesson (Day 366)
- Update lesson lookup to use calendar dates
```

---

## CRITICAL REQUIREMENTS

### 1. Date Display (NEVER "Day X")
```javascript
// WRONG
"Day 47 of your learning journey"
"Welcome to Day 1"

// CORRECT  
"Thursday, December 12, 2025"
"Today's lesson: The Science of Sleep"
```

### 2. Calendar-Based Lessons
```javascript
// WRONG - course mentality
const lesson = await getLessonByDayNumber(state.currentDay);

// CORRECT - calendar mentality
const lesson = await getLessonForDate(new Date()); // Uses month + day
```

### 3. Same Experience Both Pages
```
index.html shows: "December 12, 2025 — The Science of Sleep"
learn.html shows: "December 12, 2025 — The Science of Sleep"

User clicks through → NO change in date/topic display
State persists via localStorage
```

### 4. Live Class Awareness
```javascript
// Both pages show live class status
const status = KellyPresence.getStatusMessage();
// Returns: { badge: "🔴 LIVE NOW", message: "Join 1,847 learners" }
// OR: { badge: "Next: 23m", message: "Morning class at 9:00 AM" }
```

### 5. KellyTime is Source of Truth
```javascript
// ALL date/time operations go through KellyTime
KellyTime.now()           // Current date
KellyTime.fullDate()      // "December 12, 2025"
KellyTime.dayName()       // "Thursday"
KellyTime.iso()           // "2025-12-12" (for storage)
KellyTime.isLeapDay()     // Check Feb 29
```

---

## FILE STRUCTURE TARGET

```
public/
├── index.html              # Landing page (calendar-first)
├── learn.html              # App (uses shared modules)
├── manifest.json           # PWA manifest
├── config.js               # Runtime config
├── sw.js                   # Service worker
│
├── styles/
│   ├── kelly-system.css    # SHARED design system
│   ├── index.css           # index.html specific
│   └── learn.css           # learn.html specific
│
├── js/
│   ├── kelly-time.js       # SHARED time utilities
│   ├── kelly-calendar.js   # SHARED calendar component
│   ├── kelly-lesson.js     # SHARED lesson fetching
│   ├── kelly-presence.js   # SHARED live class status
│   ├── index.js            # index.html specific
│   └── learn.js            # learn.html specific
│
└── images/
    └── kelly-*.png         # All Kelly variants
```

---

## TESTING CHECKPOINTS

After each phase, verify:

### Phase 1 Complete ✓
- [ ] KellyTime.now() returns correct date
- [ ] KellyTime.fullDate() formats correctly
- [ ] KellyCalendar renders current month
- [ ] KellyLesson.getToday() fetches from Supabase
- [ ] KellyPresence shows correct live status

### Phase 2 Complete ✓
- [ ] index.html shows today's date prominently
- [ ] index.html shows today's topic
- [ ] index.html shows next live class time
- [ ] Calendar component is interactive
- [ ] "Start Learning" links to learn.html with context

### Phase 3 Complete ✓
- [ ] learn.html uses same KellyTime module
- [ ] learn.html shows same date/topic as index
- [ ] State persists between pages
- [ ] Calendar in Journey view uses KellyCalendar
- [ ] Completed dates show green checkmarks

### Phase 4 Complete ✓
- [ ] Supabase has calendar_month, calendar_day columns
- [ ] Lesson lookup works by month+day
- [ ] Feb 29 returns leap day lesson
- [ ] All 365 lessons have calendar mappings

---

## DO NOT

- ❌ Use "Day 1, Day 2, Day 3" anywhere
- ❌ Create separate time/calendar logic for each page
- ❌ Hardcode dates or years
- ❌ Ignore the leap day case
- ❌ Skip reading the directive files
- ❌ Build features not in the directives

---

## SUCCESS CRITERIA

When done, this should work:

1. Open index.html at 9:05 AM
2. See "Thursday, December 12, 2025"
3. See "Today's lesson: The Science of Sleep"
4. See "🔴 LIVE NOW — Morning class"
5. Click "Start Learning"
6. learn.html shows SAME date, topic, live status
7. Complete lesson
8. Return to index.html → calendar shows green checkmark
9. **Feels like ONE product, not two pages**

---

## BEGIN

Start by reading the directive files, then implement Phase 1 (shared foundation).

Report back with:
- Files created
- Tests passed
- Any blockers
