# CURIOUS KELLY PRODUCT ROADMAP
## From Launch to Legend

---

## THE VISION

**December 17, 2025:** Kelly launches. 365 lessons. 12 personas. 5 age buckets. One teacher.

**June 2026:** Kelly is the educational equivalent of brushing your teeth—a daily habit for millions. Nicolette transitions to board role. Son turns 5. Exit achieved.

**This roadmap is the bridge.**

---

## RELEASE TIMELINE

| Version | Codename | Target | Theme |
|---------|----------|--------|-------|
| v1.0 | **Genesis** | Dec 17, 2025 | Launch |
| v1.1 | **Voice** | Jan 2026 | Audio polish + ASL foundation |
| v1.2 | **Unity** | Feb 2026 | 2D/3D toggle + immersive mode |
| v1.3 | **Community** | Mar 2026 | Affiliates + Earn to Learn |
| v2.0 | **Conversation** | Q2 2026 | Real-time Kelly dialogue |
| v2.5 | **World** | Q3 2026 | Full localization + global |
| v3.0 | **Platform** | Q4 2026 | API + SDK + partnerships |

---

## v1.0 GENESIS (Launch — Dec 17, 2025)

### What Ships

| Feature | Status |
|---------|--------|
| 12 Kelly personas | ✅ |
| 5 age buckets | ✅ |
| 365 lessons (core) | ✅ |
| Mobile-first PWA | ✅ |
| iOS/Android wrappers | ✅ |
| Streak tracking | ✅ |
| Achievements | ✅ |
| Settings persistence | ✅ |
| COPPA compliance | ✅ |
| Basic audio (TTS fallback) | ✅ |

### What Doesn't Ship (Deferred)

| Feature | Deferred To |
|---------|-------------|
| ASL/Sign language | v1.1 |
| Unity 3D player | v1.2 |
| Affiliate program | v1.3 |
| Real-time conversation | v2.0 |
| Multi-language content | v2.5 |

---

## v1.1 VOICE (January 2026)

### Theme: "Kelly Finds Her Voice(s)"

### Features

#### 1. Voice Tuning for All 60 Kellys

**Problem:** We have 60 Kelly variants (12 personas × 5 ages) but haven't verified each voice sounds right.

**Solution:**

```
Voice Configuration Matrix:
┌─────────────┬─────────┬─────────┬─────────┬─────────┬─────────────┐
│ Persona     │ Kid     │ Teen    │ Adult   │ Elder   │ Super Elder │
├─────────────┼─────────┼─────────┼─────────┼─────────┼─────────────┤
│ Scientist   │ ✓ tune  │ ✓ tune  │ ✓ base  │ ✓ tune  │ ✓ tune      │
│ Explorer    │ ✓ tune  │ ✓ tune  │ ✓ base  │ ✓ tune  │ ✓ tune      │
│ ...         │ ...     │ ...     │ ...     │ ...     │ ...         │
└─────────────┴─────────┴─────────┴─────────┴─────────┴─────────────┘
```

**Technical Approach:**

```javascript
// Voice configuration per Kelly variant
const VOICE_CONFIG = {
  scientist: {
    kid: {
      voice_id: 'wAdymQH5YucAkXwmrdL0',
      stability: 0.7,
      similarity_boost: 0.8,
      style: 0.3,  // Less formal for kids
      speed: 0.9   // Slightly slower
    },
    teen: {
      voice_id: 'wAdymQH5YucAkXwmrdL0',
      stability: 0.75,
      similarity_boost: 0.8,
      style: 0.4,
      speed: 1.0
    },
    adult: {
      voice_id: 'wAdymQH5YucAkXwmrdL0',
      stability: 0.8,
      similarity_boost: 0.85,
      style: 0.5,  // More authoritative
      speed: 1.0
    },
    elder: {
      voice_id: 'wAdymQH5YucAkXwmrdL0',
      stability: 0.85,
      similarity_boost: 0.8,
      style: 0.6,  // Warm, wise
      speed: 0.95  // Slightly slower
    },
    super_elder: {
      voice_id: 'wAdymQH5YucAkXwmrdL0',
      stability: 0.9,
      similarity_boost: 0.75,
      style: 0.7,  // Very warm
      speed: 0.9   // Notably slower
    }
  },
  // ... 11 more personas
};

// Voice tuning workflow
async function tuneVoice(personaId, ageBucket) {
  const config = VOICE_CONFIG[personaId][ageBucket];
  
  // Generate sample
  const sample = await generateTTS(
    "Welcome to Curious Kelly. Today we'll learn something amazing.",
    config
  );
  
  // Human review
  // 1. Does it sound warm?
  // 2. Does it match the age?
  // 3. Does it match the persona energy?
  // 4. Would you want to hear this every day?
  
  return sample;
}
```

**Deliverable:** Voice tuning dashboard + approved configs for all 60 variants.

---

#### 2. ASL/Sign Language Foundation

**Why This Matters:**
> "Kelly is named after a real person who is deaf and teaches ASL. This isn't a feature—it's honoring the origin."

**The Challenge:**
ASL is a complete visual language, not just "subtitles with hand gestures." Proper ASL:
- Has different grammar than English
- Uses facial expressions as grammar
- Requires 3D space for meaning
- Changes based on context

**Phase 1 (v1.1): Research + Proof of Concept**

```
Week 1-2: Research
├── Study existing ASL avatar projects
│   ├── SignAll (academic)
│   ├── SLAIT (startup)
│   └── VirtualSignAI
├── Evaluate generation approaches
│   ├── Motion capture → Avatar
│   ├── Text → ASL translation + avatar
│   └── Full video generation (Sora-style)
└── Talk to Deaf community advisors

Week 3-4: Proof of Concept
├── Generate 1 ASL lesson (Day 1, Hook only)
├── Test with Kelly (the real person)
├── Document learnings
└── Plan full implementation for v1.2+
```

**Technical Options:**

| Approach | Pros | Cons | Cost |
|----------|------|------|------|
| **Pre-recorded human** | Most authentic | Doesn't scale, can't personalize | $$$$ |
| **Motion capture → Avatar** | High quality | Requires capture sessions | $$$ |
| **Text → ASL AI** | Scalable | Grammar accuracy varies | $$ |
| **Generative video** | Most scalable | Technology immature | $ |

**Recommended Path:**
1. Partner with ASL interpreter for initial content review
2. Use SignAll or similar for text → gloss translation
3. Drive Unity avatar with translated signs
4. Human review every lesson before publish

**v1.1 Deliverable:** 
- ASL mode toggle in settings (hidden/beta)
- Day 1 available in ASL (proof of concept)
- Feedback mechanism for Deaf users

---

#### 3. Voice Preview in Settings

Let users hear Kelly before starting:

```javascript
// Settings enhancement
function previewVoice() {
  const config = VOICE_CONFIG[state.kellyId][getAgeBucket(state.age)];
  const sample = `Hi! I'm Kelly, your ${KELLYS[state.kellyId].name}. 
                  Ready to learn something amazing together?`;
  
  playTTS(sample, config);
}
```

---

### v1.1 Timeline

| Week | Focus |
|------|-------|
| Week 1 | Voice config matrix + tuning tools |
| Week 2 | Tune all 60 voices (5 per day) |
| Week 3 | ASL research + partnerships |
| Week 4 | ASL proof of concept + QA |

---

## v1.2 UNITY (February 2026)

### Theme: "Kelly Steps Into Your World"

### Features

#### 1. 2D/3D Mode Toggle

**What We Have:**
- Unity WebGL player (receiving today)
- 60 Kelly head images (2D)
- Kelly 3D model (Character Creator 5 / iClone 8)

**The Experience:**

```
2D Mode (Default):
┌────────────────────────────┐
│                            │
│     ┌──────────────┐       │
│     │   Kelly's    │       │
│     │   Head PNG   │       │
│     └──────────────┘       │
│                            │
│   "Today we learn about    │
│    photosynthesis..."      │
│                            │
└────────────────────────────┘

3D Mode (Enhanced):
┌────────────────────────────┐
│                            │
│     ╭──────────────╮       │
│     │   Kelly 3D   │       │
│     │  (Animated)  │       │
│     │ Lip-sync +   │       │
│     │ Gestures     │       │
│     ╰──────────────╯       │
│                            │
│   "Today we learn about    │
│    photosynthesis..."      │
│                            │
└────────────────────────────┘
```

**Technical Architecture:**

```
User toggles 3D mode
        │
        ▼
┌───────────────────┐
│ Check device      │
│ capabilities      │
│ - WebGL support   │
│ - RAM > 2GB       │
│ - GPU available   │
└─────────┬─────────┘
          │
    ┌─────┴─────┐
    │           │
    ▼           ▼
 Capable    Not Capable
    │           │
    ▼           ▼
 Load Unity   Keep 2D
 WebGL player + message
    │
    ▼
┌───────────────────┐
│ Unity receives:   │
│ - Persona ID      │
│ - Age bucket      │
│ - Audio URL       │
│ - Phase timing    │
└─────────┬─────────┘
          │
          ▼
┌───────────────────┐
│ Unity renders:    │
│ - Correct outfit  │
│ - Age-morphed face│
│ - Lip sync        │
│ - Gestures        │
│ - Eye contact     │
└───────────────────┘
```

**Unity ↔ Web Communication:**

```javascript
// Web → Unity
function sendToUnity(command, data) {
  if (window.unityInstance) {
    window.unityInstance.SendMessage('KellyController', command, JSON.stringify(data));
  }
}

// Load Kelly variant
sendToUnity('LoadKelly', {
  persona: 'scientist',
  ageBucket: 'adult',
  outfit: 'lab_coat'
});

// Start speaking
sendToUnity('StartSpeaking', {
  audioUrl: 'https://...',
  duration: 45.2,
  phonemes: [...] // For lip sync
});

// Unity → Web (callbacks)
window.onUnityReady = () => console.log('Unity loaded');
window.onUnityError = (err) => fallbackTo2D();
window.onSpeechComplete = () => advancePhase();
```

---

#### 2. Immersive Mode

Full-screen 3D Kelly with minimal UI:

```javascript
function enterImmersiveMode() {
  // Hide UI elements
  document.getElementById('bottom-nav').style.display = 'none';
  document.getElementById('phase-progress').style.display = 'none';
  
  // Expand Unity canvas
  document.getElementById('unity-container').classList.add('fullscreen');
  
  // Show floating controls
  showFloatingControls(['pause', 'next', 'bookmark']);
  
  // Request fullscreen
  document.documentElement.requestFullscreen();
}
```

---

#### 3. AR Mode (Experimental)

Kelly in your room via WebXR:

```javascript
async function startARMode() {
  if (!navigator.xr) {
    showToast('AR not supported on this device');
    return;
  }
  
  const supported = await navigator.xr.isSessionSupported('immersive-ar');
  if (!supported) {
    showToast('AR not available');
    return;
  }
  
  // Launch AR session
  const session = await navigator.xr.requestSession('immersive-ar', {
    requiredFeatures: ['hit-test', 'dom-overlay'],
    domOverlay: { root: document.getElementById('ar-overlay') }
  });
  
  // Place Kelly in the room
  // ... WebXR rendering code
}
```

---

### v1.2 Timeline

| Week | Focus |
|------|-------|
| Week 1 | Integrate Unity WebGL player |
| Week 2 | Build 2D/3D toggle + fallback |
| Week 3 | Persona/age variant loading |
| Week 4 | Immersive mode + polish |

---

## v1.3 COMMUNITY (March 2026)

### Theme: "Learn Together, Earn Together"

### Features

#### 1. Affiliate Program ("Earn to Learn")

**Model:**
```
User signs up with referral code
        │
        ▼
Referred user completes Day 1
        │
        ▼
Referrer gets $1 credit
        │
        ▼
Referred user subscribes
        │
        ▼
Referrer gets 20% of first year ($16)
        │
        ▼
Ongoing: 10% of renewals forever
```

**Technical Implementation:**

```javascript
// Referral tracking
const REFERRAL_PARAMS = ['ref', 'affiliate', 'via'];

function captureReferral() {
  const params = new URLSearchParams(window.location.search);
  
  for (const key of REFERRAL_PARAMS) {
    const code = params.get(key);
    if (code) {
      localStorage.setItem('referralCode', code);
      trackEvent('referral_captured', { code });
      return code;
    }
  }
  
  return null;
}

// Stripe integration for affiliate payouts
async function processAffiliateCommission(subscription) {
  const referralCode = subscription.metadata.referralCode;
  if (!referralCode) return;
  
  const affiliate = await getAffiliateByCode(referralCode);
  if (!affiliate) return;
  
  // Calculate commission
  const commission = subscription.amount * 0.20; // 20%
  
  // Create payout via Stripe Connect
  await stripe.transfers.create({
    amount: commission,
    currency: 'usd',
    destination: affiliate.stripeAccountId,
    description: `Commission for ${subscription.id}`
  });
}
```

**Affiliate Dashboard:**

```
┌────────────────────────────────────────┐
│  🎓 Kelly Affiliate Dashboard          │
├────────────────────────────────────────┤
│                                        │
│  Your Code: SARAH2025                  │
│  Your Link: curiouskelly.com/?ref=...  │
│                                        │
│  ┌──────────────────────────────────┐  │
│  │ This Month                       │  │
│  │ ─────────────────────────────── │  │
│  │ Clicks:      247                 │  │
│  │ Sign-ups:    34                  │  │
│  │ Conversions: 8                   │  │
│  │ Earnings:    $128.00             │  │
│  └──────────────────────────────────┘  │
│                                        │
│  [Copy Link]  [Share]  [Withdraw]      │
│                                        │
└────────────────────────────────────────┘
```

---

#### 2. Family Accounts

```javascript
// Family plan: 1 primary + 5 members
const FAMILY_PLAN = {
  maxMembers: 5,
  priceMonthly: 14.99,  // vs $9.99 individual
  priceYearly: 119.99,  // vs $79.99 individual
};

// Each family member gets:
// - Own Kelly selection
// - Own age setting
// - Own progress/streak
// - Shared subscription
```

---

#### 3. Classroom Mode

For teachers with 30+ students:

```javascript
const CLASSROOM_PLAN = {
  pricePerSeat: 4.99,  // per student/month
  minSeats: 10,
  features: [
    'Teacher dashboard',
    'Progress tracking per student',
    'Assignment system',
    'Curriculum alignment reports',
    'Bulk enrollment'
  ]
};
```

---

### v1.3 Timeline

| Week | Focus |
|------|-------|
| Week 1 | Stripe Connect setup for affiliates |
| Week 2 | Affiliate dashboard + tracking |
| Week 3 | Family account logic |
| Week 4 | Classroom mode MVP |

---

## v2.0 CONVERSATION (Q2 2026)

### Theme: "Kelly Listens"

### The Vision

Today: Kelly talks, learner listens.
Tomorrow: Kelly and learner have a conversation.

### Features

#### 1. Real-Time Voice Dialogue

```
Learner: "Kelly, I didn't understand that last part."

Kelly: "No problem! Let me explain it differently. 
       You know how a sponge absorbs water? 
       Photosynthesis is like that, but with light..."

Learner: "Oh, so the leaf is like a sponge for sunlight?"

Kelly: "Exactly! You've got it. Want to try a quick quiz?"
```

**Technical Stack:**

```
┌─────────────────────────────────────────────────────────┐
│                    Real-Time Pipeline                    │
├─────────────────────────────────────────────────────────┤
│                                                          │
│  User speaks                                             │
│       │                                                  │
│       ▼                                                  │
│  ┌─────────────┐                                        │
│  │ Deepgram    │  Speech-to-Text (streaming)            │
│  │ or Whisper  │  ~200ms latency                        │
│  └──────┬──────┘                                        │
│         │                                                │
│         ▼                                                │
│  ┌─────────────┐                                        │
│  │ Claude API  │  Context: lesson + Kelly persona       │
│  │ (Streaming) │  + conversation history                │
│  └──────┬──────┘                                        │
│         │                                                │
│         ▼                                                │
│  ┌─────────────┐                                        │
│  │ ElevenLabs  │  Text-to-Speech (streaming)            │
│  │ (Streaming) │  ~300ms latency                        │
│  └──────┬──────┘                                        │
│         │                                                │
│         ▼                                                │
│  Kelly speaks + animates                                 │
│                                                          │
│  Total latency target: < 1 second                        │
│                                                          │
└─────────────────────────────────────────────────────────┘
```

**Implementation:**

```javascript
class KellyConversation {
  constructor() {
    this.socket = null;
    this.mediaRecorder = null;
    this.conversationHistory = [];
  }
  
  async start() {
    // Connect to conversation server
    this.socket = new WebSocket('wss://api.curiouskelly.com/conversation');
    
    // Send context
    this.socket.send(JSON.stringify({
      type: 'init',
      context: {
        persona: state.kellyId,
        ageBucket: getAgeBucket(state.age),
        currentLesson: currentLesson,
        currentPhase: state.currentPhase,
        history: this.conversationHistory
      }
    }));
    
    // Start listening
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    this.mediaRecorder = new MediaRecorder(stream);
    
    this.mediaRecorder.ondataavailable = (e) => {
      this.socket.send(e.data);
    };
    
    this.mediaRecorder.start(100); // Send chunks every 100ms
  }
  
  handleResponse(audioChunk) {
    // Stream audio to speaker
    this.audioContext.decodeAudioData(audioChunk, (buffer) => {
      const source = this.audioContext.createBufferSource();
      source.buffer = buffer;
      source.connect(this.audioContext.destination);
      source.start();
    });
    
    // Animate Kelly mouth
    updateKellyLipSync(audioChunk);
  }
}
```

---

#### 2. "Ask Kelly" Feature

Quick questions during lessons:

```javascript
// Button in lesson player
function askKelly() {
  showOverlay('ask-kelly');
  
  // Options:
  // 1. Voice question (mic)
  // 2. Text question (keyboard)
  // 3. Quick prompts: "Explain again", "Give example", "Quiz me"
}
```

---

#### 3. Practice Mode

Kelly quizzes you after lessons:

```javascript
const practiceSession = {
  async start(lessonId) {
    // Generate questions from lesson content
    const questions = await generateQuestions(lessonId, state.kellyId);
    
    // Kelly asks verbally
    await kelly.speak(questions[0].question);
    
    // Listen for answer
    const answer = await listenForAnswer();
    
    // Kelly responds
    if (isCorrect(answer, questions[0])) {
      await kelly.speak("That's right! " + questions[0].explanation);
    } else {
      await kelly.speak("Not quite. " + questions[0].hint);
    }
  }
};
```

---

### v2.0 Technical Requirements

| Component | Requirement | Provider |
|-----------|-------------|----------|
| STT Streaming | < 200ms latency | Deepgram |
| LLM Streaming | < 500ms first token | Claude API |
| TTS Streaming | < 300ms latency | ElevenLabs |
| WebSocket server | Handles 1000+ concurrent | Custom (Cloudflare Workers) |
| Conversation memory | Per-session + cross-session | Supabase |

---

### v2.0 Timeline

| Month | Focus |
|-------|-------|
| Month 1 | STT + TTS streaming pipeline |
| Month 2 | Claude conversation integration |
| Month 3 | Unity lip-sync for real-time |
| Month 4 | Practice mode + polish |

---

## v2.5 WORLD (Q3 2026)

### Theme: "Kelly Speaks Your Language"

### Features

#### 1. Full Localization

| Language | UI | Content | Voice |
|----------|-----|---------|-------|
| English | ✓ | ✓ | ✓ |
| Spanish | ✓ | ✓ | ✓ |
| French | ✓ | ✓ | ✓ |
| German | ✓ | ✓ | ✓ |
| Portuguese | ✓ | ✓ | ✓ |
| Japanese | ✓ | ✓ | ✓ |
| Korean | ✓ | ✓ | ✓ |
| Mandarin | ✓ | ✓ | ✓ |
| Hindi | ✓ | ✓ | ✓ |
| Arabic | ✓ | ✓ | ✓ (RTL) |

#### 2. Regional Content Adaptation

Not just translation—cultural adaptation:

```
US: "Think of it like a baseball player catching a ball..."
UK: "Think of it like a footballer heading the ball..."
Japan: "Think of it like catching a ball in baseball..."
India: "Think of it like a cricket player catching..."
```

#### 3. Local Curriculum Alignment

Partner with education ministries to align with:
- Common Core (US)
- National Curriculum (UK)
- CBSE/ICSE (India)
- etc.

---

## v3.0 PLATFORM (Q4 2026)

### Theme: "Kelly Everywhere"

### Features

#### 1. Kelly API

Let other apps use Kelly:

```javascript
// Third-party integration
const kelly = new KellyAPI({ apiKey: 'sk_...' });

// Generate lesson for their content
const lesson = await kelly.createLesson({
  topic: "How vaccines work",
  audience: "adult",
  style: "scientist",
  format: "5-phase"
});

// Get audio
const audio = await kelly.generateAudio(lesson, {
  voice: "scientist-adult"
});
```

#### 2. Kelly SDK

Embed Kelly in any app:

```javascript
// React component
import { Kelly } from '@curiouskelly/react';

function App() {
  return (
    <Kelly
      persona="storyteller"
      age={25}
      topic="Your custom topic"
      onComplete={() => console.log('Done!')}
    />
  );
}
```

#### 3. Kelly for Enterprise

White-label Kelly for corporate training:

```
Acme Corp Training Portal
├── Kelly teaches onboarding
├── Kelly teaches compliance
├── Kelly teaches product knowledge
└── Progress tracked in Acme's LMS
```

---

## TECHNICAL DEBT & INFRASTRUCTURE

### Ongoing Work (Every Release)

| Task | Frequency |
|------|-----------|
| Voice quality audits | Monthly |
| Content accuracy review | Weekly |
| Performance monitoring | Daily |
| Security audits | Quarterly |
| Accessibility testing | Per release |
| Load testing | Per release |

### Infrastructure Scaling

| Milestone | Action |
|-----------|--------|
| 10K users | Current Vercel/Supabase handles |
| 100K users | Add CDN caching, optimize queries |
| 1M users | Multi-region deployment |
| 10M users | Custom infrastructure |

---

## SUCCESS METRICS BY VERSION

| Version | Key Metric | Target |
|---------|------------|--------|
| v1.0 | Day 1 completion | 70% |
| v1.1 | Voice satisfaction | 4.5/5 |
| v1.2 | 3D mode adoption | 30% |
| v1.3 | Affiliate revenue | $10K/mo |
| v2.0 | Conversation engagement | 5 min avg |
| v2.5 | Non-English users | 40% |
| v3.0 | API revenue | $50K/mo |

---

## THE EXIT PATH

```
Dec 2025: Launch (v1.0)
         │
         ▼
Mar 2026: 100K users, $50K MRR
         │
         ▼
Jun 2026: 500K users, $200K MRR → EXIT
         │                        Son turns 5
         ▼                        Board role
Dec 2026: 1M users, $500K MRR
         │
         ▼
Mar 2027: Strategic acquisition interest
         │
         ▼
Jun 2027: Full scale / IPO path
```

---

## FAQ

### General

**Q: What is Curious Kelly?**
A: Curious Kelly is a daily learning companion that delivers one beautiful micro-lesson every day, 365 days a year. Kelly is an AI teacher who adapts her teaching style to match your personality and age.

**Q: Who is Kelly?**
A: Kelly is named after a real person—a Deaf teacher who teaches ASL. The digital Kelly honors her legacy by making education accessible and personal for everyone.

**Q: What ages is Kelly for?**
A: Kelly is designed for learners ages 2 to 102. She transforms her appearance, vocabulary, and teaching style to match each learner's age.

**Q: How long is each lesson?**
A: Each lesson is approximately 5 minutes—perfect for daily learning without overwhelming your schedule.

**Q: What topics does Kelly teach?**
A: Kelly covers 365 unique topics spanning science, history, philosophy, practical skills, and wisdom. Each day brings something new.

### Technical

**Q: Is there an app?**
A: Yes! Curious Kelly is available as a web app (curiouskelly.com/learn), and as native apps on iOS and Android.

**Q: Does Kelly work offline?**
A: Partially. The app shell and your current lesson work offline. New lessons require an internet connection.

**Q: What devices are supported?**
A: Kelly works on any modern smartphone, tablet, or computer. We recommend iPhone (iOS 15+), Android (version 10+), or any desktop browser.

**Q: Is my data private?**
A: Yes. We collect minimal data and never sell it. See our privacy policy for details. Kelly is COPPA-compliant for learners under 13.

### Features

**Q: What are the 12 Kelly personas?**
A: The Scientist, Explorer, Rebel, Architect, Diplomat, Empath, MacGyver, Mystic, Provider, Storyteller, Strategist, and Survivor. Each teaches with a unique style.

**Q: Can I change my Kelly?**
A: Absolutely! Go to Settings → Your Kelly → Change Kelly to pick a new persona anytime.

**Q: What's the streak?**
A: Your streak counts consecutive days of learning. Keep it going for achievements and bragging rights!

**Q: Will Kelly support sign language?**
A: Yes! ASL support is coming in v1.1 (January 2026). Kelly was named after a Deaf teacher, so accessibility is core to our mission.

**Q: Can I talk to Kelly?**
A: Real-time conversation is coming in v2.0 (Q2 2026). For now, Kelly teaches and you listen—but soon, you'll be able to ask questions and have back-and-forth dialogue.

### Subscription

**Q: Is Curious Kelly free?**
A: Day 1 is free for everyone. Full access to all 365 lessons requires a subscription.

**Q: How much does it cost?**
A: Monthly: $9.99. Yearly: $79.99 (save 33%). Lifetime: $199.99.

**Q: Is there a family plan?**
A: Coming in v1.3 (March 2025). Family plan will cover up to 5 learners for $14.99/month.

**Q: Can I get a refund?**
A: Yes. Contact support within 14 days for a full refund, no questions asked.

### Affiliate Program

**Q: How does the affiliate program work?**
A: Share your unique link. When someone signs up and completes Day 1, you get $1. When they subscribe, you get 20% of their first year and 10% of renewals forever.

**Q: How do I become an affiliate?**
A: Coming in v1.3 (March 2026). Sign up at curiouskelly.com/affiliates.

**Q: When do I get paid?**
A: Payouts are processed monthly via Stripe. Minimum payout is $20.

### Support

**Q: How do I contact support?**
A: Email support@curiouskelly.com or tap Help in the app settings.

**Q: I found a bug. How do I report it?**
A: Tap the thumbs down after any lesson, or email bugs@curiouskelly.com with details.

**Q: Can I request a feature?**
A: Yes! Email ideas@curiouskelly.com. We read every suggestion.

---

*Curious Kelly Product Roadmap*
*December 2025 → June 2026*
*"From launch to legend."*
