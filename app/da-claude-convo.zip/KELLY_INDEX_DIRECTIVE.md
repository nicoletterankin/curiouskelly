# CURIOUS KELLY INDEX.HTML DIRECTIVE
## The Front Door to Kelly's World

---

## THE PROBLEM

The current index.html was built before learn.html existed. It's selling a vision.

Now we have the product. The landing page must:
1. Show what Kelly actually looks like
2. Demonstrate the real experience
3. Convert visitors to learners
4. Set accurate expectations

---

## THE TRANSFORMATION

### Before (Vision)
```
"Coming soon..."
"Imagine a teacher who..."
"Sign up for early access..."
```

### After (Reality)
```
"Meet Kelly. Start learning now."
"Here's today's lesson preview."
"Your first lesson is free."
```

---

## PART 1: PAGE STRUCTURE

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Curious Kelly — Daily Learning for Ages 2-102</title>
  
  <!-- SEO -->
  <meta name="description" content="Meet Kelly, your personal AI teacher. One beautiful lesson every day, 365 days a year. Choose from 12 teaching styles. Ages 2 to 102.">
  <meta name="keywords" content="learning app, daily learning, AI teacher, education, micro-lessons, kids learning, adult education">
  
  <!-- Open Graph -->
  <meta property="og:title" content="Curious Kelly — The Teacher You Never Knew You Needed">
  <meta property="og:description" content="One lesson. Every day. For everyone.">
  <meta property="og:image" content="https://curiouskelly.com/og-image.jpg">
  <meta property="og:url" content="https://curiouskelly.com">
  <meta property="og:type" content="website">
  
  <!-- Twitter -->
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="Curious Kelly">
  <meta name="twitter:description" content="Meet your daily learning companion">
  <meta name="twitter:image" content="https://curiouskelly.com/twitter-card.jpg">
  
  <!-- Favicon -->
  <link rel="icon" href="/favicon.ico">
  <link rel="apple-touch-icon" href="/icons/apple-touch-icon.png">
  
  <!-- Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
  
  <!-- Styles -->
  <link rel="stylesheet" href="/styles/index.css">
</head>
<body>
  <!-- Hero -->
  <!-- Meet Kelly -->
  <!-- How It Works -->
  <!-- The 12 Kellys -->
  <!-- For Every Age -->
  <!-- What You'll Learn -->
  <!-- Testimonials (Post-Launch) -->
  <!-- Pricing -->
  <!-- FAQ -->
  <!-- Footer -->
</body>
</html>
```

---

## PART 2: HERO SECTION

### Design
```
┌─────────────────────────────────────────────────────────────┐
│  [Logo]                      [Features] [Pricing] [Start]   │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│     The teacher you never                    ┌──────────┐   │
│     knew you needed.                         │          │   │
│                                              │  Kelly   │   │
│     One lesson. Every day.                   │  Video   │   │
│     For everyone.                            │  Preview │   │
│                                              │          │   │
│     🎯 5 minutes a day                       └──────────┘   │
│     📚 365 unique lessons                                   │
│     👩‍🔬 12 teaching styles                                   │
│                                                              │
│     [Start Learning — Free]                                 │
│                                                              │
│     Trusted by 10,000+ curious minds                        │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

### Code

```html
<section class="hero">
  <div class="hero-content">
    <h1>The teacher you never knew you needed.</h1>
    <p class="tagline">One lesson. Every day. For everyone.</p>
    
    <ul class="hero-features">
      <li>🎯 5 minutes a day</li>
      <li>📚 365 unique lessons</li>
      <li>👩‍🔬 12 teaching styles</li>
    </ul>
    
    <a href="/learn.html" class="btn-primary btn-large">
      Start Learning — Free
    </a>
    
    <p class="social-proof">Trusted by 10,000+ curious minds</p>
  </div>
  
  <div class="hero-media">
    <div class="phone-frame">
      <video 
        autoplay 
        muted 
        loop 
        playsinline
        poster="/images/hero-poster.jpg"
      >
        <source src="/videos/kelly-preview.mp4" type="video/mp4">
      </video>
    </div>
  </div>
</section>
```

### Hero Video Requirements

Create a 15-second loop showing:
1. Kelly (Scientist) speaking a hook (3s)
2. Swipe to Explorer (2s)
3. Kelly (Explorer) speaking (3s)
4. Phase navigation (2s)
5. Completion confetti (3s)
6. Streak celebration (2s)

---

## PART 3: MEET KELLY SECTION

### Design
```
┌─────────────────────────────────────────────────────────────┐
│                                                              │
│                      Meet Kelly                              │
│                                                              │
│     Kelly isn't just an AI. She's your personal guide       │
│     through 365 days of wonder, wisdom, and growth.         │
│                                                              │
│     Named after a real teacher — a Deaf educator who        │
│     proved that learning knows no barriers.                 │
│                                                              │
│     ┌─────────────┐  ┌─────────────┐  ┌─────────────┐      │
│     │   Kelly     │  │   Kelly     │  │   Kelly     │      │
│     │   Kid       │  │   Adult     │  │   Elder     │      │
│     │   (age 8)   │  │   (age 35)  │  │   (age 70)  │      │
│     └─────────────┘  └─────────────┘  └─────────────┘      │
│                                                              │
│     She transforms to meet you where you are.               │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

### Code

```html
<section class="meet-kelly">
  <h2>Meet Kelly</h2>
  
  <p class="section-intro">
    Kelly isn't just an AI. She's your personal guide through 
    365 days of wonder, wisdom, and growth.
  </p>
  
  <p class="kelly-origin">
    Named after a real teacher — a Deaf educator who proved 
    that learning knows no barriers.
  </p>
  
  <div class="kelly-ages">
    <div class="kelly-age">
      <img src="/images/kelly-kid.png" alt="Kelly for kids">
      <span>Ages 2-12</span>
    </div>
    <div class="kelly-age featured">
      <img src="/images/kelly-adult.png" alt="Kelly for adults">
      <span>Ages 18-49</span>
    </div>
    <div class="kelly-age">
      <img src="/images/kelly-elder.png" alt="Kelly for elders">
      <span>Ages 50-102</span>
    </div>
  </div>
  
  <p class="kelly-transform">
    She transforms to meet you where you are.
  </p>
</section>
```

---

## PART 4: HOW IT WORKS

### Design
```
┌─────────────────────────────────────────────────────────────┐
│                                                              │
│                    How It Works                              │
│                                                              │
│     ┌───────┐        ┌───────┐        ┌───────┐            │
│     │   1   │   →    │   2   │   →    │   3   │            │
│     └───────┘        └───────┘        └───────┘            │
│                                                              │
│     Choose           Learn            Grow                   │
│     Your Kelly       Daily            Forever                │
│                                                              │
│     Pick from 12     5 minutes.       Build streaks.        │
│     teaching         5 phases.        Earn badges.          │
│     styles that      1 new topic.     Never stop.           │
│     match you.       Every day.                              │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

### Code

```html
<section class="how-it-works">
  <h2>How It Works</h2>
  
  <div class="steps">
    <div class="step">
      <div class="step-number">1</div>
      <h3>Choose Your Kelly</h3>
      <p>Pick from 12 teaching styles that match your personality.</p>
    </div>
    
    <div class="step-arrow">→</div>
    
    <div class="step">
      <div class="step-number">2</div>
      <h3>Learn Daily</h3>
      <p>5 minutes. 5 phases. 1 new topic. Every single day.</p>
    </div>
    
    <div class="step-arrow">→</div>
    
    <div class="step">
      <div class="step-number">3</div>
      <h3>Grow Forever</h3>
      <p>Build streaks. Earn badges. Never stop being curious.</p>
    </div>
  </div>
</section>
```

---

## PART 5: THE 12 KELLYS

### Design
```
┌─────────────────────────────────────────────────────────────┐
│                                                              │
│                   12 Ways to Learn                           │
│                                                              │
│     Every mind is different. Kelly adapts.                   │
│                                                              │
│     ┌─────┐ ┌─────┐ ┌─────┐ ┌─────┐ ┌─────┐ ┌─────┐       │
│     │ 🔬  │ │ 🌎  │ │ ⚡  │ │ 📐  │ │ 🤝  │ │ 💜  │       │
│     │Sci- │ │Expl-│ │Reb- │ │Arch-│ │Dipl-│ │Emp- │       │
│     │ntist│ │orer │ │el   │ │itect│ │omat │ │ath  │       │
│     └─────┘ └─────┘ └─────┘ └─────┘ └─────┘ └─────┘       │
│                                                              │
│     ┌─────┐ ┌─────┐ ┌─────┐ ┌─────┐ ┌─────┐ ┌─────┐       │
│     │ 🔧  │ │ 🔮  │ │ 🏠  │ │ 📖  │ │ ♟️  │ │ 🏔️  │       │
│     │Mac- │ │Mys- │ │Prov-│ │Stor-│ │Stra-│ │Surv-│       │
│     │Gyver│ │tic  │ │ider │ │tllr │ │tgst │ │ivor │       │
│     └─────┘ └─────┘ └─────┘ └─────┘ └─────┘ └─────┘       │
│                                                              │
│     [Take the Quiz →]                                        │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

### Code

```html
<section class="twelve-kellys">
  <h2>12 Ways to Learn</h2>
  <p class="section-intro">Every mind is different. Kelly adapts.</p>
  
  <div class="persona-grid">
    <div class="persona" data-id="scientist">
      <img src="/images/kelly-scientist-thumb.png" alt="The Scientist">
      <h4>The Scientist</h4>
      <p>Data-driven precision</p>
    </div>
    
    <div class="persona" data-id="explorer">
      <img src="/images/kelly-explorer-thumb.png" alt="The Explorer">
      <h4>The Explorer</h4>
      <p>Wonder-filled discovery</p>
    </div>
    
    <div class="persona" data-id="rebel">
      <img src="/images/kelly-rebel-thumb.png" alt="The Rebel">
      <h4>The Rebel</h4>
      <p>Question everything</p>
    </div>
    
    <div class="persona" data-id="architect">
      <img src="/images/kelly-architect-thumb.png" alt="The Architect">
      <h4>The Architect</h4>
      <p>Build understanding</p>
    </div>
    
    <div class="persona" data-id="diplomat">
      <img src="/images/kelly-diplomat-thumb.png" alt="The Diplomat">
      <h4>The Diplomat</h4>
      <p>Every perspective</p>
    </div>
    
    <div class="persona" data-id="empath">
      <img src="/images/kelly-empath-thumb.png" alt="The Empath">
      <h4>The Empath</h4>
      <p>Feel to understand</p>
    </div>
    
    <div class="persona" data-id="macgyver">
      <img src="/images/kelly-macgyver-thumb.png" alt="The MacGyver">
      <h4>The MacGyver</h4>
      <p>Practical wisdom</p>
    </div>
    
    <div class="persona" data-id="mystic">
      <img src="/images/kelly-mystic-thumb.png" alt="The Mystic">
      <h4>The Mystic</h4>
      <p>Deep meaning</p>
    </div>
    
    <div class="persona" data-id="provider">
      <img src="/images/kelly-provider-thumb.png" alt="The Provider">
      <h4>The Provider</h4>
      <p>Care and nurture</p>
    </div>
    
    <div class="persona" data-id="storyteller">
      <img src="/images/kelly-storyteller-thumb.png" alt="The Storyteller">
      <h4>The Storyteller</h4>
      <p>Narrative magic</p>
    </div>
    
    <div class="persona" data-id="strategist">
      <img src="/images/kelly-strategist-thumb.png" alt="The Strategist">
      <h4>The Strategist</h4>
      <p>Long-game thinking</p>
    </div>
    
    <div class="persona" data-id="survivor">
      <img src="/images/kelly-survivor-thumb.png" alt="The Survivor">
      <h4>The Survivor</h4>
      <p>Hard-won wisdom</p>
    </div>
  </div>
  
  <a href="/quiz" class="btn-secondary">Take the Quiz →</a>
</section>
```

---

## PART 6: FOR EVERY AGE

### Design
```
┌─────────────────────────────────────────────────────────────┐
│                                                              │
│                   For Ages 2 to 102                          │
│                                                              │
│     ┌─────────────────────────────────────────────────┐     │
│     │                                                  │     │
│     │  [Age Slider: 2 ──────●────────────────── 102]  │     │
│     │                                                  │     │
│     │  ┌──────────┐                                   │     │
│     │  │  Kelly   │  "For a 35-year-old learner,     │     │
│     │  │  Adult   │   Kelly speaks as a peer.        │     │
│     │  │          │   Full vocabulary. Real-world    │     │
│     │  └──────────┘   examples. No fluff."           │     │
│     │                                                  │     │
│     └─────────────────────────────────────────────────┘     │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

### Code

```html
<section class="every-age">
  <h2>For Ages 2 to 102</h2>
  
  <div class="age-demo">
    <div class="age-slider-container">
      <input 
        type="range" 
        id="demo-age-slider" 
        min="2" 
        max="102" 
        value="35"
      >
      <div class="age-labels">
        <span>2</span>
        <span>25</span>
        <span>50</span>
        <span>75</span>
        <span>102</span>
      </div>
    </div>
    
    <div class="age-preview">
      <img 
        id="demo-kelly-image" 
        src="/images/kelly-adult.png" 
        alt="Kelly for your age"
      >
      <div class="age-description">
        <h3 id="demo-age-bucket">Adult Learner</h3>
        <p id="demo-age-text">
          Kelly speaks as a peer. Full vocabulary. 
          Real-world examples. No fluff.
        </p>
      </div>
    </div>
  </div>
</section>

<script>
const ageDescriptions = {
  kid: {
    title: "Young Explorer",
    text: "Kelly uses wonder and play. Simple words. Big excitement. Learning feels like magic.",
    image: "/images/kelly-kid.png"
  },
  teen: {
    title: "Teen Learner", 
    text: "Kelly respects your intelligence. Relevant examples. Real talk. No lectures.",
    image: "/images/kelly-teen.png"
  },
  adult: {
    title: "Adult Learner",
    text: "Kelly speaks as a peer. Full vocabulary. Real-world examples. No fluff.",
    image: "/images/kelly-adult.png"
  },
  elder: {
    title: "Wise Learner",
    text: "Kelly honors your experience. Legacy focus. Meaning over trivia. Warm pace.",
    image: "/images/kelly-elder.png"
  },
  super_elder: {
    title: "Life Master",
    text: "Kelly connects to your vast experience. Big picture. Deep wisdom. Profound respect.",
    image: "/images/kelly-super-elder.png"
  }
};

document.getElementById('demo-age-slider').addEventListener('input', (e) => {
  const age = parseInt(e.target.value);
  let bucket;
  
  if (age <= 12) bucket = 'kid';
  else if (age <= 17) bucket = 'teen';
  else if (age <= 49) bucket = 'adult';
  else if (age <= 75) bucket = 'elder';
  else bucket = 'super_elder';
  
  const desc = ageDescriptions[bucket];
  document.getElementById('demo-kelly-image').src = desc.image;
  document.getElementById('demo-age-bucket').textContent = desc.title;
  document.getElementById('demo-age-text').textContent = desc.text;
});
</script>
```

---

## PART 7: WHAT YOU'LL LEARN

### Design
```
┌─────────────────────────────────────────────────────────────┐
│                                                              │
│                 365 Days of Wonder                           │
│                                                              │
│     ┌─────────────────────────────────────────────────┐     │
│     │ Month 1: Foundations                            │     │
│     │ Day 1: Starting Fresh                           │     │
│     │ Day 2: The Power of Questions                   │     │
│     │ Day 3: How Memory Works                         │     │
│     │ ...                                             │     │
│     └─────────────────────────────────────────────────┘     │
│                                                              │
│     ┌─────────────────────────────────────────────────┐     │
│     │ Month 2: The Body                               │     │
│     │ Day 32: Your Amazing Heart                      │     │
│     │ Day 33: Why You Sleep                           │     │
│     │ ...                                             │     │
│     └─────────────────────────────────────────────────┘     │
│                                                              │
│     [See Full Curriculum →]                                  │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

### Code

```html
<section class="curriculum-preview">
  <h2>365 Days of Wonder</h2>
  
  <div class="month-previews">
    <div class="month-card">
      <h3>Month 1: Foundations</h3>
      <ul>
        <li><span class="day">Day 1</span> Starting Fresh</li>
        <li><span class="day">Day 2</span> The Power of Questions</li>
        <li><span class="day">Day 3</span> How Memory Works</li>
        <li class="more">+ 28 more lessons</li>
      </ul>
    </div>
    
    <div class="month-card">
      <h3>Month 2: The Body</h3>
      <ul>
        <li><span class="day">Day 32</span> Your Amazing Heart</li>
        <li><span class="day">Day 33</span> Why You Sleep</li>
        <li><span class="day">Day 34</span> The Gut-Brain Connection</li>
        <li class="more">+ 25 more lessons</li>
      </ul>
    </div>
    
    <div class="month-card">
      <h3>Month 3: The Mind</h3>
      <ul>
        <li><span class="day">Day 60</span> How Habits Form</li>
        <li><span class="day">Day 61</span> The Science of Creativity</li>
        <li><span class="day">Day 62</span> Why We Procrastinate</li>
        <li class="more">+ 28 more lessons</li>
      </ul>
    </div>
  </div>
  
  <a href="/curriculum" class="btn-secondary">See Full Curriculum →</a>
</section>
```

---

## PART 8: PRICING

### Design
```
┌─────────────────────────────────────────────────────────────┐
│                                                              │
│                  Simple Pricing                              │
│                                                              │
│     ┌───────────┐  ┌───────────────┐  ┌───────────┐        │
│     │  Monthly  │  │    Yearly     │  │ Lifetime  │        │
│     │           │  │   BEST VALUE  │  │           │        │
│     │  $9.99    │  │    $79.99     │  │  $199.99  │        │
│     │  /month   │  │    /year      │  │  one-time │        │
│     │           │  │               │  │           │        │
│     │  Cancel   │  │  Save 33%     │  │  Forever  │        │
│     │  anytime  │  │  $6.67/mo     │  │  access   │        │
│     │           │  │               │  │           │        │
│     │  [Start]  │  │   [Start]     │  │  [Start]  │        │
│     └───────────┘  └───────────────┘  └───────────┘        │
│                                                              │
│     ✓ All 365 lessons  ✓ All 12 Kellys  ✓ Offline mode     │
│                                                              │
│     Day 1 is always free. No credit card required.          │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

### Code

```html
<section class="pricing" id="pricing">
  <h2>Simple Pricing</h2>
  
  <div class="pricing-cards">
    <div class="pricing-card">
      <h3>Monthly</h3>
      <div class="price">
        <span class="amount">$9.99</span>
        <span class="period">/month</span>
      </div>
      <p class="detail">Cancel anytime</p>
      <a href="/learn.html?plan=monthly" class="btn-secondary">Start Monthly</a>
    </div>
    
    <div class="pricing-card featured">
      <div class="badge">Best Value</div>
      <h3>Yearly</h3>
      <div class="price">
        <span class="amount">$79.99</span>
        <span class="period">/year</span>
      </div>
      <p class="detail">Save 33% — just $6.67/mo</p>
      <a href="/learn.html?plan=yearly" class="btn-primary">Start Yearly</a>
    </div>
    
    <div class="pricing-card">
      <h3>Lifetime</h3>
      <div class="price">
        <span class="amount">$199.99</span>
        <span class="period">one-time</span>
      </div>
      <p class="detail">Forever access</p>
      <a href="/learn.html?plan=lifetime" class="btn-secondary">Get Lifetime</a>
    </div>
  </div>
  
  <ul class="pricing-features">
    <li>✓ All 365 lessons</li>
    <li>✓ All 12 Kellys</li>
    <li>✓ Offline mode</li>
    <li>✓ Family sharing (coming soon)</li>
  </ul>
  
  <p class="pricing-note">
    Day 1 is always free. No credit card required.
  </p>
</section>
```

---

## PART 9: FAQ

```html
<section class="faq" id="faq">
  <h2>Questions?</h2>
  
  <div class="faq-list">
    <details class="faq-item">
      <summary>What is Curious Kelly?</summary>
      <p>Curious Kelly is a daily learning companion that delivers one beautiful micro-lesson every day. Kelly is an AI teacher who adapts her teaching style to match your personality and age.</p>
    </details>
    
    <details class="faq-item">
      <summary>Who is Kelly named after?</summary>
      <p>Kelly is named after a real person — a Deaf teacher who teaches ASL. The digital Kelly honors her legacy by making education accessible and personal for everyone.</p>
    </details>
    
    <details class="faq-item">
      <summary>What ages is this for?</summary>
      <p>Kelly is designed for learners ages 2 to 102. She transforms her appearance, vocabulary, and teaching style to match each learner's age.</p>
    </details>
    
    <details class="faq-item">
      <summary>How long is each lesson?</summary>
      <p>Each lesson is approximately 5 minutes — perfect for daily learning without overwhelming your schedule.</p>
    </details>
    
    <details class="faq-item">
      <summary>Can I change my Kelly?</summary>
      <p>Absolutely! Go to Settings → Your Kelly → Change Kelly to pick a new persona anytime. Try them all!</p>
    </details>
    
    <details class="faq-item">
      <summary>Is there a free trial?</summary>
      <p>Day 1 is completely free, no credit card required. Experience Kelly before you commit.</p>
    </details>
    
    <details class="faq-item">
      <summary>Does Kelly work offline?</summary>
      <p>Partially. The app shell and your current lesson work offline. New lessons require an internet connection.</p>
    </details>
    
    <details class="faq-item">
      <summary>Is my data private?</summary>
      <p>Yes. We collect minimal data and never sell it. Kelly is COPPA-compliant for learners under 13.</p>
    </details>
    
    <details class="faq-item">
      <summary>Will Kelly support sign language?</summary>
      <p>Yes! ASL support is coming in early 2026. Since Kelly is named after a Deaf teacher, accessibility is core to our mission.</p>
    </details>
    
    <details class="faq-item">
      <summary>Can I get a refund?</summary>
      <p>Yes. Contact support within 14 days for a full refund, no questions asked.</p>
    </details>
  </div>
</section>
```

---

## PART 10: FOOTER

```html
<footer class="footer">
  <div class="footer-content">
    <div class="footer-brand">
      <img src="/images/logo.svg" alt="Curious Kelly" class="footer-logo">
      <p>The teacher you never knew you needed.</p>
    </div>
    
    <div class="footer-links">
      <div class="footer-column">
        <h4>Product</h4>
        <a href="/learn.html">Start Learning</a>
        <a href="/curriculum">Curriculum</a>
        <a href="#pricing">Pricing</a>
        <a href="/quiz">Find Your Kelly</a>
      </div>
      
      <div class="footer-column">
        <h4>Company</h4>
        <a href="/about">About Us</a>
        <a href="/blog">Blog</a>
        <a href="/careers">Careers</a>
        <a href="/press">Press</a>
      </div>
      
      <div class="footer-column">
        <h4>Support</h4>
        <a href="/help">Help Center</a>
        <a href="/contact">Contact Us</a>
        <a href="#faq">FAQ</a>
        <a href="/status">System Status</a>
      </div>
      
      <div class="footer-column">
        <h4>Legal</h4>
        <a href="/privacy">Privacy Policy</a>
        <a href="/terms">Terms of Service</a>
        <a href="/coppa">COPPA Notice</a>
        <a href="/accessibility">Accessibility</a>
      </div>
    </div>
  </div>
  
  <div class="footer-bottom">
    <p>© 2025 Curious Kelly. Made with 💜 for curious minds everywhere.</p>
    
    <div class="footer-social">
      <a href="https://twitter.com/curiouskelly" aria-label="Twitter">
        <svg>...</svg>
      </a>
      <a href="https://instagram.com/curiouskelly" aria-label="Instagram">
        <svg>...</svg>
      </a>
      <a href="https://tiktok.com/@curiouskelly" aria-label="TikTok">
        <svg>...</svg>
      </a>
    </div>
    
    <div class="app-badges">
      <a href="https://apps.apple.com/app/curious-kelly">
        <img src="/images/app-store-badge.svg" alt="Download on App Store">
      </a>
      <a href="https://play.google.com/store/apps/details?id=com.curiouskelly.app">
        <img src="/images/google-play-badge.svg" alt="Get it on Google Play">
      </a>
    </div>
  </div>
</footer>
```

---

## PART 11: SEO PAGES TO CREATE

| Page | URL | Purpose |
|------|-----|---------|
| Curriculum | /curriculum | Full 365-day topic list |
| Quiz | /quiz | "Find Your Kelly" personality quiz |
| About | /about | Company story, team, mission |
| Privacy | /privacy | Privacy policy |
| Terms | /terms | Terms of service |
| COPPA | /coppa | Children's privacy notice |
| Help | /help | FAQ + support articles |
| Blog | /blog | Content marketing |
| Affiliates | /affiliates | Affiliate program (v1.3) |

---

## PART 12: IMPLEMENTATION CHECKLIST

### Assets Needed

```
/images/
├── logo.svg
├── logo-white.svg
├── og-image.jpg (1200×630)
├── twitter-card.jpg (1200×600)
├── hero-poster.jpg
├── kelly-kid.png
├── kelly-teen.png
├── kelly-adult.png
├── kelly-elder.png
├── kelly-super-elder.png
├── kelly-scientist-thumb.png
├── kelly-explorer-thumb.png
├── ... (all 12 personas)
├── app-store-badge.svg
└── google-play-badge.svg

/videos/
└── kelly-preview.mp4 (15s loop, <5MB)
```

### Code Tasks

```
[ ] Replace current index.html with new structure
[ ] Create /styles/index.css with mobile-first styles
[ ] Add age slider interactivity
[ ] Add persona hover previews
[ ] Add FAQ accordion
[ ] Connect pricing buttons to learn.html
[ ] Add analytics tracking
[ ] Test all breakpoints (320px → 1920px)
[ ] Lighthouse audit (target: 90+ all categories)
[ ] Accessibility audit (WCAG 2.1 AA)
```

---

## PART 13: CONVERSION OPTIMIZATION

### A/B Test Ideas

| Test | Variant A | Variant B |
|------|-----------|-----------|
| Hero CTA | "Start Learning — Free" | "Meet Kelly" |
| Social proof | "10,000+ learners" | "★★★★★ 4.9 rating" |
| Pricing default | Monthly highlighted | Yearly highlighted |
| Hero media | Video autoplay | Static image |

### Tracking Events

```javascript
// Key conversion events
analytics.track('page_view', { page: 'index' });
analytics.track('cta_click', { cta: 'hero_start' });
analytics.track('persona_hover', { persona: 'scientist' });
analytics.track('age_slider_interact', { age: 35 });
analytics.track('pricing_view', {});
analytics.track('pricing_click', { plan: 'yearly' });
analytics.track('faq_expand', { question: 'what_is_kelly' });
```

---

## PART 14: MOBILE OPTIMIZATION

```css
/* Mobile-first approach */

/* Base: Mobile (320px+) */
.hero {
  flex-direction: column;
  padding: 24px 16px;
}

.hero-content h1 {
  font-size: 28px;
}

.persona-grid {
  grid-template-columns: repeat(2, 1fr);
  gap: 16px;
}

.pricing-cards {
  flex-direction: column;
  gap: 24px;
}

/* Tablet (768px+) */
@media (min-width: 768px) {
  .hero {
    flex-direction: row;
  }
  
  .persona-grid {
    grid-template-columns: repeat(4, 1fr);
  }
  
  .pricing-cards {
    flex-direction: row;
  }
}

/* Desktop (1024px+) */
@media (min-width: 1024px) {
  .hero-content h1 {
    font-size: 48px;
  }
  
  .persona-grid {
    grid-template-columns: repeat(6, 1fr);
  }
}
```

---

## SUCCESS METRICS

| Metric | Target |
|--------|--------|
| Bounce rate | < 40% |
| Time on page | > 2 minutes |
| Scroll depth | > 75% reach pricing |
| CTA click rate | > 10% |
| Mobile conversion | = Desktop conversion |

---

*Index.html Directive for Curious Kelly*
*December 2025*
*"The front door to Kelly's world."*
