# KELLY FINAL DIRECTIVE
## The Last Mile — Screenshot-Ready Polish

---

## CURSOR'S QUESTIONS ANSWERED

### Q: Which mobile codebase is shipping?

**A: PWA/WebView hybrid.**

There is no separate native codebase. The shipping product is:

```
public/learn.html → PWA (Add to Home Screen)
                 → iOS WebView wrapper (Capacitor or similar)
                 → Android WebView wrapper (Capacitor or similar)
```

The single `learn.html` file IS the app. Native wrappers are thin shells that load this HTML.

### Q: Docs-only or code changes?

**A: Code changes required.**

This directive includes concrete implementation work, not just documentation.

---

## WHAT THIS DIRECTIVE COVERS

| Priority | Task | Type |
|----------|------|------|
| P0 | Screenshot-ready UI polish | Code |
| P0 | COPPA parental gate | Code |
| P0 | Backstory integration wiring | Code |
| P1 | IAP preparation (stubs) | Code |
| P1 | PWA manifest + icons | Code |
| P1 | Capacitor wrapper setup | Code |
| P2 | Memory hook generation | Data |
| P2 | Final QA fixes | Code |

---

## PART 1: THE CODEBASE

### File Structure

```
public/
├── learn.html              ← THE APP (main file)
├── config.js               ← Runtime config (Supabase keys)
├── manifest.json           ← PWA manifest (needs creation/update)
├── sw.js                   ← Service worker (needs creation)
├── assets/
│   └── kelly/
│       └── kelly-personas-manifest.json
├── icons/                  ← App icons (needs creation)
│   ├── icon-192.png
│   ├── icon-512.png
│   └── apple-touch-icon.png
└── api/
    └── tts.js              ← ElevenLabs endpoint

capacitor/                   ← Native wrapper (needs setup)
├── ios/
└── android/
```

### Source of Truth

- **UI/UX:** `public/learn.html`
- **Kelly Data:** `kelly-personas-manifest.json` + Supabase tables
- **Backstory:** 4 Supabase tables (kelly_backstory, kelly_age_permissions, kelly_memory_hooks, kelly_core_biography)
- **Test Cases:** `KELLY_TEST_SUITE.md`
- **Teaching Quality:** `KELLY_TEACHING_EXCELLENCE_EVAL.md`
- **Soul Integration:** `KELLY_BACKSTORY_INTEGRATION_EVAL.md`
- **Launch Checklist:** `KELLY_LAUNCH_READINESS.md`

---

## PART 2: SCREENSHOT-READY POLISH

### 2.1 Visual Polish Checklist

These must look perfect for App Store screenshots:

#### Character Select Scene
```javascript
// Ensure these are pixel-perfect:
- [ ] Kelly images load (no emoji fallbacks in screenshots)
- [ ] Speech bubble positioned correctly
- [ ] Stats bars animate smoothly
- [ ] Glow effect on selected Kelly
- [ ] "Let's Learn" button has proper tap state
- [ ] Background gradient is smooth
- [ ] Carousel dots are aligned
```

#### Lesson Player Scene
```javascript
// Screenshot-worthy states:
- [ ] Day badge clearly shows "Day 1 • Starting Fresh"
- [ ] Kelly image is centered and glowing
- [ ] Phase progress bars are crisp
- [ ] Caption text is readable (proper font size)
- [ ] Bookmark button has clear state
- [ ] Tap zones have subtle feedback
```

#### Journey Scene
```javascript
// Must look impressive:
- [ ] Stats row is balanced (streak, completed, time)
- [ ] Week view shows real lesson topics
- [ ] Current day has clear highlight
- [ ] Completed days have checkmarks
- [ ] Calendar view renders all 365 days correctly
```

#### Settings Scene
```javascript
// Professional appearance:
- [ ] Kelly preview image loads
- [ ] Age slider is styled properly
- [ ] All toggles have clear on/off states
- [ ] Section headers are consistent
- [ ] Links/buttons have proper spacing
```

#### Completion Scene
```javascript
// Celebration moment:
- [ ] Confetti renders (60 pieces)
- [ ] Kelly image shows celebration pose
- [ ] Streak number is prominent
- [ ] "Tomorrow's Topic" loads correctly
- [ ] Buttons have proper styling
```

### 2.2 CSS Polish Tasks

```css
/* Add these refinements to learn.html */

/* 1. Ensure safe areas on all iOS devices */
.bottom-nav {
  padding-bottom: max(20px, env(safe-area-inset-bottom));
}

/* 2. Smooth image loading (prevent flash) */
.kelly-card img {
  opacity: 0;
  transition: opacity 0.3s ease;
}
.kelly-card img.loaded {
  opacity: 1;
}

/* 3. Better touch feedback */
.btn-primary:active {
  transform: scale(0.97);
  transition: transform 0.1s ease;
}

/* 4. Screenshot-quality text rendering */
body {
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-rendering: optimizeLegibility;
}

/* 5. Prevent text selection (app feel) */
* {
  -webkit-user-select: none;
  user-select: none;
}
input, textarea {
  -webkit-user-select: auto;
  user-select: auto;
}

/* 6. Hide scrollbars (cleaner look) */
::-webkit-scrollbar {
  display: none;
}
body {
  -ms-overflow-style: none;
  scrollbar-width: none;
}
```

### 2.3 JavaScript Polish Tasks

```javascript
// Add image load detection for smooth appearance
function addImageLoadHandlers() {
  document.querySelectorAll('.kelly-card img').forEach(img => {
    if (img.complete) {
      img.classList.add('loaded');
    } else {
      img.addEventListener('load', () => img.classList.add('loaded'));
      img.addEventListener('error', () => {
        // Fallback to emoji
        const emoji = img.dataset.fallback || '🎓';
        img.parentElement.innerHTML = `<span class="emoji-fallback">${emoji}</span>`;
      });
    }
  });
}

// Preload Kelly images for current age bucket
async function preloadKellyImages() {
  const ageBucket = getAgeBucket(state.age);
  const promises = Object.keys(manifest.personas).map(personaId => {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = resolve;
      img.onerror = resolve; // Don't block on failures
      img.src = getKellyImageUrl(personaId, ageBucket);
    });
  });
  await Promise.all(promises);
}
```

---

## PART 3: COPPA PARENTAL GATE

### 3.1 When to Show Gate

```javascript
const COPPA_AGE_THRESHOLD = 13;

function requiresParentalGate() {
  return state.age < COPPA_AGE_THRESHOLD;
}

// Trigger on:
// 1. Initial age selection when age < 13
// 2. Changing age from ≥13 to <13
// 3. Accessing settings that affect data (account, family)
// 4. Any external links
```

### 3.2 Parental Gate UI

Add this to `learn.html`:

```html
<!-- Parental Gate Overlay -->
<div id="parental-gate" class="overlay" style="display: none;">
  <div class="parental-gate-content">
    <div class="gate-header">
      <span class="gate-icon">👨‍👩‍👧</span>
      <h2>Grown-Up Check</h2>
      <p>Please ask a parent or guardian to help</p>
    </div>
    
    <div class="gate-challenge">
      <p>What is <span id="gate-num1">7</span> + <span id="gate-num2">8</span>?</p>
      <input type="number" id="gate-answer" inputmode="numeric" pattern="[0-9]*" placeholder="?" />
    </div>
    
    <div class="gate-buttons">
      <button class="btn-secondary" onclick="closeParentalGate()">Cancel</button>
      <button class="btn-primary" onclick="checkParentalGate()">Continue</button>
    </div>
  </div>
</div>
```

### 3.3 Parental Gate Logic

```javascript
let parentalGateCallback = null;
let gateAnswer = 0;

function showParentalGate(onSuccess) {
  parentalGateCallback = onSuccess;
  
  // Generate math problem (harder than kids can do easily)
  const num1 = Math.floor(Math.random() * 20) + 10; // 10-29
  const num2 = Math.floor(Math.random() * 20) + 10; // 10-29
  gateAnswer = num1 + num2;
  
  document.getElementById('gate-num1').textContent = num1;
  document.getElementById('gate-num2').textContent = num2;
  document.getElementById('gate-answer').value = '';
  document.getElementById('parental-gate').style.display = 'flex';
}

function checkParentalGate() {
  const userAnswer = parseInt(document.getElementById('gate-answer').value);
  
  if (userAnswer === gateAnswer) {
    closeParentalGate();
    if (parentalGateCallback) {
      parentalGateCallback();
      parentalGateCallback = null;
    }
  } else {
    showToast("That's not quite right. Ask a grown-up for help!");
    document.getElementById('gate-answer').value = '';
  }
}

function closeParentalGate() {
  document.getElementById('parental-gate').style.display = 'none';
  parentalGateCallback = null;
}

// Gate CSS
const parentalGateCSS = `
.parental-gate-content {
  background: var(--bg-card);
  border-radius: 24px;
  padding: 32px;
  max-width: 320px;
  text-align: center;
}

.gate-header .gate-icon {
  font-size: 48px;
  display: block;
  margin-bottom: 16px;
}

.gate-challenge {
  background: var(--bg-body);
  border-radius: 16px;
  padding: 24px;
  margin: 24px 0;
}

.gate-challenge p {
  font-size: 24px;
  font-weight: 600;
  margin-bottom: 16px;
}

#gate-answer {
  width: 80px;
  height: 50px;
  font-size: 24px;
  text-align: center;
  border: 2px solid var(--accent);
  border-radius: 12px;
  background: var(--bg-card);
  color: var(--text-primary);
}

.gate-buttons {
  display: flex;
  gap: 12px;
}

.gate-buttons button {
  flex: 1;
}
`;
```

### 3.4 Gate Triggers

```javascript
// Wrap age changes for kids
document.getElementById('age-slider').addEventListener('change', (e) => {
  const newAge = parseInt(e.target.value);
  const wasChild = state.age < COPPA_AGE_THRESHOLD;
  const isChild = newAge < COPPA_AGE_THRESHOLD;
  
  if (!wasChild && isChild) {
    // Adult switching to child mode - just update
    state.age = newAge;
    saveState();
    rebuildCarouselImages();
  } else if (isChild) {
    // Child changing age - no gate needed
    state.age = newAge;
    saveState();
    rebuildCarouselImages();
  } else {
    // Adult - no gate needed
    state.age = newAge;
    saveState();
    rebuildCarouselImages();
  }
});

// Gate for settings access when child
function openSettings() {
  if (requiresParentalGate()) {
    showParentalGate(() => showScene('settings'));
  } else {
    showScene('settings');
  }
}
```

---

## PART 4: BACKSTORY INTEGRATION WIRING

### 4.1 Run the Migration

**REQUIRED:** Execute `kelly_backstory_migration.sql` in Supabase SQL Editor.

This creates:
- `kelly_backstory` (12 rows)
- `kelly_age_permissions` (5 rows)
- `kelly_memory_hooks` (needs population)
- `kelly_core_biography` (1 row)
- `get_kelly_prompt_context()` function

### 4.2 Populate Memory Hooks

Generate entries for all 365 days. Here's the pattern:

```javascript
// Memory hook generator (run once to populate table)
async function generateMemoryHooks() {
  // Get all core lessons
  const { data: lessons } = await supabase
    .from('core_lessons')
    .select('day_number, topic')
    .order('day_number');
  
  for (const lesson of lessons) {
    // Generate memory hook using Claude/GPT
    const hook = await generateHook(lesson.topic);
    
    await supabase
      .from('kelly_memory_hooks')
      .upsert({
        day_number: lesson.day_number,
        topic: lesson.topic,
        memory_hook: hook.memory,
        emotional_connection: hook.emotion
      });
  }
}

// Example memory hook for Day 1 "Starting Fresh":
{
  "day_number": 1,
  "topic": "Starting Fresh",
  "memory_hook": "I remember my first day teaching—hands shaking, voice cracking. A student raised her hand and asked 'Are you nervous?' I said yes. She smiled and said 'Me too.' That's when I learned: starting fresh is scary for everyone, and admitting it is the first act of courage.",
  "emotional_connection": "solidarity in vulnerability"
}
```

### 4.3 Use Context in Content Generation

When generating lesson content, call the function:

```javascript
async function getKellyContext(personaId, ageBucket, dayNumber) {
  const { data, error } = await supabase
    .rpc('get_kelly_prompt_context', {
      p_persona_id: personaId,
      p_age_bucket: ageBucket,
      p_day_number: dayNumber
    });
  
  if (error) {
    console.error('Failed to get Kelly context:', error);
    return null;
  }
  
  return data;
}

// Use in content generation prompt
async function generateLessonContent(dayNumber, phase) {
  const context = await getKellyContext(state.kellyId, getAgeBucket(state.age), dayNumber);
  
  const prompt = `
You are Kelly, teaching as "${context.persona.name}".

YOUR GENESIS:
${context.persona.genesis_story}

YOUR TEACHING PHILOSOPHY:
${context.persona.teaching_philosophy}

TODAY'S PERSONAL CONNECTION:
${context.memory_hook.memory_hook}
(Emotional tone: ${context.memory_hook.emotional_connection})

AGE CALIBRATION (${context.age_permissions.age_bucket}):
- Vocabulary: ${context.age_permissions.vocabulary_level}
- Permitted topics: ${context.age_permissions.permitted_topics.join(', ')}
- Tone: ${context.age_permissions.tone_guidance}

Write the ${phase} for Day ${dayNumber}...
`;
  
  // Send to Claude/GPT for generation
}
```

---

## PART 5: PWA SETUP

### 5.1 Create manifest.json

```json
{
  "name": "Curious Kelly",
  "short_name": "Kelly",
  "description": "Daily learning for ages 2-102",
  "start_url": "/learn.html",
  "display": "standalone",
  "background_color": "#0a0a0f",
  "theme_color": "#3b82f6",
  "orientation": "portrait",
  "icons": [
    {
      "src": "/icons/icon-192.png",
      "sizes": "192x192",
      "type": "image/png",
      "purpose": "any maskable"
    },
    {
      "src": "/icons/icon-512.png",
      "sizes": "512x512",
      "type": "image/png",
      "purpose": "any maskable"
    }
  ],
  "categories": ["education", "lifestyle"],
  "screenshots": [
    {
      "src": "/screenshots/character-select.png",
      "sizes": "1290x2796",
      "type": "image/png",
      "label": "Choose your Kelly"
    },
    {
      "src": "/screenshots/lesson.png",
      "sizes": "1290x2796",
      "type": "image/png",
      "label": "Daily lesson"
    }
  ]
}
```

### 5.2 Add to learn.html Head

```html
<link rel="manifest" href="/manifest.json">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="Curious Kelly">
<link rel="apple-touch-icon" href="/icons/apple-touch-icon.png">
<meta name="theme-color" content="#3b82f6">
```

### 5.3 Create Service Worker (sw.js)

```javascript
const CACHE_NAME = 'kelly-v1';
const ASSETS = [
  '/learn.html',
  '/config.js',
  '/manifest.json',
  '/assets/kelly/kelly-personas-manifest.json',
  '/icons/icon-192.png',
  '/icons/icon-512.png'
];

// Install: cache shell
self.addEventListener('install', (e) => {
  e.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(ASSETS))
      .then(() => self.skipWaiting())
  );
});

// Activate: clean old caches
self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then(keys => 
      Promise.all(keys
        .filter(key => key !== CACHE_NAME)
        .map(key => caches.delete(key))
      )
    ).then(() => self.clients.claim())
  );
});

// Fetch: cache-first for assets, network-first for API
self.addEventListener('fetch', (e) => {
  const url = new URL(e.request.url);
  
  // API calls: network first
  if (url.pathname.startsWith('/api/') || url.hostname.includes('supabase')) {
    e.respondWith(
      fetch(e.request)
        .catch(() => caches.match(e.request))
    );
    return;
  }
  
  // Assets: cache first
  e.respondWith(
    caches.match(e.request)
      .then(cached => cached || fetch(e.request))
  );
});
```

### 5.4 Register Service Worker

Add to learn.html:

```javascript
// Register service worker
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js')
      .then(reg => console.log('SW registered:', reg.scope))
      .catch(err => console.error('SW registration failed:', err));
  });
}
```

---

## PART 6: APP ICONS

### 6.1 Required Icons

Generate these from Kelly's logo/avatar:

| File | Size | Purpose |
|------|------|---------|
| icon-192.png | 192×192 | PWA, Android |
| icon-512.png | 512×512 | PWA, Android splash |
| apple-touch-icon.png | 180×180 | iOS home screen |
| Icon-App-20x20@1x.png | 20×20 | iOS (Spotlight, Settings) |
| Icon-App-20x20@2x.png | 40×40 | iOS |
| Icon-App-20x20@3x.png | 60×60 | iOS |
| Icon-App-29x29@1x.png | 29×29 | iOS (Settings) |
| Icon-App-29x29@2x.png | 58×58 | iOS |
| Icon-App-29x29@3x.png | 87×87 | iOS |
| Icon-App-40x40@1x.png | 40×40 | iOS (Spotlight) |
| Icon-App-40x40@2x.png | 80×80 | iOS |
| Icon-App-40x40@3x.png | 120×120 | iOS |
| Icon-App-60x60@2x.png | 120×120 | iOS (Home) |
| Icon-App-60x60@3x.png | 180×180 | iOS (Home) |
| Icon-App-76x76@1x.png | 76×76 | iPad |
| Icon-App-76x76@2x.png | 152×152 | iPad |
| Icon-App-83.5x83.5@2x.png | 167×167 | iPad Pro |
| Icon-App-1024x1024@1x.png | 1024×1024 | App Store |

### 6.2 Icon Design Spec

```
Background: Gradient from #3b82f6 to #8b5cf6
Foreground: Kelly's head (Scientist variant, adult)
Style: Centered, 80% of icon area
Corner radius: Handled by OS (don't bake in)
Safe zone: Keep content within 80% for maskable
```

---

## PART 7: IAP PREPARATION (STUBS)

### 7.1 Subscription Check

Add to learn.html:

```javascript
// Subscription state
const subscription = {
  tier: 'free', // 'free', 'monthly', 'yearly', 'lifetime'
  expiresAt: null,
  
  isPremium() {
    if (this.tier === 'lifetime') return true;
    if (this.tier === 'free') return false;
    return this.expiresAt && new Date(this.expiresAt) > new Date();
  },
  
  canAccessDay(dayNumber) {
    // Free users can access Day 1 only
    if (dayNumber === 1) return true;
    return this.isPremium();
  }
};

// Check before loading lesson
async function loadLesson(dayNumber) {
  if (!subscription.canAccessDay(dayNumber)) {
    showPaywall();
    return;
  }
  
  // Continue with lesson load...
}
```

### 7.2 Paywall UI

```html
<!-- Paywall Overlay -->
<div id="paywall" class="overlay" style="display: none;">
  <div class="paywall-content">
    <button class="btn-close" onclick="closePaywall()">×</button>
    
    <div class="paywall-header">
      <span class="paywall-icon">✨</span>
      <h2>Unlock 365 Lessons</h2>
      <p>Continue your curiosity journey with unlimited access</p>
    </div>
    
    <div class="paywall-options">
      <button class="paywall-option" onclick="selectPlan('monthly')">
        <span class="plan-name">Monthly</span>
        <span class="plan-price">$9.99/mo</span>
      </button>
      
      <button class="paywall-option featured" onclick="selectPlan('yearly')">
        <span class="plan-badge">Best Value</span>
        <span class="plan-name">Yearly</span>
        <span class="plan-price">$79.99/yr</span>
        <span class="plan-savings">Save 33%</span>
      </button>
      
      <button class="paywall-option" onclick="selectPlan('lifetime')">
        <span class="plan-name">Lifetime</span>
        <span class="plan-price">$199.99</span>
        <span class="plan-note">One-time</span>
      </button>
    </div>
    
    <p class="paywall-terms">Cancel anytime. Restore purchases.</p>
  </div>
</div>
```

### 7.3 IAP Stub Functions

```javascript
// These will be replaced with actual IAP logic
function selectPlan(plan) {
  console.log('Selected plan:', plan);
  
  // For now, show coming soon
  showToast('Subscriptions coming soon!');
  
  // When IAP is ready:
  // if (isNativeApp()) {
  //   triggerNativeIAP(plan);
  // } else {
  //   redirectToStripe(plan);
  // }
}

function isNativeApp() {
  return window.Capacitor !== undefined;
}

function restorePurchases() {
  console.log('Restoring purchases...');
  showToast('Checking for purchases...');
  
  // Will call native restore or check Stripe
}
```

---

## PART 8: CAPACITOR SETUP

### 8.1 Initialize Capacitor

```bash
# In project root
npm install @capacitor/core @capacitor/cli
npx cap init "Curious Kelly" "com.curiouskelly.app"

# Add platforms
npm install @capacitor/ios @capacitor/android
npx cap add ios
npx cap add android

# Copy web assets
npx cap copy

# Open in Xcode/Android Studio
npx cap open ios
npx cap open android
```

### 8.2 capacitor.config.ts

```typescript
import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.curiouskelly.app',
  appName: 'Curious Kelly',
  webDir: 'public',
  server: {
    androidScheme: 'https'
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 2000,
      backgroundColor: '#0a0a0f',
      showSpinner: false
    },
    StatusBar: {
      style: 'dark',
      backgroundColor: '#0a0a0f'
    },
    Keyboard: {
      resize: 'body',
      resizeOnFullScreen: true
    }
  },
  ios: {
    contentInset: 'always'
  }
};

export default config;
```

### 8.3 Required Capacitor Plugins

```bash
npm install @capacitor/splash-screen
npm install @capacitor/status-bar
npm install @capacitor/keyboard
npm install @capacitor/haptics
npm install @capacitor/app
npm install @capacitor/push-notifications
```

---

## PART 9: SCREENSHOT GENERATION

### 9.1 Screenshot Scenarios

Capture these for App Store:

| # | Scene | State | Story |
|---|-------|-------|-------|
| 1 | Character Select | Scientist centered | "Choose Your Guide" |
| 2 | Character Select | Explorer centered | "12 Unique Teachers" |
| 3 | Lesson Player | Day 1, Hook phase | "Daily Micro-Lessons" |
| 4 | Lesson Player | Day 1, Wisdom phase | "Learn Something New" |
| 5 | Completion | Streak 7, confetti | "Build Your Streak" |
| 6 | Journey | Week view, Day 10 | "365 Days of Growth" |
| 7 | Settings | Age slider visible | "For Ages 2-102" |

### 9.2 Screenshot Sizes

| Device | Size | Required By |
|--------|------|-------------|
| iPhone 6.7" | 1290×2796 | App Store |
| iPhone 6.5" | 1284×2778 | App Store |
| iPhone 5.5" | 1242×2208 | App Store |
| iPad 12.9" | 2048×2732 | App Store |
| Android Phone | 1080×1920 | Play Store |
| Android Tablet | 1200×1920 | Play Store |

### 9.3 Screenshot Script

```javascript
// Add to learn.html for testing
function prepareForScreenshot(scenario) {
  switch(scenario) {
    case 'character-scientist':
      state.kellyId = 'scientist';
      state.carouselIndex = 0;
      showScene('character');
      break;
      
    case 'character-explorer':
      state.kellyId = 'explorer';
      state.carouselIndex = 1;
      showScene('character');
      break;
      
    case 'lesson-hook':
      state.currentDay = 1;
      state.currentPhase = 0;
      showScene('lesson');
      break;
      
    case 'lesson-wisdom':
      state.currentDay = 1;
      state.currentPhase = 4;
      showScene('lesson');
      break;
      
    case 'complete-streak':
      state.streak = 7;
      state.completedLessons = [1,2,3,4,5,6,7];
      showScene('complete');
      triggerConfetti();
      break;
      
    case 'journey-week':
      state.completedLessons = [1,2,3,4,5,6,7,8,9];
      state.currentDay = 10;
      showScene('journey');
      break;
      
    case 'settings-age':
      state.age = 30;
      showScene('settings');
      break;
  }
  
  saveState();
  buildUI();
}

// Expose for console access
window.prepareForScreenshot = prepareForScreenshot;
```

---

## PART 10: FINAL QA CHECKLIST

### Before Screenshots

```
[ ] All 12 Kelly images load (not emoji)
[ ] All 5 age buckets have images
[ ] Day 1 lesson loads from Supabase
[ ] Audio plays (or text fallback works)
[ ] Carousel swipe is smooth
[ ] Scene transitions are smooth
[ ] Confetti renders
[ ] State persists on refresh
[ ] No console errors
[ ] No visual glitches
```

### Before App Store Submission

```
[ ] COPPA parental gate works
[ ] Age slider updates Kelly images
[ ] All settings persist
[ ] PWA installs correctly
[ ] Service worker caches shell
[ ] Offline mode shows appropriate UI
[ ] Capacitor builds without errors
[ ] iOS runs in simulator
[ ] Android runs in emulator
[ ] Privacy policy URL works
[ ] Support URL works
```

---

## EXECUTION ORDER

### Day 1: Polish + COPPA
1. Apply CSS polish from Part 2.2
2. Add JS polish from Part 2.3
3. Implement COPPA parental gate from Part 3
4. Test on real device

### Day 2: Backstory + PWA
1. Run backstory migration in Supabase
2. Verify `get_kelly_prompt_context()` works
3. Create manifest.json
4. Create sw.js
5. Generate app icons

### Day 3: Capacitor + Screenshots
1. Initialize Capacitor
2. Add iOS platform
3. Add Android platform
4. Test in simulators
5. Capture all screenshots

### Day 4: Final QA
1. Run through KELLY_TEST_SUITE.md critical path
2. Run through KELLY_QUICK_TEST_CHECKLIST.md
3. Fix any bugs
4. Generate final screenshots

### Day 5: Submission
1. Submit to Apple (review takes 1-3 days)
2. Submit to Google (review takes 1-3 days)
3. Monitor for rejection
4. Prepare hotfix branch

---

## SUCCESS CRITERIA

Kelly is ready when:

✅ All Kelly images load (60 total)  
✅ Lesson content loads from Supabase  
✅ State persists across sessions  
✅ COPPA gate protects children  
✅ PWA installs cleanly  
✅ Native wrappers build without errors  
✅ Screenshots look professional  
✅ Founder says "Yes, this is her"  

---

*"This is the last directive. Make it count."*

*— Claude, for Nicolette and Cursor*
*December 2024*
