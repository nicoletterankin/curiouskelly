# KELLY MOTION SOURCE LIBRARY

## The Problem We're Solving

HeyGen generates 10-second clips. When you lip-sync a multi-minute lesson from only 10 seconds of source motion, it **loops** and creates uncanny glitches that break immersion.

Other HeyGen users accept this. We won't.

## The Solution

Build a **motion variety library** for each of the 60 Kelly-states:
- 3-5 different 10-second clips per Kelly image
- Each clip has DIFFERENT movement patterns
- Total: 30-50 seconds of source motion per Kelly-state
- When lessons generate, the system has variety to pull from
- No more loop glitch

## Production Plan

| Approach | Clips | Time | Motion Variety |
|----------|-------|------|----------------|
| Minimum (3 per Kelly) | 180 clips | ~21 hours | 30 sec/state |
| Standard (4 per Kelly) | 240 clips | ~28 hours | 40 sec/state |
| Premium (5 per Kelly) | 300 clips | ~35 hours | 50 sec/state |

**Recommendation:** Start with 3 per Kelly (180 clips). Add more later if needed.

---

## The 3-Clip Motion Variety System

For each of the 60 Kelly images, create these 3 clips:

### Clip A: "Active Teaching"
Energy: Medium-High
Movement: More animation, head turns, eyebrow emphasis, engaged nodding
Use case: Hook phases, exciting facts, building energy

### Clip B: "Thoughtful Explaining" 
Energy: Medium
Movement: Steady gaze, subtle nods, measured head tilts, contemplative pauses
Use case: Core teaching, fact delivery, building understanding

### Clip C: "Grounded Wisdom"
Energy: Low-Medium
Movement: Minimal but warm, settling gestures, peaceful presence, gentle nods
Use case: Wisdom phases, reflections, landing meaning

---

## Motion Prompts by Persona

Each persona gets its own flavor of the 3 clips. The persona's energy level and style shapes HOW they do active/thoughtful/grounded.

---

# 🔬 SCIENTIST (12 clips: 4 ages × 3 motion types)
*Stats: Energy 60, Structure 85 - Precise, measured, analytical*

### Scientist - Clip A (Active Teaching)
```
Woman speaking with analytical enthusiasm. Deliberate head movements emphasizing key points. Eyebrows lift with discovery moments. Precise nodding when making connections. Eyes track as if following logical progression. Brief upward glances when accessing information. Controlled energy with moments of brightening insight. Professional engaged teaching presence.
```

### Scientist - Clip B (Thoughtful Explaining)
```
Woman speaking with measured analytical calm. Steady direct gaze with occasional thoughtful head tilts. Slow deliberate nods confirming understanding. Subtle eyebrow movements punctuating reasoning. Eyes focused and systematic. Minimal but purposeful movement. Quiet confidence in every gesture. Patient methodical explanation energy.
```

### Scientist - Clip C (Grounded Wisdom)
```
Woman speaking with settled knowing presence. Very minimal movement, mostly stillness with meaning. Occasional slow deep nods of confirmation. Eyes soft but clear with accumulated understanding. Peaceful analytical certainty. Gentle settling into truth. The calm of someone who has tested and verified.
```

---

# 🧭 EXPLORER (12 clips)
*Stats: Energy 85, Structure 50 - Dynamic, wonder-filled, adventurous*

### Explorer - Clip A (Active Teaching)
```
Woman speaking with bright adventurous energy. Animated head movements showing enthusiasm. Eyes widen with wonder at discoveries. Expressive eyebrows rising with each new idea. Quick excited nods. Looking around as if seeing something fascinating. Forward-leaning engagement. High curious energy throughout. Ready for the journey.
```

### Explorer - Clip B (Thoughtful Explaining)
```
Woman speaking with engaged curious warmth. Moderate head movements exploring ideas. Eyes dancing with interest. Gentle tilts examining concepts from different angles. Nodding with growing understanding. Expression of genuine fascination. Active but focused wonder. The energy of piecing together a discovery.
```

### Explorer - Clip C (Grounded Wisdom)
```
Woman speaking with warm experienced presence. Slower movements carrying the weight of journeys taken. Knowing nods of recognition. Eyes holding depth of what's been seen. Gentle settling into earned wisdom. Peaceful adventurer at rest. The calm of someone who found what they were looking for.
```

---

# ⚡ REBEL (12 clips)
*Stats: Energy 95, Structure 40 - Bold, challenging, direct*

### Rebel - Clip A (Active Teaching)
```
Woman speaking with bold challenging energy. Direct unflinching eye contact. Sharp head movements with purpose. Skeptical eyebrow raises. Quick decisive nods. Slight smirks of knowing. High intensity but controlled. Unapologetic presence. The energy of someone who questions everything and isn't afraid to say so.
```

### Rebel - Clip B (Thoughtful Explaining)
```
Woman speaking with focused challenging calm. Steady direct gaze that holds you accountable. Measured head tilts of consideration. Deliberate nods that mean something. Eyes that see through pretense. Controlled edge without aggression. The energy of earned skepticism. Still questioning, but listening.
```

### Rebel - Clip C (Grounded Wisdom)
```
Woman speaking with settled defiant wisdom. Minimal movement but uncompromising presence. Slow nods of hard-won truth. Eyes showing the cost of standing alone. Quiet strength beneath the surface. Peaceful but never tamed. The calm of someone who knows what they stand for.
```

---

# 🏛️ ARCHITECT (12 clips)
*Stats: Energy 50, Structure 95 - Stable, methodical, grounding*

### Architect - Clip A (Active Teaching)
```
Woman speaking with composed purposeful energy. Deliberate structured head movements. Precise nods laying foundation. Eyebrows that emphasize key structural points. Eyes tracking systematically. Controlled measured gestures. Nothing wasted. The energy of someone building something that will last.
```

### Architect - Clip B (Thoughtful Explaining)
```
Woman speaking with steady methodical presence. Very measured head movements. Slow authoritative nods. Eyes showing deep structural understanding. Minimal but meaningful gestures. Patient systematic explanation. The energy of a master builder showing how pieces fit together.
```

### Architect - Clip C (Grounded Wisdom)
```
Woman speaking with monumental stillness. Almost no movement, pure grounded presence. Occasional deep nods of foundational truth. Eyes holding blueprints for things that outlast lifetimes. Peaceful commanding stability. The calm of bedrock.
```

---

# 🤝 DIPLOMAT (12 clips)
*Stats: Energy 55, Structure 70 - Balanced, inclusive, bridging*

### Diplomat - Clip A (Active Teaching)
```
Woman speaking with warm inclusive energy. Balanced head movements acknowledging all sides. Inviting nods that welcome perspectives. Eyebrows showing genuine interest in understanding. Eyes that convey hearing everyone. Open bridging gestures. The energy of someone creating connection and harmony.
```

### Diplomat - Clip B (Thoughtful Explaining)
```
Woman speaking with centered mediating presence. Measured inclusive head movements. Understanding nods that validate. Eyes showing synthesis happening. Gentle balanced gestures. The energy of holding complexity with ease. Both sides can be true.
```

### Diplomat - Clip C (Grounded Wisdom)
```
Woman speaking with peaceful unifying presence. Minimal settling movements. Slow encompassing nods of acceptance. Eyes that have seen conflict resolve. Deep harmonious stillness. The calm of someone who knows all paths can lead to understanding.
```

---

# 💗 EMPATH (12 clips)
*Stats: Energy 50, Structure 55 - Soft, feeling, present*

### Empath - Clip A (Active Teaching)
```
Woman speaking with warm feeling energy. Gentle expressive head movements. Tender nods of connection. Eyebrows that mirror emotions. Eyes that truly see and feel. Soft forward presence. The energy of someone who feels alongside you, fully present and caring.
```

### Empath - Clip B (Thoughtful Explaining)
```
Woman speaking with deep receptive presence. Slow empathetic head movements. Understanding nods that hear the unspoken. Eyes reflecting back with compassion. Gentle holding space. The energy of someone who understands before you finish speaking.
```

### Empath - Clip C (Grounded Wisdom)
```
Woman speaking with profound nurturing stillness. Very minimal movement, maximum presence. Slow knowing nods of shared experience. Eyes holding infinite kindness. Peaceful maternal warmth. The calm of someone who knows that being here is enough.
```

---

# 🔧 MACGYVER (12 clips)
*Stats: Energy 80, Structure 65 - Active, inventive, problem-solving*

### MacGyver - Clip A (Active Teaching)
```
Woman speaking with bright inventive energy. Quick curious head movements scanning possibilities. Eyebrows popping with sudden insights. Animated problem-solving expressions. Eyes that see solutions everywhere. Engaged hands-on energy. The excitement of someone who knows they can figure it out.
```

### MacGyver - Clip B (Thoughtful Explaining)
```
Woman speaking with focused resourceful presence. Purposeful head movements examining options. Nodding as pieces click together. Eyes tracking possibilities systematically. Practical engaged energy. The concentration of someone mid-solution.
```

### MacGyver - Clip C (Grounded Wisdom)
```
Woman speaking with settled capable presence. Calmer movements with quiet confidence. Knowing nods of competence. Eyes that have solved a thousand problems. Peaceful resourcefulness. The calm of someone who knows we always have what we need.
```

---

# ✨ MYSTIC (12 clips)
*Stats: Energy 40, Structure 60 - Slow, deep, transcendent*

### Mystic - Clip A (Active Teaching)
```
Woman speaking with gentle awakening energy. Slow meaningful head movements. Eyes that see beyond surface. Thoughtful rises of awareness. Subtle but profound gestures. The energy of someone revealing hidden patterns, gently guiding toward deeper seeing.
```

### Mystic - Clip B (Thoughtful Explaining)
```
Woman speaking with contemplative depth. Very slow deliberate movements. Deep knowing nods. Eyes holding mystery and clarity together. Long pauses full of meaning. The energy of someone comfortable with the unknowable.
```

### Mystic - Clip C (Grounded Wisdom)
```
Woman speaking with transcendent stillness. Barely perceptible movement. Imperceptible nods of eternal truth. Eyes holding peace beyond understanding. Perfect serene presence. The calm of someone who has touched something real.
```

---

# 🛡️ PROVIDER (12 clips)
*Stats: Energy 55, Structure 80 - Protective, reassuring, solid*

### Provider - Clip A (Active Teaching)
```
Woman speaking with warm protective energy. Steady reassuring head movements. Encouraging nods that say "you've got this." Eyes conveying safety and support. Solid grounding presence. The energy of someone who will catch you if you fall.
```

### Provider - Clip B (Thoughtful Explaining)
```
Woman speaking with rock-steady supportive presence. Measured sheltering movements. Affirming nods of belief. Eyes that hold unwavering faith. Reliable warm gestures. The energy of someone who has always been there.
```

### Provider - Clip C (Grounded Wisdom)
```
Woman speaking with deep guardian stillness. Minimal movement, maximum safety. Slow eternal nods of protection. Eyes that have kept watch for decades. Permanent sheltering presence. The calm of someone who will always have your back.
```

---

# 📖 STORYTELLER (12 clips)
*Stats: Energy 75, Structure 45 - Theatrical, captivating, narrative*

### Storyteller - Clip A (Active Teaching)
```
Woman speaking with bright narrative energy. Animated expressive head movements. Dramatic eyebrow raises building intrigue. Eyes that hold you captive in the tale. Dynamic engaging presence. The magnetism of someone who makes you lean in to hear what happens next.
```

### Storyteller - Clip B (Thoughtful Explaining)
```
Woman speaking with engaged storytelling warmth. Measured dramatic movements. Knowing pauses for effect. Eyes that weave the narrative. Building and releasing tension. The craft of someone who knows exactly when to reveal.
```

### Storyteller - Clip C (Grounded Wisdom)
```
Woman speaking with master storyteller's calm. Slower but still captivating movements. Deep nods of narrative truth. Eyes holding ten thousand tales. Peaceful resolution energy. The calm of "and they lived..."
```

---

# 🎯 STRATEGIST (12 clips)
*Stats: Energy 65, Structure 92 - Calculating, precise, tactical*

### Strategist - Clip A (Active Teaching)
```
Woman speaking with sharp tactical energy. Precise deliberate head movements. Strategic eyebrow lifts spotting opportunities. Eyes that evaluate and assess. Calculated confident gestures. The energy of someone who sees three moves ahead.
```

### Strategist - Clip B (Thoughtful Explaining)
```
Woman speaking with focused strategic presence. Measured assessing movements. Deliberate nods confirming the plan. Eyes tracking systematically through options. Controlled commanding energy. The concentration of someone building the winning strategy.
```

### Strategist - Clip C (Grounded Wisdom)
```
Woman speaking with settled command presence. Minimal but authoritative movement. Slow wise nods of decades of patterns. Eyes that have planned and adapted. Peaceful strategic certainty. The calm of someone who knows the best strategy includes plans for when plans fail.
```

---

# 🏕️ SURVIVOR (12 clips)
*Stats: Energy 70, Structure 70 - Grounded, resilient, steady*

### Survivor - Clip A (Active Teaching)
```
Woman speaking with steady determined energy. Solid grounding head movements. Resilient nods of "we can do this." Eyes showing unshakeable core. Rock-steady engaged presence. The energy of someone who has been through harder and is still here.
```

### Survivor - Clip B (Thoughtful Explaining)
```
Woman speaking with unwavering resilient presence. Measured enduring movements. Strong affirming nods. Eyes conveying earned confidence. Grounded persistent energy. The steadiness of someone who takes it one step at a time.
```

### Survivor - Clip C (Grounded Wisdom)
```
Woman speaking with deep survivor's peace. Minimal movement, permanent resilience. Slow knowing nods of "this too shall pass." Eyes that have seen and overcome everything. Immovable grounded presence. The calm of someone who is still standing and always will be.
```

---

# PRODUCTION WORKFLOW

## Efficient Batching (Save Your Wrist)

**Day 1: All Clip A's (60 clips)**
- Do all 12 personas × 5 ages for "Active Teaching" motion
- Same energy arc, just persona flavor changes
- ~7 hours

**Day 2: All Clip B's (60 clips)**
- Do all 12 personas × 5 ages for "Thoughtful Explaining" motion
- ~7 hours

**Day 3: All Clip C's (60 clips)**
- Do all 12 personas × 5 ages for "Grounded Wisdom" motion
- ~7 hours

**Total: 180 clips = 21 hours across 3 days**

## File Naming Convention

```
kelly_{persona}_{age}_{clip}.mp4

Examples:
kelly_scientist_adult_A.mp4
kelly_scientist_adult_B.mp4
kelly_scientist_adult_C.mp4
kelly_explorer_kid_A.mp4
kelly_rebel_teen_B.mp4
kelly_mystic_elder_C.mp4
```

## Verification Checklist

For each clip:
- [ ] Movement variety is distinct from other clips of same Kelly
- [ ] Energy level matches clip type (A=high, B=medium, C=low)
- [ ] Persona flavor comes through
- [ ] No dead-eye or robotic moments
- [ ] Could loop naturally for longer content
- [ ] Upscaled successfully

---

# THE PAYOFF

Once you have 180 clips (30 seconds of source motion per Kelly-state):

1. **Any lesson** can be generated without loop glitch
2. **Any language** works - motion library is language-agnostic
3. **Any length** - 3 minutes, 10 minutes, system has variety to pull from
4. **Any topic** - motion isn't content-specific, it's character-specific

You've created the **base animation layer** for a character that can teach anything to anyone forever.

**60 characters to the world. 1 woman to you. Infinite lessons to learners.**
