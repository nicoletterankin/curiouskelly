# KELLY MOTION LIBRARY - PASTE READY

Copy prompt → Load Kelly head image → Generate → Next

---

# CLIP A: ACTIVE TEACHING (Higher energy)

## Scientist A
```
Woman speaking with analytical enthusiasm. Deliberate head movements emphasizing key points. Eyebrows lift with discovery moments. Precise nodding when making connections. Eyes track as if following logical progression. Brief upward glances when accessing information. Controlled energy with moments of brightening insight. Professional engaged teaching presence.
```

## Explorer A
```
Woman speaking with bright adventurous energy. Animated head movements showing enthusiasm. Eyes widen with wonder at discoveries. Expressive eyebrows rising with each new idea. Quick excited nods. Looking around as if seeing something fascinating. Forward-leaning engagement. High curious energy throughout. Ready for the journey.
```

## Rebel A
```
Woman speaking with bold challenging energy. Direct unflinching eye contact. Sharp head movements with purpose. Skeptical eyebrow raises. Quick decisive nods. Slight smirks of knowing. High intensity but controlled. Unapologetic presence. The energy of someone who questions everything and isn't afraid to say so.
```

## Architect A
```
Woman speaking with composed purposeful energy. Deliberate structured head movements. Precise nods laying foundation. Eyebrows that emphasize key structural points. Eyes tracking systematically. Controlled measured gestures. Nothing wasted. The energy of someone building something that will last.
```

## Diplomat A
```
Woman speaking with warm inclusive energy. Balanced head movements acknowledging all sides. Inviting nods that welcome perspectives. Eyebrows showing genuine interest in understanding. Eyes that convey hearing everyone. Open bridging gestures. The energy of someone creating connection and harmony.
```

## Empath A
```
Woman speaking with warm feeling energy. Gentle expressive head movements. Tender nods of connection. Eyebrows that mirror emotions. Eyes that truly see and feel. Soft forward presence. The energy of someone who feels alongside you, fully present and caring.
```

## MacGyver A
```
Woman speaking with bright inventive energy. Quick curious head movements scanning possibilities. Eyebrows popping with sudden insights. Animated problem-solving expressions. Eyes that see solutions everywhere. Engaged hands-on energy. The excitement of someone who knows they can figure it out.
```

## Mystic A
```
Woman speaking with gentle awakening energy. Slow meaningful head movements. Eyes that see beyond surface. Thoughtful rises of awareness. Subtle but profound gestures. The energy of someone revealing hidden patterns, gently guiding toward deeper seeing.
```

## Provider A
```
Woman speaking with warm protective energy. Steady reassuring head movements. Encouraging nods that say "you've got this." Eyes conveying safety and support. Solid grounding presence. The energy of someone who will catch you if you fall.
```

## Storyteller A
```
Woman speaking with bright narrative energy. Animated expressive head movements. Dramatic eyebrow raises building intrigue. Eyes that hold you captive in the tale. Dynamic engaging presence. The magnetism of someone who makes you lean in to hear what happens next.
```

## Strategist A
```
Woman speaking with sharp tactical energy. Precise deliberate head movements. Strategic eyebrow lifts spotting opportunities. Eyes that evaluate and assess. Calculated confident gestures. The energy of someone who sees three moves ahead.
```

## Survivor A
```
Woman speaking with steady determined energy. Solid grounding head movements. Resilient nods of "we can do this." Eyes showing unshakeable core. Rock-steady engaged presence. The energy of someone who has been through harder and is still here.
```

---

# CLIP B: THOUGHTFUL EXPLAINING (Medium energy)

## Scientist B
```
Woman speaking with measured analytical calm. Steady direct gaze with occasional thoughtful head tilts. Slow deliberate nods confirming understanding. Subtle eyebrow movements punctuating reasoning. Eyes focused and systematic. Minimal but purposeful movement. Quiet confidence in every gesture. Patient methodical explanation energy.
```

## Explorer B
```
Woman speaking with engaged curious warmth. Moderate head movements exploring ideas. Eyes dancing with interest. Gentle tilts examining concepts from different angles. Nodding with growing understanding. Expression of genuine fascination. Active but focused wonder. The energy of piecing together a discovery.
```

## Rebel B
```
Woman speaking with focused challenging calm. Steady direct gaze that holds you accountable. Measured head tilts of consideration. Deliberate nods that mean something. Eyes that see through pretense. Controlled edge without aggression. The energy of earned skepticism. Still questioning, but listening.
```

## Architect B
```
Woman speaking with steady methodical presence. Very measured head movements. Slow authoritative nods. Eyes showing deep structural understanding. Minimal but meaningful gestures. Patient systematic explanation. The energy of a master builder showing how pieces fit together.
```

## Diplomat B
```
Woman speaking with centered mediating presence. Measured inclusive head movements. Understanding nods that validate. Eyes showing synthesis happening. Gentle balanced gestures. The energy of holding complexity with ease. Both sides can be true.
```

## Empath B
```
Woman speaking with deep receptive presence. Slow empathetic head movements. Understanding nods that hear the unspoken. Eyes reflecting back with compassion. Gentle holding space. The energy of someone who understands before you finish speaking.
```

## MacGyver B
```
Woman speaking with focused resourceful presence. Purposeful head movements examining options. Nodding as pieces click together. Eyes tracking possibilities systematically. Practical engaged energy. The concentration of someone mid-solution.
```

## Mystic B
```
Woman speaking with contemplative depth. Very slow deliberate movements. Deep knowing nods. Eyes holding mystery and clarity together. Long pauses full of meaning. The energy of someone comfortable with the unknowable.
```

## Provider B
```
Woman speaking with rock-steady supportive presence. Measured sheltering movements. Affirming nods of belief. Eyes that hold unwavering faith. Reliable warm gestures. The energy of someone who has always been there.
```

## Storyteller B
```
Woman speaking with engaged storytelling warmth. Measured dramatic movements. Knowing pauses for effect. Eyes that weave the narrative. Building and releasing tension. The craft of someone who knows exactly when to reveal.
```

## Strategist B
```
Woman speaking with focused strategic presence. Measured assessing movements. Deliberate nods confirming the plan. Eyes tracking systematically through options. Controlled commanding energy. The concentration of someone building the winning strategy.
```

## Survivor B
```
Woman speaking with unwavering resilient presence. Measured enduring movements. Strong affirming nods. Eyes conveying earned confidence. Grounded persistent energy. The steadiness of someone who takes it one step at a time.
```

---

# CLIP C: GROUNDED WISDOM (Lower energy)

## Scientist C
```
Woman speaking with settled knowing presence. Very minimal movement, mostly stillness with meaning. Occasional slow deep nods of confirmation. Eyes soft but clear with accumulated understanding. Peaceful analytical certainty. Gentle settling into truth. The calm of someone who has tested and verified.
```

## Explorer C
```
Woman speaking with warm experienced presence. Slower movements carrying the weight of journeys taken. Knowing nods of recognition. Eyes holding depth of what's been seen. Gentle settling into earned wisdom. Peaceful adventurer at rest. The calm of someone who found what they were looking for.
```

## Rebel C
```
Woman speaking with settled defiant wisdom. Minimal movement but uncompromising presence. Slow nods of hard-won truth. Eyes showing the cost of standing alone. Quiet strength beneath the surface. Peaceful but never tamed. The calm of someone who knows what they stand for.
```

## Architect C
```
Woman speaking with monumental stillness. Almost no movement, pure grounded presence. Occasional deep nods of foundational truth. Eyes holding blueprints for things that outlast lifetimes. Peaceful commanding stability. The calm of bedrock.
```

## Diplomat C
```
Woman speaking with peaceful unifying presence. Minimal settling movements. Slow encompassing nods of acceptance. Eyes that have seen conflict resolve. Deep harmonious stillness. The calm of someone who knows all paths can lead to understanding.
```

## Empath C
```
Woman speaking with profound nurturing stillness. Very minimal movement, maximum presence. Slow knowing nods of shared experience. Eyes holding infinite kindness. Peaceful maternal warmth. The calm of someone who knows that being here is enough.
```

## MacGyver C
```
Woman speaking with settled capable presence. Calmer movements with quiet confidence. Knowing nods of competence. Eyes that have solved a thousand problems. Peaceful resourcefulness. The calm of someone who knows we always have what we need.
```

## Mystic C
```
Woman speaking with transcendent stillness. Barely perceptible movement. Imperceptible nods of eternal truth. Eyes holding peace beyond understanding. Perfect serene presence. The calm of someone who has touched something real.
```

## Provider C
```
Woman speaking with deep guardian stillness. Minimal movement, maximum safety. Slow eternal nods of protection. Eyes that have kept watch for decades. Permanent sheltering presence. The calm of someone who will always have your back.
```

## Storyteller C
```
Woman speaking with master storyteller's calm. Slower but still captivating movements. Deep nods of narrative truth. Eyes holding ten thousand tales. Peaceful resolution energy. The calm of "and they lived..."
```

## Strategist C
```
Woman speaking with settled command presence. Minimal but authoritative movement. Slow wise nods of decades of patterns. Eyes that have planned and adapted. Peaceful strategic certainty. The calm of someone who knows the best strategy includes plans for when plans fail.
```

## Survivor C
```
Woman speaking with deep survivor's peace. Minimal movement, permanent resilience. Slow knowing nods of "this too shall pass." Eyes that have seen and overcome everything. Immovable grounded presence. The calm of someone who is still standing and always will be.
```

---

# WORKFLOW

## Day 1: All A clips (60 total)
Load each Kelly head → Paste matching "A" prompt → Generate → Next

## Day 2: All B clips (60 total)  
Load each Kelly head → Paste matching "B" prompt → Generate → Next

## Day 3: All C clips (60 total)
Load each Kelly head → Paste matching "C" prompt → Generate → Next

## Naming
```
kelly_{persona}_{age}_{A/B/C}.mp4
```

---

# QUICK ENERGY CHECK

| Clip | Energy | Movement | Use |
|------|--------|----------|-----|
| A | High | Animated, expressive | Hooks, exciting content |
| B | Medium | Steady, measured | Core teaching |
| C | Low | Minimal, grounded | Wisdom, reflection |
