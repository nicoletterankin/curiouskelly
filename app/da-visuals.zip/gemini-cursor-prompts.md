# 🎯 Gemini Cursor Prompts - Ready to Run

## IMPORTANT: Rate Limit Status

⚠️ **Imagen is at 73/70 RPD** - You've hit the daily limit!
- Wait until midnight PST for reset
- OR request limit increase at https://aistudio.google.com/usage

---

## PROMPT 1: Fix API Key + Test Connection

```
# FIX GEMINI API KEY CONFIGURATION

Check the .env file. It has GOOGLE_API_KEY but scripts look for GEMINI_API_KEY.

1. Show me what API key variables exist in .env

2. Update generate-lesson-visuals.ts to use whichever key exists:
   const apiKey = process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY;

3. Test the connection (DO NOT generate images yet - we're at rate limit):
   - Call gemini-2.0-flash with a simple "Hello, respond with OK"
   - Report: Connected Y/N

4. Check Imagen availability:
   - If at rate limit, report "Imagen unavailable until midnight PST"
   - If available, report remaining quota
```

---

## PROMPT 2: Batch Script Variation Generator

```
# CREATE GEMINI SCRIPT VARIATION GENERATOR

Using gemini-2.0-flash (unlimited RPD), create a script that generates 
all 60 Kelly script variations for a single lesson.

## CREATE: scripts/generate-script-variations.ts

Input: lesson day number
Output: 60 script variations (12 personas × 5 age buckets)

For each variation:
1. Load base lesson from core_lessons + lesson_atoms
2. Call gemini-2.0-flash with persona + age context
3. Generate age-appropriate, persona-aligned script
4. Save to Supabase: lesson_script_variations table

Schema for lesson_script_variations:
- id (uuid)
- day_number (int)
- persona (text): scientist, explorer, rebel, etc.
- age_bucket (text): kid, teen, adult, elder, super_elder
- script (text): the generated variation
- created_at (timestamp)

Test with Day 1 only. Report the 60 variations generated.
```

---

## PROMPT 3: Visual Prompt Generator (No Images Yet)

```
# GENERATE IMAGE PROMPTS - NO GENERATION YET

We're at Imagen rate limit. But we CAN pre-generate all the prompts.

Using gemini-2.0-flash, create prompts for all 365 lessons.

## CREATE: scripts/generate-image-prompts.ts

For each lesson:
1. Analyze lesson content
2. Generate 3 image prompts:
   - thumbnail_prompt: Netflix-style 16:9 lesson thumbnail
   - infographic_prompt: Key concept visualization
   - social_prompt: Instagram/social share image

3. Save to Supabase: lesson_image_prompts table

Schema:
- day_number (int)
- thumbnail_prompt (text)
- infographic_prompt (text)
- social_prompt (text)
- created_at (timestamp)

Run for Days 1-10 as test. Show me the prompts generated.

This uses gemini-2.0-flash (unlimited) NOT imagen (rate limited).
```

---

## PROMPT 4: Quality Review Interface

```
# CREATE VISUAL QA ADMIN PAGE

Build an admin interface to review generated visuals.

## CREATE: public/admin/visual-qa.html

Features:
1. Grid view of all lessons with their generated images
2. For each lesson show:
   - Thumbnail (if generated)
   - Quality score input (1-10)
   - Approve/Reject/Regenerate buttons
   - Notes field

3. Filter by:
   - Status: pending, approved, rejected, needs-regen
   - Day range: 1-365
   - Has thumbnail: yes/no

4. Batch actions:
   - Approve all visible
   - Queue regeneration for rejected

5. Stats dashboard:
   - Total lessons: 365
   - Thumbnails generated: X
   - Approved: X
   - Pending review: X
   - Needs regeneration: X

Use Supabase for data. Style similar to avatar-registry.html.
```

---

## PROMPT 5: Daily Batch Scheduler

```
# CREATE DAILY BATCH SCHEDULER

Set up automated daily runs for Gemini operations.

## CREATE: scripts/daily-batch-runner.ts

Schedule (respecting rate limits):

6 AM - Content Generation (gemini-2.0-flash, unlimited):
- Generate script variations for next 7 days
- Create social media posts
- Generate quiz questions

12 PM - Visual Planning (gemini-3-pro, 250/day):
- Analyze lessons needing visuals
- Generate image prompts
- Plan infographic layouts

6 PM - Image Generation (imagen-4.0, 70/day):
- Generate up to 70 images
- Priority: lessons without thumbnails
- Track which days are complete

12 AM - Quality Check:
- Log daily summary
- Flag failures for retry
- Report completion status

Create the runner that can be triggered via:
npx tsx scripts/daily-batch-runner.ts --phase morning
npx tsx scripts/daily-batch-runner.ts --phase midday
npx tsx scripts/daily-batch-runner.ts --phase evening
npx tsx scripts/daily-batch-runner.ts --phase night

For now, just scaffold the structure. We'll fill in each phase.
```

---

## PROMPT 6: Content Studio Interface

```
# CREATE KELLY CONTENT STUDIO

Build an admin interface for managing script variations.

## CREATE: public/admin/content-studio.html

Features:
1. Lesson selector (Day 1-365 dropdown)
2. When lesson selected, show:
   - Base lesson content
   - All 60 script variations (12 personas × 5 ages)
   - Grid layout: personas as columns, ages as rows

3. For each variation:
   - Preview script text
   - Edit button (inline editing)
   - Regenerate button (calls gemini-2.0-flash)
   - Status: draft, approved, generated-video

4. Bulk actions:
   - Generate all variations for this lesson
   - Approve all variations
   - Send to HeyGen queue

5. Kelly persona reference panel:
   - Show persona descriptions
   - Show age bucket characteristics
   - Voice/tone guidelines

Style: Dark mode, similar to existing admin pages.
Data: Supabase lesson_script_variations table.
```

---

## IMMEDIATE PRIORITY ORDER

1. **PROMPT 1** - Fix API key (5 min)
2. **PROMPT 3** - Generate image prompts while waiting for Imagen reset (uses Flash, unlimited)
3. **PROMPT 2** - Generate script variations (uses Flash, unlimited)
4. Wait for midnight PST → Imagen resets
5. Run actual image generation

---

## NOTES

- gemini-2.0-flash is your workhorse - UNLIMITED daily requests
- Imagen is precious - only 70/day, use wisely
- Pre-generate prompts now, generate images overnight
- All admin pages should live in /public/admin/
