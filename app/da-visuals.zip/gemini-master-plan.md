# 🧠 Gemini Master Plan for Curious Kelly

## Your Current Rate Limits (Paid Tier 1)

| Model | RPM | TPM | RPD | Best For |
|-------|-----|-----|-----|----------|
| gemini-2.0-flash | 40/2K | 18K/4M | Unlimited | Fast reasoning, batch processing |
| gemini-2.0-flash-exp | 9/10 | 914/250K | 10/500 | Experimental features |
| gemini-3-pro | 0/25 | 4.9K/1M | 0/250 | Complex reasoning, planning |
| gemini-3-pro-image | 2/20 | 6.2K/100K | 44/250 | Image understanding |
| imagen-4.0-generate | 6/10 | N/A | 73/70 ⚠️ | Image generation (at limit!) |

---

## 🎯 MODEL ALIGNMENT STRATEGY

### Tier 1: THINKING & PLANNING (gemini-2.0-flash)
**Use for:** High-volume, fast operations
- Lesson script refinement
- Content variation generation (5 age buckets × 12 personas)
- SEO metadata generation
- Quiz question generation
- Daily batch processing

**Why:** Unlimited RPD, 40 RPM = can process all 365 lessons repeatedly

### Tier 2: DEEP REASONING (gemini-3-pro)
**Use for:** Complex, strategic tasks
- Kelly persona voice calibration
- Curriculum coherence checking
- Cross-lesson narrative threading
- Quality audits
- Parent/educator explanation generation

**Why:** 1M token context = can analyze multiple lessons at once

### Tier 3: IMAGE UNDERSTANDING (gemini-3-pro-image)
**Use for:** Visual QA and refinement
- Review generated thumbnails for quality
- Check infographics for accuracy
- Validate Kelly avatar expressions match content tone
- Audit visual consistency across lessons

**Why:** Can "see" what you've generated and critique it

### Tier 4: IMAGE GENERATION (imagen-4.0-generate)
**Use for:** Creating visual assets
- Lesson thumbnails (Netflix-style)
- Educational infographics
- Supporting illustrations
- Social media assets

**⚠️ WARNING:** You're at 73/70 RPD - over daily limit!
**Strategy:** Batch image generation overnight, 70 images/day max

---

## 📅 DAILY BATCH SCHEDULE

### Morning Batch (6 AM) - Content Generation
```
gemini-2.0-flash (unlimited):
├── Generate today's lesson variations (5 ages × 12 personas = 60 scripts)
├── Create social media posts for today's lesson
├── Generate quiz questions
└── Produce parent/educator guides
```

### Midday Batch (12 PM) - Visual Planning
```
gemini-3-pro (25 RPM):
├── Analyze today's lesson for visual opportunities
├── Write detailed image prompts for Imagen
├── Plan infographic data/layouts
└── Review yesterday's generated content
```

### Evening Batch (6 PM) - Image Generation
```
imagen-4.0-generate (70/day limit):
├── Generate 3-5 images per lesson
├── Priority: Next 14 days of lessons
├── Create: 1 thumbnail + 2-3 infographics per lesson
└── Target: ~15-20 lessons/day at 70 images
```

### Night Batch (12 AM) - Quality Assurance
```
gemini-3-pro-image (20 RPM):
├── Review all generated images
├── Flag low-quality outputs for regeneration
├── Check brand consistency
└── Validate educational accuracy
```

---

## 🖼️ IMAGE GENERATION PIPELINE

### Thumbnail Strategy (Netflix-Style)
```
For each lesson:
1. gemini-2.0-flash: Analyze lesson → Generate 3 thumbnail concepts
2. imagen-4.0: Generate best concept at 16:9, 4K
3. gemini-3-pro-image: Review for quality score (1-10)
4. If score < 7: Regenerate with refined prompt
5. Store in Supabase: lesson_visuals bucket
```

### Infographic Types
| Type | Description | Lessons |
|------|-------------|---------|
| Process Flow | Step-by-step visual | How-to lessons |
| Comparison | Side-by-side | vs/difference lessons |
| Timeline | Chronological | History/sequence lessons |
| Data Viz | Charts/graphs | Number-based lessons |
| Concept Map | Relationship diagram | Complex topic lessons |

### Prompt Engineering Template
```
THUMBNAIL PROMPT STRUCTURE:
"Educational thumbnail for children's learning platform.
Topic: [LESSON_TITLE]
Style: Warm, inviting, Netflix-quality
Elements: [KEY_VISUAL_ELEMENT], soft lighting, depth of field
Color palette: [AGE_APPROPRIATE_COLORS]
Text overlay space: Leave room for title on [LEFT/RIGHT]
Mood: [CURIOUS/EXCITED/THOUGHTFUL]
NO: Text, letters, words, logos, watermarks"
```

---

## 🎬 VIDEO GENERATION STRATEGY

### Current: HeyGen for Kelly Avatar Videos
- 60 avatar IDs ready
- Generates talking head videos
- ~78 seconds per video

### Future: Veo 2 Integration (when available)
```
Potential uses:
├── B-roll footage for lessons
├── Animated explanations
├── Scene transitions
├── Background environments for Kelly
└── Educational demonstrations
```

### Hybrid Approach
```
Kelly (HeyGen) + Background (Veo) + Infographics (Imagen)
         ↓              ↓                 ↓
    Talking head   Environment      Visual aids
         ↓              ↓                 ↓
         └──────────────┴─────────────────┘
                        ↓
              Final Composited Lesson
```

---

## 🔄 60 KELLY VARIATIONS × 365 LESSONS

### The Math
- 12 personas × 5 age buckets = 60 Kelly variants
- 365 lessons × 60 variants = 21,900 potential video scripts
- Reality: Generate on-demand based on user profile

### Smart Generation Strategy
```javascript
// Don't pre-generate everything. Generate what's needed.

const generateForUser = async (userId, lessonDay) => {
  const user = await getUser(userId);
  const ageBucket = getAgeBucket(user.age);
  const persona = user.selectedPersona || 'scientist';
  
  const key = `${lessonDay}-${ageBucket}-${persona}`;
  
  // Check cache first
  let video = await getFromCache(key);
  if (video) return video;
  
  // Generate on-demand
  video = await generateKellyVideo(lessonDay, ageBucket, persona);
  await saveToCache(key, video);
  
  return video;
};
```

### Pre-Generation Priority
1. **Day 1-30**: All 60 variants (first month experience)
2. **Day 31-365**: adult-scientist only (most common)
3. **On-demand**: Other variants as users request

---

## 🛠️ GENERATIVE INTERFACES

### 1. Admin Dashboard: Visual Generation Queue
```
/admin/visual-queue.html
├── View pending lessons needing visuals
├── Trigger batch generation
├── Review/approve generated images
├── Regenerate with new prompts
└── Monitor Imagen rate limits
```

### 2. Content Studio: Script Variations
```
/admin/content-studio.html
├── Select lesson
├── Generate all 60 persona/age variations
├── Preview each variation
├── Edit/refine individual scripts
└── Push to HeyGen queue
```

### 3. Kelly Voice Calibration
```
/admin/voice-calibration.html
├── Input sample scripts
├── Generate variations per persona
├── A/B test voice styles
├── Lock in approved voice patterns
└── Export to ElevenLabs prompts
```

### 4. Lesson Preview Theater
```
/admin/preview-theater.html
├── Select any lesson + Kelly variant
├── See: Thumbnail + Script + Video (if generated)
├── Play full lesson experience
├── Flag issues for regeneration
└── Approve for production
```

---

## 📊 RATE LIMIT MANAGEMENT

### Daily Budget Allocation
```
IMAGEN (70/day):
├── 50 thumbnails (1 per lesson, 50 lessons/day)
├── 15 infographics (priority lessons)
└── 5 regenerations (failed/low-quality)

GEMINI-3-PRO (250/day):
├── 100 lesson analyses
├── 100 prompt generations  
└── 50 quality reviews

GEMINI-2.0-FLASH (unlimited):
├── All script variations
├── All metadata generation
├── All quick tasks
└── No limits!
```

### Rate Limit Monitor Script
```javascript
// scripts/check-rate-limits.ts
const checkLimits = async () => {
  const usage = await getGeminiUsage();
  
  console.log('=== DAILY BUDGET ===');
  console.log(`Imagen: ${usage.imagen.used}/${usage.imagen.limit}`);
  console.log(`Gemini-3-Pro: ${usage.pro.used}/${usage.pro.limit}`);
  
  if (usage.imagen.used > usage.imagen.limit * 0.8) {
    console.warn('⚠️ Imagen approaching daily limit!');
  }
};
```

---

## 🚀 IMPLEMENTATION PHASES

### Phase 1: Foundation (This Week)
- [ ] Fix GEMINI_API_KEY in .env
- [ ] Run Day 1 visual generation test
- [ ] Validate thumbnail quality
- [ ] Set up lesson_visuals Supabase bucket

### Phase 2: Batch Pipeline (Next Week)
- [ ] Create daily batch scheduler
- [ ] Generate thumbnails for Days 1-70 (1 week of Imagen limits)
- [ ] Build admin visual queue interface
- [ ] Implement quality review workflow

### Phase 3: Full Production (Week 3+)
- [ ] All 365 lessons have thumbnails
- [ ] Infographics for top 100 lessons
- [ ] Content studio for script variations
- [ ] Kelly voice calibration complete

### Phase 4: Advanced (Month 2)
- [ ] On-demand video generation
- [ ] Veo 2 integration (when available)
- [ ] Real-time personalization
- [ ] Multi-language generation

---

## 🔑 IMMEDIATE ACTION ITEMS

### 1. Fix Imagen Rate Limit
You're at 73/70 - **wait until tomorrow** or request limit increase

### 2. Add to .env
```
GEMINI_API_KEY=<your key from GOOGLE_API_KEY>
# Or update script to use GOOGLE_API_KEY
```

### 3. Test Single Lesson
```bash
npx tsx scripts/generate-lesson-visuals.ts --day 1
```

### 4. Monitor Usage
Bookmark: https://aistudio.google.com/usage

---

## 💡 STRATEGIC INSIGHT

**Your competitive advantage:**
- HeyGen = Kelly speaks (avatar video)
- Gemini = Kelly thinks (content generation)
- Imagen = Kelly's world (visuals)
- ElevenLabs = Kelly's voice (audio)

**No one else has this stack integrated for education.**

The 60 Kelly variants + 365 lessons + Gemini intelligence = 
**Personalized education at scale that actually works.**

---

*Generated for Curious Kelly - December 2024*
