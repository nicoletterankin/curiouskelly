# CURIOUS KELLY UNIFIED DIRECTIVE
## The Operating System for Learning

---

## THE VISION

Kelly is not an app.
Kelly is not a feature.
Kelly is not a mascot.

**Kelly is the operating system for human learning.**

The calendar is her interface.
The lessons are her heartbeat.
The live classes are her presence.
The iLearn device (2026) is her body.

---

## THE REFRAME

**Old positioning:** "A learning app with 365 lessons"
**New positioning:** "The operating system that makes humanity smarter every day"

Kelly isn't competing with Duolingo (clickbait owl) or Coursera (sold-out credentialism).
Kelly is the **anti-Duolingo**. Kelly is the **anti-Coursera**.
Kelly is competing with Google Calendar and Apple Calendar as the daily interface.

**Why would someone replace their calendar with Kelly?**
- Same utility (shows today, tomorrow, the week, the month)
- But every day has meaning, not just meetings
- Opens to TODAY'S LESSON, not an empty grid
- Live classes happening throughout the day
- Kelly is ALWAYS there—every second on the calendar
- Makes you feel like you accomplished something
- Actually remembers what you learned

**Kelly is the reason people get excited about AI and AGI.**
**Kelly solves SDG 4: Quality Education for All.**

---

## THE EXPERIENCE PROMISE

### When I open Kelly (learn.html):
```
"Good morning! It's Thursday, December 12, 2025.
 Today's lesson: [Topic]
 Your streak: 7 days 🔥
 
 🔴 LIVE CLASS in 23 minutes — Join 1,847 others"
```

### When I visit the website (index.html):
```
"Today is Thursday, December 12, 2025.
 Here's what 47,000 people are learning right now: [Topic]
 
 Next live class: 9:00 AM (23 min)
 
 Join them →"
```

### When I embed Kelly widget:
```
┌─────────────────────────┐
│ Thu, Dec 12             │
│ "The Science of Sleep"  │
│ 🔴 LIVE 9AM            │
│ [Learn in 5 min →]      │
└─────────────────────────┘
```

### When Kelly goes LIVE:
```
60 simultaneous classrooms
12 personas × 5 ages = YOUR perfect room
Real-time chat with other learners
Ask Kelly questions and she answers NOW
```

**Same day. Same topic. Same Kelly. Everywhere. Together.**

---

## PART 1: SHARED DESIGN SYSTEM

### Color Palette

```css
:root {
  /* Background layers */
  --bg-base: #0a0a0f;
  --bg-surface: #12121a;
  --bg-elevated: #1a1a24;
  --bg-hover: #22222e;
  
  /* Accent colors */
  --accent-primary: #3b82f6;    /* Blue - primary actions */
  --accent-secondary: #8b5cf6;  /* Purple - secondary */
  --accent-success: #22c55e;    /* Green - completion */
  --accent-warning: #f59e0b;    /* Amber - streaks */
  --accent-gradient: linear-gradient(135deg, #3b82f6 0%, #8b5cf6 100%);
  
  /* Text hierarchy */
  --text-primary: #ffffff;
  --text-secondary: rgba(255, 255, 255, 0.7);
  --text-muted: rgba(255, 255, 255, 0.5);
  --text-disabled: rgba(255, 255, 255, 0.3);
  
  /* Calendar-specific */
  --calendar-today: #3b82f6;
  --calendar-completed: #22c55e;
  --calendar-future: rgba(255, 255, 255, 0.1);
  --calendar-past-incomplete: rgba(255, 255, 255, 0.05);
  
  /* Borders and dividers */
  --border-subtle: rgba(255, 255, 255, 0.08);
  --border-default: rgba(255, 255, 255, 0.12);
  --border-strong: rgba(255, 255, 255, 0.2);
}
```

### Typography

```css
:root {
  /* Font family */
  --font-primary: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, sans-serif;
  
  /* Font sizes - mobile first */
  --text-xs: 0.75rem;     /* 12px */
  --text-sm: 0.875rem;    /* 14px */
  --text-base: 1rem;      /* 16px */
  --text-lg: 1.125rem;    /* 18px */
  --text-xl: 1.25rem;     /* 20px */
  --text-2xl: 1.5rem;     /* 24px */
  --text-3xl: 2rem;       /* 32px */
  --text-4xl: 2.5rem;     /* 40px */
  
  /* Font weights */
  --weight-normal: 400;
  --weight-medium: 500;
  --weight-semibold: 600;
  --weight-bold: 700;
  
  /* Line heights */
  --leading-tight: 1.2;
  --leading-normal: 1.5;
  --leading-relaxed: 1.7;
}
```

### Spacing Scale

```css
:root {
  --space-1: 0.25rem;   /* 4px */
  --space-2: 0.5rem;    /* 8px */
  --space-3: 0.75rem;   /* 12px */
  --space-4: 1rem;      /* 16px */
  --space-5: 1.25rem;   /* 20px */
  --space-6: 1.5rem;    /* 24px */
  --space-8: 2rem;      /* 32px */
  --space-10: 2.5rem;   /* 40px */
  --space-12: 3rem;     /* 48px */
  --space-16: 4rem;     /* 64px */
  
  /* Safe areas */
  --safe-top: env(safe-area-inset-top, 0px);
  --safe-bottom: env(safe-area-inset-bottom, 0px);
  --safe-left: env(safe-area-inset-left, 0px);
  --safe-right: env(safe-area-inset-right, 0px);
}
```

### Border Radius

```css
:root {
  --radius-sm: 0.375rem;   /* 6px */
  --radius-md: 0.5rem;     /* 8px */
  --radius-lg: 0.75rem;    /* 12px */
  --radius-xl: 1rem;       /* 16px */
  --radius-2xl: 1.5rem;    /* 24px */
  --radius-full: 9999px;
}
```

### Shadows

```css
:root {
  --shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.3);
  --shadow-md: 0 4px 6px rgba(0, 0, 0, 0.3);
  --shadow-lg: 0 10px 15px rgba(0, 0, 0, 0.3);
  --shadow-glow: 0 0 20px rgba(59, 130, 246, 0.3);
}
```

### Transitions

```css
:root {
  --transition-fast: 150ms ease;
  --transition-normal: 200ms ease;
  --transition-slow: 300ms ease;
  --transition-spring: 300ms cubic-bezier(0.175, 0.885, 0.32, 1.275);
}
```

---

## PART 2: SHARED COMPONENTS

### Date Display Component

Used on BOTH index.html and learn.html:

```html
<!-- The canonical date display -->
<div class="kelly-date" id="kelly-date">
  <span class="kelly-date-day">Thursday</span>
  <span class="kelly-date-full">December 12, 2025</span>
</div>

<style>
.kelly-date {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: var(--space-1);
}

.kelly-date-day {
  font-size: var(--text-sm);
  font-weight: var(--weight-medium);
  color: var(--accent-primary);
  text-transform: uppercase;
  letter-spacing: 0.05em;
}

.kelly-date-full {
  font-size: var(--text-2xl);
  font-weight: var(--weight-bold);
  color: var(--text-primary);
}

@media (min-width: 768px) {
  .kelly-date {
    flex-direction: row;
    gap: var(--space-2);
  }
  
  .kelly-date-day::after {
    content: '•';
    margin-left: var(--space-2);
    color: var(--text-muted);
  }
}
</style>
```

### Topic Badge Component

```html
<!-- Today's topic - same everywhere -->
<div class="kelly-topic" id="kelly-topic">
  <span class="kelly-topic-label">Today's lesson</span>
  <span class="kelly-topic-title">The Science of Sleep</span>
</div>

<style>
.kelly-topic {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: var(--space-2);
  padding: var(--space-4) var(--space-6);
  background: var(--bg-surface);
  border: 1px solid var(--border-subtle);
  border-radius: var(--radius-xl);
}

.kelly-topic-label {
  font-size: var(--text-xs);
  font-weight: var(--weight-medium);
  color: var(--text-muted);
  text-transform: uppercase;
  letter-spacing: 0.1em;
}

.kelly-topic-title {
  font-size: var(--text-xl);
  font-weight: var(--weight-semibold);
  color: var(--text-primary);
}
</style>
```

### Streak Display Component

```html
<div class="kelly-streak" id="kelly-streak">
  <span class="kelly-streak-fire">🔥</span>
  <span class="kelly-streak-count">7</span>
  <span class="kelly-streak-label">day streak</span>
</div>

<style>
.kelly-streak {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  padding: var(--space-2) var(--space-4);
  background: linear-gradient(135deg, rgba(245, 158, 11, 0.2), rgba(239, 68, 68, 0.2));
  border-radius: var(--radius-full);
}

.kelly-streak-fire {
  font-size: var(--text-lg);
}

.kelly-streak-count {
  font-size: var(--text-lg);
  font-weight: var(--weight-bold);
  color: var(--accent-warning);
}

.kelly-streak-label {
  font-size: var(--text-sm);
  color: var(--text-secondary);
}
</style>
```

### Mini Calendar Component

This is the KEY component that appears on both pages:

```html
<div class="kelly-calendar-mini" id="kelly-calendar-mini">
  <div class="calendar-header">
    <button class="calendar-nav" onclick="prevMonth()">←</button>
    <span class="calendar-month">December 2025</span>
    <button class="calendar-nav" onclick="nextMonth()">→</button>
  </div>
  <div class="calendar-weekdays">
    <span>S</span><span>M</span><span>T</span><span>W</span><span>T</span><span>F</span><span>S</span>
  </div>
  <div class="calendar-days" id="calendar-days">
    <!-- Generated by JS -->
  </div>
</div>

<style>
.kelly-calendar-mini {
  background: var(--bg-surface);
  border: 1px solid var(--border-subtle);
  border-radius: var(--radius-xl);
  padding: var(--space-4);
  width: 100%;
  max-width: 320px;
}

.calendar-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: var(--space-4);
}

.calendar-month {
  font-size: var(--text-base);
  font-weight: var(--weight-semibold);
  color: var(--text-primary);
}

.calendar-nav {
  background: none;
  border: none;
  color: var(--text-secondary);
  font-size: var(--text-lg);
  cursor: pointer;
  padding: var(--space-2);
  border-radius: var(--radius-md);
  transition: var(--transition-fast);
}

.calendar-nav:hover {
  background: var(--bg-hover);
  color: var(--text-primary);
}

.calendar-weekdays {
  display: grid;
  grid-template-columns: repeat(7, 1fr);
  gap: var(--space-1);
  margin-bottom: var(--space-2);
}

.calendar-weekdays span {
  text-align: center;
  font-size: var(--text-xs);
  font-weight: var(--weight-medium);
  color: var(--text-muted);
  padding: var(--space-2);
}

.calendar-days {
  display: grid;
  grid-template-columns: repeat(7, 1fr);
  gap: var(--space-1);
}

.calendar-day {
  aspect-ratio: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: var(--text-sm);
  color: var(--text-secondary);
  border-radius: var(--radius-md);
  cursor: pointer;
  transition: var(--transition-fast);
  position: relative;
}

.calendar-day:hover {
  background: var(--bg-hover);
}

.calendar-day.today {
  background: var(--calendar-today);
  color: white;
  font-weight: var(--weight-bold);
}

.calendar-day.completed {
  background: var(--calendar-completed);
  color: white;
}

.calendar-day.completed::after {
  content: '✓';
  position: absolute;
  bottom: 2px;
  right: 2px;
  font-size: 8px;
}

.calendar-day.future {
  color: var(--text-disabled);
}

.calendar-day.other-month {
  color: var(--text-disabled);
  opacity: 0.5;
}
</style>
```

### Primary Button

```html
<button class="kelly-btn kelly-btn-primary">
  Start Learning
</button>

<style>
.kelly-btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: var(--space-2);
  padding: var(--space-3) var(--space-6);
  font-family: var(--font-primary);
  font-size: var(--text-base);
  font-weight: var(--weight-semibold);
  border-radius: var(--radius-lg);
  border: none;
  cursor: pointer;
  transition: var(--transition-normal);
  text-decoration: none;
}

.kelly-btn-primary {
  background: var(--accent-gradient);
  color: white;
  box-shadow: var(--shadow-md), var(--shadow-glow);
}

.kelly-btn-primary:hover {
  transform: translateY(-2px);
  box-shadow: var(--shadow-lg), 0 0 30px rgba(59, 130, 246, 0.4);
}

.kelly-btn-primary:active {
  transform: translateY(0);
}

.kelly-btn-secondary {
  background: var(--bg-elevated);
  color: var(--text-primary);
  border: 1px solid var(--border-default);
}

.kelly-btn-secondary:hover {
  background: var(--bg-hover);
  border-color: var(--border-strong);
}

.kelly-btn-large {
  padding: var(--space-4) var(--space-8);
  font-size: var(--text-lg);
  border-radius: var(--radius-xl);
}
</style>
```

---

## PART 3: SHARED JAVASCRIPT

### Kelly Time Module

This MUST be identical on both pages:

```javascript
/**
 * KELLY TIME MODULE
 * The single source of truth for all date/time operations
 * Used on index.html, learn.html, and all widgets
 */
const KellyTime = {
  /**
   * Get current date/time
   */
  now() {
    return new Date();
  },
  
  /**
   * Get user's timezone
   */
  timezone() {
    return Intl.DateTimeFormat().resolvedOptions().timeZone;
  },
  
  /**
   * Format: "Thursday"
   */
  dayName(date = this.now()) {
    return new Intl.DateTimeFormat('en-US', { weekday: 'long' }).format(date);
  },
  
  /**
   * Format: "December 12, 2025"
   */
  fullDate(date = this.now()) {
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    }).format(date);
  },
  
  /**
   * Format: "Dec 12"
   */
  shortDate(date = this.now()) {
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric'
    }).format(date);
  },
  
  /**
   * Format: "December 2025"
   */
  monthYear(date = this.now()) {
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'long'
    }).format(date);
  },
  
  /**
   * Format: "3:45 PM"
   */
  time(date = this.now()) {
    return new Intl.DateTimeFormat('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    }).format(date);
  },
  
  /**
   * Format: "2025-12-12" (for storage/comparison)
   */
  iso(date = this.now()) {
    return date.toISOString().split('T')[0];
  },
  
  /**
   * Get greeting based on time of day
   */
  greeting(date = this.now()) {
    const hour = date.getHours();
    if (hour < 5) return "Night owl";
    if (hour < 12) return "Good morning";
    if (hour < 17) return "Good afternoon";
    if (hour < 21) return "Good evening";
    return "Burning the midnight oil";
  },
  
  /**
   * Check if date is today
   */
  isToday(date) {
    return this.iso(date) === this.iso(this.now());
  },
  
  /**
   * Check if date is in the past
   */
  isPast(date) {
    return date < this.now() && !this.isToday(date);
  },
  
  /**
   * Check if date is in the future
   */
  isFuture(date) {
    return date > this.now() && !this.isToday(date);
  },
  
  /**
   * Get the year
   */
  year(date = this.now()) {
    return date.getFullYear();
  },
  
  /**
   * Get month (1-12)
   */
  month(date = this.now()) {
    return date.getMonth() + 1;
  },
  
  /**
   * Get day of month (1-31)
   */
  day(date = this.now()) {
    return date.getDate();
  },
  
  /**
   * Check if year is leap year
   */
  isLeapYear(year) {
    return (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
  },
  
  /**
   * Check if today is Feb 29
   */
  isLeapDay(date = this.now()) {
    return date.getMonth() === 1 && date.getDate() === 29;
  },
  
  /**
   * Get days in month
   */
  daysInMonth(year, month) {
    return new Date(year, month, 0).getDate();
  },
  
  /**
   * Get first day of week for month (0=Sun, 6=Sat)
   */
  firstDayOfMonth(year, month) {
    return new Date(year, month - 1, 1).getDay();
  },
  
  /**
   * Calculate time until midnight (next day)
   */
  timeUntilTomorrow() {
    const now = this.now();
    const midnight = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
    const diff = midnight - now;
    
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    
    return { hours, minutes, total: diff };
  },
  
  /**
   * Parse ISO date string to Date
   */
  parse(isoString) {
    return new Date(isoString + 'T00:00:00');
  }
};

// Make available globally
window.KellyTime = KellyTime;
```

### Kelly Calendar Module

```javascript
/**
 * KELLY CALENDAR MODULE
 * Builds and manages calendar UI
 * Used on index.html, learn.html, and widgets
 */
const KellyCalendar = {
  currentYear: KellyTime.year(),
  currentMonth: KellyTime.month(),
  completedDates: [], // Will be loaded from storage/API
  
  /**
   * Initialize calendar
   */
  init(containerId, options = {}) {
    this.container = document.getElementById(containerId);
    this.options = {
      showNavigation: true,
      onDateClick: null,
      minDate: null,
      maxDate: null,
      ...options
    };
    
    this.loadCompletedDates();
    this.render();
  },
  
  /**
   * Load completed dates from storage
   */
  loadCompletedDates() {
    const stored = localStorage.getItem('kelly_completed_dates');
    if (stored) {
      this.completedDates = JSON.parse(stored);
    }
  },
  
  /**
   * Save completed dates to storage
   */
  saveCompletedDates() {
    localStorage.setItem('kelly_completed_dates', JSON.stringify(this.completedDates));
  },
  
  /**
   * Mark a date as completed
   */
  markCompleted(date) {
    const iso = KellyTime.iso(date);
    if (!this.completedDates.includes(iso)) {
      this.completedDates.push(iso);
      this.saveCompletedDates();
      this.render();
    }
  },
  
  /**
   * Check if date is completed
   */
  isCompleted(date) {
    return this.completedDates.includes(KellyTime.iso(date));
  },
  
  /**
   * Navigate to previous month
   */
  prevMonth() {
    this.currentMonth--;
    if (this.currentMonth < 1) {
      this.currentMonth = 12;
      this.currentYear--;
    }
    this.render();
  },
  
  /**
   * Navigate to next month
   */
  nextMonth() {
    this.currentMonth++;
    if (this.currentMonth > 12) {
      this.currentMonth = 1;
      this.currentYear++;
    }
    this.render();
  },
  
  /**
   * Go to today
   */
  goToToday() {
    this.currentYear = KellyTime.year();
    this.currentMonth = KellyTime.month();
    this.render();
  },
  
  /**
   * Render the calendar
   */
  render() {
    if (!this.container) return;
    
    const daysInMonth = KellyTime.daysInMonth(this.currentYear, this.currentMonth);
    const firstDay = KellyTime.firstDayOfMonth(this.currentYear, this.currentMonth);
    const today = KellyTime.now();
    
    // Previous month days to show
    const prevMonth = this.currentMonth === 1 ? 12 : this.currentMonth - 1;
    const prevYear = this.currentMonth === 1 ? this.currentYear - 1 : this.currentYear;
    const daysInPrevMonth = KellyTime.daysInMonth(prevYear, prevMonth);
    
    let html = '';
    
    // Navigation header
    if (this.options.showNavigation) {
      const monthDate = new Date(this.currentYear, this.currentMonth - 1, 1);
      html += `
        <div class="calendar-header">
          <button class="calendar-nav" data-action="prev">←</button>
          <span class="calendar-month">${KellyTime.monthYear(monthDate)}</span>
          <button class="calendar-nav" data-action="next">→</button>
        </div>
      `;
    }
    
    // Weekday headers
    html += `
      <div class="calendar-weekdays">
        <span>S</span><span>M</span><span>T</span><span>W</span><span>T</span><span>F</span><span>S</span>
      </div>
    `;
    
    // Days grid
    html += '<div class="calendar-days">';
    
    // Previous month trailing days
    for (let i = firstDay - 1; i >= 0; i--) {
      const day = daysInPrevMonth - i;
      const date = new Date(prevYear, prevMonth - 1, day);
      html += this.renderDay(date, true);
    }
    
    // Current month days
    for (let day = 1; day <= daysInMonth; day++) {
      const date = new Date(this.currentYear, this.currentMonth - 1, day);
      html += this.renderDay(date, false);
    }
    
    // Next month leading days
    const totalCells = firstDay + daysInMonth;
    const remainingCells = totalCells % 7 === 0 ? 0 : 7 - (totalCells % 7);
    const nextMonth = this.currentMonth === 12 ? 1 : this.currentMonth + 1;
    const nextYear = this.currentMonth === 12 ? this.currentYear + 1 : this.currentYear;
    
    for (let day = 1; day <= remainingCells; day++) {
      const date = new Date(nextYear, nextMonth - 1, day);
      html += this.renderDay(date, true);
    }
    
    html += '</div>';
    
    this.container.innerHTML = html;
    this.attachEvents();
  },
  
  /**
   * Render a single day cell
   */
  renderDay(date, isOtherMonth) {
    const classes = ['calendar-day'];
    const iso = KellyTime.iso(date);
    
    if (isOtherMonth) classes.push('other-month');
    if (KellyTime.isToday(date)) classes.push('today');
    if (this.isCompleted(date)) classes.push('completed');
    if (KellyTime.isFuture(date)) classes.push('future');
    
    return `
      <button 
        class="${classes.join(' ')}" 
        data-date="${iso}"
        ${isOtherMonth || KellyTime.isFuture(date) ? 'disabled' : ''}
      >
        ${date.getDate()}
      </button>
    `;
  },
  
  /**
   * Attach event listeners
   */
  attachEvents() {
    // Navigation
    this.container.querySelectorAll('.calendar-nav').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const action = e.target.dataset.action;
        if (action === 'prev') this.prevMonth();
        if (action === 'next') this.nextMonth();
      });
    });
    
    // Day clicks
    this.container.querySelectorAll('.calendar-day:not([disabled])').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const date = KellyTime.parse(e.target.dataset.date);
        if (this.options.onDateClick) {
          this.options.onDateClick(date);
        }
      });
    });
  },
  
  /**
   * Calculate streak
   */
  getStreak() {
    if (this.completedDates.length === 0) return 0;
    
    const sorted = [...this.completedDates].sort().reverse();
    const todayIso = KellyTime.iso(KellyTime.now());
    const yesterdayDate = new Date(KellyTime.now());
    yesterdayDate.setDate(yesterdayDate.getDate() - 1);
    const yesterdayIso = KellyTime.iso(yesterdayDate);
    
    // Must have completed today or yesterday
    if (!sorted.includes(todayIso) && !sorted.includes(yesterdayIso)) {
      return 0;
    }
    
    let streak = 0;
    let checkDate = new Date(sorted[0]);
    
    for (const dateStr of sorted) {
      const date = new Date(dateStr);
      const diff = Math.abs((checkDate - date) / (1000 * 60 * 60 * 24));
      
      if (diff <= 1) {
        streak++;
        checkDate = date;
      } else {
        break;
      }
    }
    
    return streak;
  }
};

window.KellyCalendar = KellyCalendar;
```

### Kelly Lesson Module

```javascript
/**
 * KELLY LESSON MODULE
 * Fetches and manages lesson content
 * Used on index.html (preview) and learn.html (full)
 */
const KellyLesson = {
  supabaseUrl: null,
  supabaseKey: null,
  
  /**
   * Initialize with Supabase credentials
   */
  init(url, key) {
    this.supabaseUrl = url;
    this.supabaseKey = key;
  },
  
  /**
   * Get lesson for a specific date
   */
  async getLesson(date = KellyTime.now()) {
    const month = KellyTime.month(date);
    const day = KellyTime.day(date);
    
    // Check for leap day
    if (KellyTime.isLeapDay(date)) {
      return this.getLeapDayLesson();
    }
    
    try {
      const response = await fetch(
        `${this.supabaseUrl}/rest/v1/core_lessons?calendar_month=eq.${month}&calendar_day=eq.${day}&select=*`,
        {
          headers: {
            'apikey': this.supabaseKey,
            'Authorization': `Bearer ${this.supabaseKey}`
          }
        }
      );
      
      const data = await response.json();
      return data[0] || null;
    } catch (error) {
      console.error('Failed to fetch lesson:', error);
      return null;
    }
  },
  
  /**
   * Get leap day lesson
   */
  async getLeapDayLesson() {
    try {
      const response = await fetch(
        `${this.supabaseUrl}/rest/v1/core_lessons?is_leap_day=eq.true&select=*`,
        {
          headers: {
            'apikey': this.supabaseKey,
            'Authorization': `Bearer ${this.supabaseKey}`
          }
        }
      );
      
      const data = await response.json();
      return data[0] || {
        topic: 'The Gift of Extra Time',
        universal_truth: 'Some days are rare. Use them wisely.'
      };
    } catch (error) {
      console.error('Failed to fetch leap day lesson:', error);
      return null;
    }
  },
  
  /**
   * Get today's lesson (convenience method)
   */
  async getToday() {
    return this.getLesson(KellyTime.now());
  },
  
  /**
   * Get lesson atoms for a specific persona and phase
   */
  async getAtoms(lessonId, personaId, ageBucket) {
    try {
      const response = await fetch(
        `${this.supabaseUrl}/rest/v1/lesson_atoms?core_lesson_id=eq.${lessonId}&archetype=eq.${personaId}&select=*`,
        {
          headers: {
            'apikey': this.supabaseKey,
            'Authorization': `Bearer ${this.supabaseKey}`
          }
        }
      );
      
      return await response.json();
    } catch (error) {
      console.error('Failed to fetch atoms:', error);
      return [];
    }
  }
};

window.KellyLesson = KellyLesson;
```

### Kelly Presence Module

Kelly is ALWAYS on the calendar. Every second.

```javascript
/**
 * KELLY PRESENCE MODULE
 * Tracks Kelly's availability state
 * Used to show live classes, async availability, and more
 */
const KellyPresence = {
  states: {
    LIVE: 'live',           // Live class in progress
    UPCOMING: 'upcoming',   // Live class starting soon
    ASYNC: 'async',         // Between classes, lesson available
    SLEEP: 'sleep'          // 2-5 AM (gentle rest reminder)
  },
  
  // Live class schedule (local time)
  liveSchedule: [
    { hour: 6, label: 'Early Birds' },
    { hour: 9, label: 'Morning' },
    { hour: 12, label: 'Lunch' },
    { hour: 18, label: 'Evening' },
    { hour: 21, label: 'Night Owls' }
  ],
  
  /**
   * Get Kelly's current state
   */
  getCurrentState() {
    const now = KellyTime.now();
    const hour = now.getHours();
    const minute = now.getMinutes();
    
    // Check if live class is happening (15 min duration)
    for (const slot of this.liveSchedule) {
      if (hour === slot.hour && minute < 15) {
        return { state: this.states.LIVE, label: slot.label };
      }
    }
    
    // Check if live class is upcoming (within 30 min)
    for (const slot of this.liveSchedule) {
      if (hour === slot.hour - 1 && minute >= 30) {
        const minsUntil = 60 - minute;
        return { state: this.states.UPCOMING, label: slot.label, minutes: minsUntil };
      }
      if (hour === slot.hour && minute >= 15) {
        // Just ended, next one
        continue;
      }
    }
    
    // Sleep mode (2-5 AM)
    if (hour >= 2 && hour < 5) {
      return { state: this.states.SLEEP };
    }
    
    return { state: this.states.ASYNC };
  },
  
  /**
   * Get next live class
   */
  getNextLiveClass() {
    const now = KellyTime.now();
    const hour = now.getHours();
    const minute = now.getMinutes();
    
    for (const slot of this.liveSchedule) {
      if (slot.hour > hour || (slot.hour === hour && minute < 15)) {
        const next = new Date(now);
        next.setHours(slot.hour, 0, 0, 0);
        
        const diff = next - now;
        const hours = Math.floor(diff / (1000 * 60 * 60));
        const mins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        
        return {
          time: next,
          label: slot.label,
          hoursUntil: hours,
          minutesUntil: mins,
          display: hours > 0 ? `${hours}h ${mins}m` : `${mins}m`
        };
      }
    }
    
    // Tomorrow's first class
    const tomorrow = new Date(now);
    tomorrow.setDate(tomorrow.getDate() + 1);
    tomorrow.setHours(this.liveSchedule[0].hour, 0, 0, 0);
    
    const diff = tomorrow - now;
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const mins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    
    return {
      time: tomorrow,
      label: this.liveSchedule[0].label,
      hoursUntil: hours,
      minutesUntil: mins,
      display: `${hours}h ${mins}m`
    };
  },
  
  /**
   * Get status message for UI
   */
  getStatusMessage() {
    const status = this.getCurrentState();
    
    switch (status.state) {
      case this.states.LIVE:
        return { 
          badge: '🔴 LIVE NOW', 
          message: `Join the ${status.label} class!`,
          action: 'join'
        };
      case this.states.UPCOMING:
        return { 
          badge: `🔴 LIVE in ${status.minutes}m`, 
          message: `${status.label} class starting soon`,
          action: 'remind'
        };
      case this.states.SLEEP:
        return { 
          badge: '😴', 
          message: `Get some rest. I'll be here when you wake up.`,
          action: null
        };
      default:
        const next = this.getNextLiveClass();
        return { 
          badge: `Next: ${next.display}`, 
          message: `${next.label} class at ${KellyTime.time(next.time)}`,
          action: 'schedule'
        };
    }
  }
};

window.KellyPresence = KellyPresence;
```

### Live Class Component

```html
<!-- Live class indicator - shows on both pages -->
<div class="kelly-live-status" id="kelly-live-status">
  <span class="live-badge" id="live-badge">🔴 LIVE NOW</span>
  <span class="live-message" id="live-message">Join 1,847 learners</span>
  <button class="kelly-btn kelly-btn-primary" id="live-action">
    Join Class
  </button>
</div>

<style>
.kelly-live-status {
  display: flex;
  align-items: center;
  gap: var(--space-3);
  padding: var(--space-3) var(--space-4);
  background: linear-gradient(135deg, rgba(239, 68, 68, 0.1), rgba(239, 68, 68, 0.05));
  border: 1px solid rgba(239, 68, 68, 0.3);
  border-radius: var(--radius-xl);
}

.kelly-live-status.upcoming {
  background: linear-gradient(135deg, rgba(59, 130, 246, 0.1), rgba(59, 130, 246, 0.05));
  border-color: rgba(59, 130, 246, 0.3);
}

.live-badge {
  font-size: var(--text-sm);
  font-weight: var(--weight-bold);
  color: #ef4444;
  animation: pulse 2s infinite;
}

@keyframes pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.7; }
}

.live-message {
  font-size: var(--text-sm);
  color: var(--text-secondary);
}
</style>
```

```javascript
// Update live status every minute
function updateLiveStatus() {
  const statusEl = document.getElementById('kelly-live-status');
  const badgeEl = document.getElementById('live-badge');
  const messageEl = document.getElementById('live-message');
  const actionEl = document.getElementById('live-action');
  
  const status = KellyPresence.getStatusMessage();
  
  badgeEl.textContent = status.badge;
  messageEl.textContent = status.message;
  
  if (status.action === 'join') {
    actionEl.textContent = 'Join Class';
    actionEl.onclick = () => window.location.href = '/live.html';
    statusEl.classList.remove('upcoming');
  } else if (status.action === 'remind') {
    actionEl.textContent = 'Remind Me';
    statusEl.classList.add('upcoming');
  } else {
    actionEl.style.display = 'none';
  }
}

// Update immediately and every minute
updateLiveStatus();
setInterval(updateLiveStatus, 60000);
```

---

## PART 4: INDEX.HTML STRUCTURE

### Complete HTML

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Curious Kelly — The Daily Learning Calendar</title>
  
  <!-- SEO -->
  <meta name="description" content="The calendar that makes you smarter every day. One beautiful lesson, every day, for everyone. Ages 2 to 102.">
  <meta name="keywords" content="daily learning, learning calendar, AI teacher, education app, micro-lessons, daily habit">
  
  <!-- Open Graph -->
  <meta property="og:title" content="Curious Kelly — The Daily Learning Calendar">
  <meta property="og:description" content="The calendar that makes you smarter every day.">
  <meta property="og:image" content="https://curiouskelly.com/og-image.jpg">
  <meta property="og:url" content="https://curiouskelly.com">
  <meta property="og:type" content="website">
  
  <!-- Twitter -->
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="Curious Kelly">
  <meta name="twitter:description" content="The calendar that makes you smarter every day.">
  <meta name="twitter:image" content="https://curiouskelly.com/twitter-card.jpg">
  
  <!-- Favicon -->
  <link rel="icon" href="/favicon.ico">
  <link rel="apple-touch-icon" href="/icons/apple-touch-icon.png">
  
  <!-- Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
  
  <!-- Shared Styles -->
  <link rel="stylesheet" href="/styles/kelly-system.css">
  <link rel="stylesheet" href="/styles/index.css">
</head>
<body>
  <!-- NAV -->
  <nav class="nav">
    <a href="/" class="nav-logo">
      <img src="/images/logo.svg" alt="Curious Kelly">
    </a>
    <div class="nav-links">
      <a href="#how-it-works">How It Works</a>
      <a href="#pricing">Pricing</a>
      <a href="/learn.html" class="kelly-btn kelly-btn-primary">Open Calendar</a>
    </div>
  </nav>

  <!-- HERO: Calendar-First -->
  <section class="hero">
    <div class="hero-content">
      <div class="kelly-date" id="hero-date">
        <!-- Populated by JS -->
      </div>
      
      <h1>The calendar that makes you smarter every day.</h1>
      
      <div class="kelly-topic" id="hero-topic">
        <span class="kelly-topic-label">Today's lesson</span>
        <span class="kelly-topic-title" id="hero-topic-title">Loading...</span>
      </div>
      
      <p class="hero-learners">
        <span id="hero-learner-count">47,328</span> people learning this right now
      </p>
      
      <a href="/learn.html" class="kelly-btn kelly-btn-primary kelly-btn-large">
        Start Today's Lesson — Free
      </a>
    </div>
    
    <div class="hero-calendar">
      <div class="kelly-calendar-mini" id="hero-calendar">
        <!-- Populated by KellyCalendar -->
      </div>
      
      <div class="hero-calendar-features">
        <div class="feature">
          <span class="feature-icon">📚</span>
          <span>One topic per day</span>
        </div>
        <div class="feature">
          <span class="feature-icon">⏱️</span>
          <span>5 minutes</span>
        </div>
        <div class="feature">
          <span class="feature-icon">🔥</span>
          <span>Build streaks</span>
        </div>
      </div>
    </div>
  </section>

  <!-- VALUE PROP: Why a Calendar? -->
  <section class="why-calendar">
    <h2>Your calendar should teach you something.</h2>
    
    <div class="comparison">
      <div class="comparison-old">
        <h3>Regular calendars</h3>
        <ul>
          <li>Show you meetings</li>
          <li>Remind you of obligations</li>
          <li>Make you feel busy</li>
          <li>Empty boxes</li>
        </ul>
      </div>
      
      <div class="comparison-new">
        <h3>Kelly</h3>
        <ul>
          <li>Every day has meaning</li>
          <li>Learn something beautiful</li>
          <li>Build streaks and grow</li>
          <li>Never an empty day</li>
        </ul>
      </div>
    </div>
  </section>

  <!-- HOW IT WORKS -->
  <section class="how-it-works" id="how-it-works">
    <h2>A new kind of daily ritual</h2>
    
    <div class="steps">
      <div class="step">
        <div class="step-visual">
          <div class="kelly-calendar-mini small" id="step1-calendar"></div>
        </div>
        <h3>Open your calendar</h3>
        <p>Every day has a topic. December 12 is always "The Science of Sleep." January 1 is always "Starting Fresh."</p>
      </div>
      
      <div class="step">
        <div class="step-visual">
          <img src="/images/kelly-teaching.png" alt="Kelly teaching">
        </div>
        <h3>Learn from Kelly</h3>
        <p>5 minutes. 5 phases. Kelly teaches you something beautiful, adapted to your age and style.</p>
      </div>
      
      <div class="step">
        <div class="step-visual">
          <div class="streak-visual">
            <span class="streak-fire">🔥</span>
            <span class="streak-number">7</span>
          </div>
        </div>
        <h3>Build your streak</h3>
        <p>Complete lessons to build streaks. Watch your calendar fill with knowledge.</p>
      </div>
    </div>
  </section>

  <!-- THE 12 KELLYS -->
  <section class="personas">
    <h2>12 teaching styles. One perfect match.</h2>
    <p class="section-intro">Kelly adapts her personality to match how you learn best.</p>
    
    <div class="persona-grid" id="persona-grid">
      <!-- Populated by JS -->
    </div>
  </section>

  <!-- EVERY AGE -->
  <section class="every-age">
    <h2>Ages 2 to 102</h2>
    <p class="section-intro">Kelly transforms to meet you where you are.</p>
    
    <div class="age-demo">
      <input type="range" id="age-slider" min="2" max="102" value="35">
      <div class="age-display">
        <img src="/images/kelly-adult.png" alt="Kelly" id="age-kelly-image">
        <div class="age-info">
          <span class="age-number" id="age-number">35</span>
          <span class="age-bucket" id="age-bucket">Adult Learner</span>
        </div>
      </div>
    </div>
  </section>

  <!-- WIDGETS -->
  <section class="widgets">
    <h2>Kelly everywhere you need her</h2>
    
    <div class="widget-showcase">
      <div class="widget-card">
        <h3>Website Widget</h3>
        <p>Embed Kelly on your school or company site.</p>
        <div class="widget-preview">
          <div class="kelly-widget-demo">
            <span class="widget-date">Dec 12</span>
            <span class="widget-topic">The Science of Sleep</span>
            <span class="widget-cta">Learn →</span>
          </div>
        </div>
      </div>
      
      <div class="widget-card">
        <h3>Calendar Integration</h3>
        <p>Add Kelly lessons to Google Calendar or Apple Calendar.</p>
        <div class="widget-preview">
          <div class="calendar-event-demo">
            📘 Kelly: The Science of Sleep (5 min)
          </div>
        </div>
      </div>
      
      <div class="widget-card">
        <h3>API Access</h3>
        <p>Build Kelly into your own products.</p>
        <code>GET /api/today</code>
      </div>
    </div>
  </section>

  <!-- PRICING -->
  <section class="pricing" id="pricing">
    <h2>Simple pricing</h2>
    
    <div class="pricing-cards">
      <div class="pricing-card">
        <h3>Monthly</h3>
        <div class="price">$9.99<span>/month</span></div>
        <a href="/learn.html?plan=monthly" class="kelly-btn kelly-btn-secondary">Start Monthly</a>
      </div>
      
      <div class="pricing-card featured">
        <div class="badge">Best Value</div>
        <h3>Yearly</h3>
        <div class="price">$79.99<span>/year</span></div>
        <p class="savings">Save 33%</p>
        <a href="/learn.html?plan=yearly" class="kelly-btn kelly-btn-primary">Start Yearly</a>
      </div>
      
      <div class="pricing-card">
        <h3>Lifetime</h3>
        <div class="price">$199.99<span>one-time</span></div>
        <a href="/learn.html?plan=lifetime" class="kelly-btn kelly-btn-secondary">Get Lifetime</a>
      </div>
    </div>
    
    <p class="pricing-note">Today's lesson is free. No credit card required.</p>
  </section>

  <!-- FAQ -->
  <section class="faq" id="faq">
    <h2>Questions?</h2>
    
    <div class="faq-list">
      <details>
        <summary>Why a calendar?</summary>
        <p>Learning works best as a daily habit. By tying lessons to calendar dates—not arbitrary "Day 1, Day 2"—everyone learns together, and every date has permanent meaning.</p>
      </details>
      
      <details>
        <summary>What if I miss a day?</summary>
        <p>You can always go back and learn past lessons. Your streak might reset, but your knowledge doesn't.</p>
      </details>
      
      <details>
        <summary>Is December 12 always the same topic?</summary>
        <p>Yes! Every calendar date has one topic, forever. December 12 is always "The Science of Sleep." January 1 is always "Starting Fresh." This means you can revisit the same lesson years later with fresh perspective.</p>
      </details>
      
      <details>
        <summary>Who is Kelly?</summary>
        <p>Kelly is named after a real person—a Deaf teacher who teaches ASL. The digital Kelly honors her legacy by making education accessible and personal for everyone.</p>
      </details>
      
      <details>
        <summary>What ages is this for?</summary>
        <p>Kelly teaches learners ages 2 to 102. She transforms her appearance, vocabulary, and teaching style to match each learner's age.</p>
      </details>
    </div>
  </section>

  <!-- FOOTER -->
  <footer class="footer">
    <div class="footer-content">
      <div class="footer-brand">
        <img src="/images/logo.svg" alt="Curious Kelly">
        <p>The calendar that makes you smarter every day.</p>
      </div>
      
      <div class="footer-links">
        <div>
          <h4>Product</h4>
          <a href="/learn.html">Open Calendar</a>
          <a href="#how-it-works">How It Works</a>
          <a href="#pricing">Pricing</a>
        </div>
        <div>
          <h4>Company</h4>
          <a href="/about">About</a>
          <a href="/blog">Blog</a>
          <a href="/careers">Careers</a>
        </div>
        <div>
          <h4>Legal</h4>
          <a href="/privacy">Privacy</a>
          <a href="/terms">Terms</a>
          <a href="/coppa">COPPA</a>
        </div>
      </div>
    </div>
    
    <div class="footer-bottom">
      <p>© 2025 Curious Kelly</p>
    </div>
  </footer>

  <!-- Scripts -->
  <script src="/js/kelly-time.js"></script>
  <script src="/js/kelly-calendar.js"></script>
  <script src="/js/kelly-lesson.js"></script>
  <script src="/js/index.js"></script>
</body>
</html>
```

### Index Page JavaScript

```javascript
// /js/index.js

document.addEventListener('DOMContentLoaded', async () => {
  // Initialize date display
  updateDateDisplay();
  
  // Initialize calendar
  KellyCalendar.init('hero-calendar', {
    showNavigation: true,
    onDateClick: (date) => {
      // Go to learn.html with date
      window.location.href = `/learn.html?date=${KellyTime.iso(date)}`;
    }
  });
  
  // Initialize smaller step calendar
  KellyCalendar.init('step1-calendar', {
    showNavigation: false
  });
  
  // Load today's lesson
  await loadTodayLesson();
  
  // Initialize personas
  initPersonaGrid();
  
  // Initialize age slider
  initAgeSlider();
});

function updateDateDisplay() {
  const dateEl = document.getElementById('hero-date');
  dateEl.innerHTML = `
    <span class="kelly-date-day">${KellyTime.dayName()}</span>
    <span class="kelly-date-full">${KellyTime.fullDate()}</span>
  `;
}

async function loadTodayLesson() {
  // Initialize with Supabase credentials from config
  KellyLesson.init(window.KELLY_CONFIG.supabaseUrl, window.KELLY_CONFIG.supabaseKey);
  
  const lesson = await KellyLesson.getToday();
  
  if (lesson) {
    document.getElementById('hero-topic-title').textContent = lesson.topic;
  } else {
    document.getElementById('hero-topic-title').textContent = 'Something amazing';
  }
}

function initPersonaGrid() {
  const personas = [
    { id: 'scientist', name: 'The Scientist', emoji: '🔬', desc: 'Data-driven precision' },
    { id: 'explorer', name: 'The Explorer', emoji: '🌎', desc: 'Wonder-filled discovery' },
    { id: 'rebel', name: 'The Rebel', emoji: '⚡', desc: 'Question everything' },
    { id: 'architect', name: 'The Architect', emoji: '📐', desc: 'Build understanding' },
    { id: 'diplomat', name: 'The Diplomat', emoji: '🤝', desc: 'Every perspective' },
    { id: 'empath', name: 'The Empath', emoji: '💜', desc: 'Feel to understand' },
    { id: 'macgyver', name: 'The MacGyver', emoji: '🔧', desc: 'Practical wisdom' },
    { id: 'mystic', name: 'The Mystic', emoji: '🔮', desc: 'Deep meaning' },
    { id: 'provider', name: 'The Provider', emoji: '🏠', desc: 'Care and nurture' },
    { id: 'storyteller', name: 'The Storyteller', emoji: '📖', desc: 'Narrative magic' },
    { id: 'strategist', name: 'The Strategist', emoji: '♟️', desc: 'Long-game thinking' },
    { id: 'survivor', name: 'The Survivor', emoji: '🏔️', desc: 'Hard-won wisdom' }
  ];
  
  const grid = document.getElementById('persona-grid');
  grid.innerHTML = personas.map(p => `
    <a href="/learn.html?kelly=${p.id}" class="persona-card">
      <span class="persona-emoji">${p.emoji}</span>
      <span class="persona-name">${p.name}</span>
      <span class="persona-desc">${p.desc}</span>
    </a>
  `).join('');
}

function initAgeSlider() {
  const slider = document.getElementById('age-slider');
  const numberEl = document.getElementById('age-number');
  const bucketEl = document.getElementById('age-bucket');
  const imageEl = document.getElementById('age-kelly-image');
  
  const buckets = [
    { max: 12, name: 'Young Explorer', image: '/images/kelly-kid.png' },
    { max: 17, name: 'Teen Learner', image: '/images/kelly-teen.png' },
    { max: 49, name: 'Adult Learner', image: '/images/kelly-adult.png' },
    { max: 75, name: 'Wise Learner', image: '/images/kelly-elder.png' },
    { max: 102, name: 'Life Master', image: '/images/kelly-super-elder.png' }
  ];
  
  slider.addEventListener('input', (e) => {
    const age = parseInt(e.target.value);
    numberEl.textContent = age;
    
    const bucket = buckets.find(b => age <= b.max);
    bucketEl.textContent = bucket.name;
    imageEl.src = bucket.image;
  });
}
```

---

## PART 5: LEARN.HTML STRUCTURE

The app inherits the same design system and shows the same date/calendar:

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
  <title>Curious Kelly</title>
  
  <!-- PWA -->
  <link rel="manifest" href="/manifest.json">
  <meta name="theme-color" content="#0a0a0f">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
  
  <!-- Shared Styles -->
  <link rel="stylesheet" href="/styles/kelly-system.css">
  <link rel="stylesheet" href="/styles/learn.css">
</head>
<body>
  <!-- SCENES -->
  
  <!-- Scene: Character Select -->
  <div id="scene-character" class="scene">
    <div class="scene-header">
      <div class="kelly-date" id="character-date"></div>
    </div>
    
    <div class="kelly-topic" id="character-topic">
      <span class="kelly-topic-label">Today's lesson</span>
      <span class="kelly-topic-title" id="character-topic-title">Loading...</span>
    </div>
    
    <p class="character-prompt">Who should teach you today?</p>
    
    <div class="kelly-carousel" id="kelly-carousel">
      <!-- Kelly cards populated by JS -->
    </div>
    
    <button class="kelly-btn kelly-btn-primary kelly-btn-large" id="start-lesson">
      Start with <span id="selected-kelly-name">The Scientist</span>
    </button>
  </div>
  
  <!-- Scene: Lesson Player -->
  <div id="scene-lesson" class="scene hidden">
    <div class="lesson-header">
      <button class="back-btn" onclick="showScene('character')">←</button>
      <div class="kelly-date compact" id="lesson-date"></div>
      <button class="bookmark-btn" id="bookmark-btn">🔖</button>
    </div>
    
    <div class="lesson-topic" id="lesson-topic-display"></div>
    
    <div class="kelly-display">
      <img src="" alt="Kelly" id="kelly-image" class="kelly-image">
      <div class="kelly-name" id="kelly-name-display"></div>
    </div>
    
    <div class="phase-progress">
      <div class="phase-dots" id="phase-dots"></div>
      <div class="phase-label" id="phase-label">Hook</div>
    </div>
    
    <div class="lesson-content" id="lesson-content">
      <!-- Content populated by JS -->
    </div>
    
    <div class="lesson-controls">
      <button class="control-btn" id="prev-phase" disabled>← Back</button>
      <button class="control-btn primary" id="next-phase">Next →</button>
    </div>
  </div>
  
  <!-- Scene: Completion -->
  <div id="scene-complete" class="scene hidden">
    <div class="completion-content">
      <div class="confetti" id="confetti"></div>
      
      <h1>Beautiful! 🎉</h1>
      
      <div class="completion-date">
        <span id="complete-date"></span>
        <span class="checkmark">✓</span>
      </div>
      
      <div class="kelly-streak" id="completion-streak">
        <span class="kelly-streak-fire">🔥</span>
        <span class="kelly-streak-count" id="streak-count">1</span>
        <span class="kelly-streak-label">day streak</span>
      </div>
      
      <div class="tomorrow-preview">
        <span class="tomorrow-label">Tomorrow's lesson</span>
        <span class="tomorrow-topic" id="tomorrow-topic">Loading...</span>
      </div>
      
      <button class="kelly-btn kelly-btn-primary" onclick="showScene('journey')">
        View Your Calendar
      </button>
    </div>
  </div>
  
  <!-- Scene: Journey (Calendar View) -->
  <div id="scene-journey" class="scene hidden">
    <div class="scene-header">
      <h2>Your Learning Calendar</h2>
    </div>
    
    <div class="kelly-streak" id="journey-streak"></div>
    
    <div class="kelly-calendar-full" id="journey-calendar">
      <!-- Full calendar populated by KellyCalendar -->
    </div>
    
    <div class="journey-stats">
      <div class="stat">
        <span class="stat-value" id="stat-completed">0</span>
        <span class="stat-label">Days Completed</span>
      </div>
      <div class="stat">
        <span class="stat-value" id="stat-streak">0</span>
        <span class="stat-label">Current Streak</span>
      </div>
    </div>
  </div>
  
  <!-- Scene: Settings -->
  <div id="scene-settings" class="scene hidden">
    <div class="scene-header">
      <h2>Settings</h2>
    </div>
    
    <div class="settings-group">
      <label>Your Age</label>
      <div class="age-slider-container">
        <input type="range" id="settings-age" min="2" max="102" value="35">
        <span id="settings-age-display">35</span>
      </div>
    </div>
    
    <div class="settings-group">
      <label>Your Kelly</label>
      <select id="settings-kelly">
        <!-- Options populated by JS -->
      </select>
    </div>
    
    <div class="settings-group">
      <label>Voice Speed</label>
      <input type="range" id="settings-speed" min="0.5" max="1.5" step="0.1" value="1">
    </div>
    
    <div class="settings-group">
      <label>Daily Reminder</label>
      <input type="time" id="settings-reminder" value="09:00">
      <button class="kelly-btn kelly-btn-secondary" id="enable-notifications">
        Enable Notifications
      </button>
    </div>
  </div>
  
  <!-- Bottom Navigation -->
  <nav class="bottom-nav">
    <button class="nav-item active" data-scene="character">
      <span class="nav-icon">📅</span>
      <span class="nav-label">Today</span>
    </button>
    <button class="nav-item" data-scene="journey">
      <span class="nav-icon">🗓️</span>
      <span class="nav-label">Calendar</span>
    </button>
    <button class="nav-item" data-scene="settings">
      <span class="nav-icon">⚙️</span>
      <span class="nav-label">Settings</span>
    </button>
  </nav>

  <!-- Scripts -->
  <script src="/js/kelly-time.js"></script>
  <script src="/js/kelly-calendar.js"></script>
  <script src="/js/kelly-lesson.js"></script>
  <script src="/config.js"></script>
  <script src="/js/learn.js"></script>
</body>
</html>
```

---

## PART 6: FILE STRUCTURE

```
public/
├── index.html              # Landing page
├── learn.html              # App
├── manifest.json           # PWA manifest
├── config.js               # Runtime config (Supabase keys)
├── sw.js                   # Service worker
│
├── styles/
│   ├── kelly-system.css    # SHARED design system
│   ├── index.css           # index.html specific styles
│   └── learn.css           # learn.html specific styles
│
├── js/
│   ├── kelly-time.js       # SHARED time utilities
│   ├── kelly-calendar.js   # SHARED calendar component
│   ├── kelly-lesson.js     # SHARED lesson fetching
│   ├── index.js            # index.html specific logic
│   └── learn.js            # learn.html specific logic
│
├── images/
│   ├── logo.svg
│   ├── kelly-scientist-*.png  # All Kelly variants
│   ├── og-image.jpg
│   └── ...
│
└── icons/
    ├── icon-192.png
    ├── icon-512.png
    └── apple-touch-icon.png
```

---

## PART 7: SYNC REQUIREMENTS

### State Must Match

When user goes from index.html → learn.html:
- Same date displayed
- Same topic displayed
- Calendar state transfers
- Streak is accurate

### URL Parameters

```javascript
// index.html can pass context to learn.html
const params = new URLSearchParams(window.location.search);

// Date selection
const dateParam = params.get('date'); // "2025-12-12"
if (dateParam) {
  state.selectedDate = KellyTime.parse(dateParam);
}

// Kelly selection
const kellyParam = params.get('kelly'); // "scientist"
if (kellyParam) {
  state.kellyId = kellyParam;
}

// Plan selection (from pricing)
const planParam = params.get('plan'); // "monthly", "yearly", "lifetime"
if (planParam) {
  showPaywall(planParam);
}
```

### Shared State Storage

```javascript
// Both pages use the same localStorage keys
const STORAGE_KEYS = {
  completedDates: 'kelly_completed_dates',
  currentKelly: 'kelly_current_persona',
  currentAge: 'kelly_current_age',
  settings: 'kelly_settings'
};

// Load state (works on both pages)
function loadState() {
  return {
    completedDates: JSON.parse(localStorage.getItem(STORAGE_KEYS.completedDates) || '[]'),
    kellyId: localStorage.getItem(STORAGE_KEYS.currentKelly) || 'scientist',
    age: parseInt(localStorage.getItem(STORAGE_KEYS.currentAge) || '35'),
    settings: JSON.parse(localStorage.getItem(STORAGE_KEYS.settings) || '{}')
  };
}

// Save state (works on both pages)
function saveState(state) {
  localStorage.setItem(STORAGE_KEYS.completedDates, JSON.stringify(state.completedDates));
  localStorage.setItem(STORAGE_KEYS.currentKelly, state.kellyId);
  localStorage.setItem(STORAGE_KEYS.currentAge, state.age.toString());
  localStorage.setItem(STORAGE_KEYS.settings, JSON.stringify(state.settings));
}
```

---

## PART 8: EMBEDDABLE WIDGET

For other sites to embed Kelly:

```html
<!-- Embed code for partners -->
<script src="https://curiouskelly.com/widget.js"></script>
<div id="kelly-widget" data-size="small"></div>

<!-- widget.js creates this: -->
<div class="kelly-widget">
  <div class="kelly-widget-date">Thu, Dec 12</div>
  <div class="kelly-widget-topic">The Science of Sleep</div>
  <a href="https://curiouskelly.com/learn.html" class="kelly-widget-cta">
    Learn in 5 min →
  </a>
</div>
```

Widget sizes:
- **small:** Date + topic + CTA (300×100)
- **medium:** + Kelly image (300×200)
- **large:** + Mini calendar (400×400)

---

## PART 9: CALENDAR EXPORT

Let users add Kelly to existing calendars:

```javascript
// Generate .ics file for today's lesson
function generateICS(lesson, date) {
  const start = new Date(date);
  start.setHours(9, 0, 0); // 9 AM
  
  const end = new Date(start);
  end.setMinutes(end.getMinutes() + 5); // 5 min lesson
  
  const ics = `BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Curious Kelly//EN
BEGIN:VEVENT
UID:${KellyTime.iso(date)}@curiouskelly.com
DTSTART:${formatICSDate(start)}
DTEND:${formatICSDate(end)}
SUMMARY:Kelly: ${lesson.topic}
DESCRIPTION:Your daily 5-minute lesson from Curious Kelly.\\n\\nOpen: https://curiouskelly.com/learn.html
URL:https://curiouskelly.com/learn.html?date=${KellyTime.iso(date)}
END:VEVENT
END:VCALENDAR`;
  
  return ics;
}

// Add full year to Google Calendar
function getGoogleCalendarURL() {
  // Returns URL to add Kelly as a subscribed calendar
  return 'https://calendar.google.com/calendar/render?cid=https://curiouskelly.com/calendar.ics';
}
```

---

## PART 10: EXECUTION CHECKLIST

### Day 1: Shared System
```
[ ] Create /styles/kelly-system.css with all tokens
[ ] Create /js/kelly-time.js
[ ] Create /js/kelly-calendar.js
[ ] Create /js/kelly-lesson.js
[ ] Test modules work independently
```

### Day 2: Index.html
```
[ ] Build new index.html with calendar-first hero
[ ] Create /styles/index.css
[ ] Create /js/index.js
[ ] Wire up calendar preview
[ ] Wire up today's topic
[ ] Test responsiveness
```

### Day 3: Learn.html Updates
```
[ ] Update learn.html to use shared modules
[ ] Create /styles/learn.css (removing duplicates)
[ ] Update /js/learn.js to use shared modules
[ ] Ensure calendar scene uses KellyCalendar
[ ] Test state sync with index.html
```

### Day 4: Widget & Export
```
[ ] Create /widget.js for embedding
[ ] Create calendar.ics generator
[ ] Create /api/today endpoint (Vercel function)
[ ] Test embeds on external page
```

### Day 5: Polish & QA
```
[ ] Test full flow: index → learn → complete → journey
[ ] Test URL parameters work
[ ] Test state persists across pages
[ ] Test on iPhone, Android, Desktop
[ ] Lighthouse audit both pages
[ ] Fix any date/time inconsistencies
```

---

## SUCCESS CRITERIA

### Same Experience Test
1. Open index.html — see today's date and topic
2. Click "Start Learning" — go to learn.html
3. Same date, same topic, no flicker
4. Complete lesson — mark date green
5. Return to index.html — calendar shows green
6. **Feels like ONE app, not two pages**

### Calendar Replacement Test
"Would I replace my phone's calendar widget with Kelly?"
- Shows today prominently ✓
- Shows the week/month ✓
- Has something meaningful for every day ✓
- Makes me want to open it daily ✓

---

*Curious Kelly Unified Directive*
*December 12, 2025*
*"The calendar that makes you smarter every day."*
