# CURIOUS KELLY — QUICK TEST CHECKLIST
## Manual Testing Reference for Launch

---

## 🔥 CRITICAL PATH (Must Pass Before Launch)

### Happy Path - New User
```
1. [ ] Open curiouskelly.com/learn.html
2. [ ] See 12 Kellys in carousel (REAL IMAGES, not emoji)
3. [ ] Swipe to select Explorer
4. [ ] Tap "Let's Learn"
5. [ ] See Day 1 lesson load ("Starting Fresh")
6. [ ] Tap right 5 times (all phases)
7. [ ] See completion screen with confetti
8. [ ] Streak shows "1"
9. [ ] Tap "Continue Journey"
10. [ ] Day 2 loads
11. [ ] Close browser, reopen
12. [ ] Still on Day 2 with Explorer selected
```

**Time to complete: < 3 minutes**  
**Pass criteria: All 12 steps work**

---

## 📱 DEVICE QUICK CHECKS

### iPhone (Safari)
```
[ ] No horizontal scroll
[ ] Bottom nav above home indicator
[ ] Kelly images load (not emoji)
[ ] Audio plays on tap (may need unmute)
[ ] Swipe gestures work
[ ] Keyboard doesn't break layout
```

### Android (Chrome)
```
[ ] No horizontal scroll
[ ] Navigation bar colored
[ ] Kelly images load (not emoji)
[ ] Audio plays
[ ] Swipe gestures work
[ ] Back button navigates in app
```

### Desktop (Chrome)
```
[ ] Layout centered/contained
[ ] Arrow keys navigate phases
[ ] Mouse hover states work
[ ] No console errors
```

---

## 🎭 EACH KELLY PERSONA CHECK

| Persona | Image Loads | Color Changes | Quote Shows |
|---------|-------------|---------------|-------------|
| Scientist | [ ] | [ ] | [ ] |
| Explorer | [ ] | [ ] | [ ] |
| Rebel | [ ] | [ ] | [ ] |
| Architect | [ ] | [ ] | [ ] |
| Diplomat | [ ] | [ ] | [ ] |
| Empath | [ ] | [ ] | [ ] |
| MacGyver | [ ] | [ ] | [ ] |
| Mystic | [ ] | [ ] | [ ] |
| Provider | [ ] | [ ] | [ ] |
| Storyteller | [ ] | [ ] | [ ] |
| Strategist | [ ] | [ ] | [ ] |
| Survivor | [ ] | [ ] | [ ] |

---

## 👶 AGE BUCKET CHECKS

| Age | Set | Image Changes | Bucket |
|-----|-----|---------------|--------|
| 5 | [ ] | [ ] | kid |
| 15 | [ ] | [ ] | teen |
| 30 | [ ] | [ ] | adult |
| 60 | [ ] | [ ] | elder |
| 85 | [ ] | [ ] | super_elder |

---

## ⚙️ SETTINGS FUNCTIONALITY

```
[ ] Age slider moves (2-102)
[ ] Age slider updates Kelly images
[ ] Language picker opens
[ ] Voice speed picker opens
[ ] Reminder toggle switches
[ ] Reminder toggle requests notification permission
[ ] Reminder time picker opens
[ ] Achievements shows correct count
[ ] Bookmarks shows correct count
[ ] Change Kelly button works
```

---

## 🗓️ JOURNEY FUNCTIONALITY

```
[ ] Week view shows 7 days
[ ] Week navigation (prev/next) works
[ ] Completed days highlighted
[ ] Current day has border
[ ] Locked days dimmed
[ ] Tap unlocked day → loads lesson
[ ] Calendar toggle switches view
[ ] Stats show correct numbers
```

---

## 🔊 AUDIO CHECKS

```
[ ] Audio plays during lesson (or text shows)
[ ] Kelly animation syncs with audio
[ ] Voice speed setting affects playback
[ ] Audio pauses when switching tabs
[ ] No audio on muted device (or prompt)
```

---

## 💾 PERSISTENCE CHECKS

```
[ ] Refresh page → same Kelly selected
[ ] Refresh page → same age
[ ] Refresh page → same day/phase
[ ] Close browser → state preserved (24h later)
[ ] Clear site data → resets to defaults
```

---

## 🌐 OFFLINE CHECKS

```
[ ] Turn off WiFi → toast appears
[ ] Current lesson continues working
[ ] Settings still accessible
[ ] Turn WiFi back on → toast appears
[ ] New lesson loads
```

---

## ♿ ACCESSIBILITY QUICK CHECK

```
[ ] All text readable (contrast)
[ ] All buttons tappable (44px+)
[ ] Images have alt text (check source)
[ ] VoiceOver can navigate carousel
[ ] Reduced motion respected (if set)
```

---

## 🚨 ERROR SCENARIOS

| Trigger | Expected |
|---------|----------|
| Bad manifest URL | Emoji fallback, app works |
| Supabase down | Fallback content loads |
| Invalid day number | Clamps to valid range |
| Invalid persona ID | Defaults to scientist |

---

## 📊 PERFORMANCE SPOT CHECK

```
[ ] App loads in < 3 seconds
[ ] Carousel swipe is smooth (no jank)
[ ] Scene transitions are smooth
[ ] No visible layout shift after load
```

---

## 🔐 SECURITY SPOT CHECK

```
[ ] View source: no API keys visible
[ ] Console: no leaked credentials
[ ] Network tab: HTTPS only
[ ] localStorage: no sensitive data exposed
```

---

## ✅ SIGN-OFF

**Tester:** ________________  
**Date:** ________________  
**Device:** ________________  
**OS Version:** ________________  
**Browser:** ________________  

**Result:** [ ] PASS / [ ] FAIL

**Notes:**
```




```

---

## 🆘 IF SOMETHING BREAKS

1. **Screenshot** the issue
2. **Note** exact steps to reproduce
3. **Check** browser console for errors
4. **Record** device + OS + browser version
5. **Report** to Nicolette immediately if P0/P1

---

*Quick reference for Curious Kelly launch testing*  
*December 2024*
