# CURIOUS KELLY APP DIRECTIVE
## Complete Learn.html Replacement - December 2024

---

## EXECUTIVE SUMMARY

Replace the current `public/learn.html` with the enhanced unified app experience. This is a **complete rewrite** that transforms the lesson player into a mobile-native, video-game-style learning app.

**Accent Color**: Blue (#3b82f6) - NOT purple
**Feel**: Mobile app, not website. Video game character select, not dropdown.
**Core Principle**: User never feels like they leave the screen - scenes transition smoothly within one unified experience.

---

## PART 1: THE UI SHELL

The complete UI is provided in the attached `kelly-app-enhanced.html` file. This contains:

### 5 SCENES (All in one HTML file, CSS-transitioned)

| Scene | ID | Purpose |
|-------|-----|---------|
| Character Select | `scene-character` | Video-game style Kelly picker with carousel |
| Lesson Player | `scene-lesson` | Stories-style phase progression |
| Journey | `scene-journey` | Week view + calendar view of 365 days |
| Settings | `scene-settings` | Full settings panel |
| Complete | `scene-complete` | Lesson completion celebration |
| Achievements | `scene-achievements` | Badge gallery |

### KEY UI ELEMENTS

**Character Carousel**
- Swipe/arrow navigation through 12 Kellys
- Center card shows: avatar, name, tagline, personality stats, speech bubble
- Glowing ring animation behind selected Kelly
- Smooth 3D-style scaling (center=100%, sides=55%)

**Lesson Player**
- Stories-style progress bars (5 phases)
- Tap zones: left=previous phase, right=next phase
- Visual ripple feedback on tap
- Side actions: Bookmark, Infographic, Ask Kelly
- Reaction buttons: 💡 Got it, 🤯 Wow, 💭 More
- Caption with typewriter effect option

**Journey (Calendar)**
- Two views: Week (detailed) and Grid (overview)
- Week view shows: day number, topic, preview text, status
- Grid view shows: monthly sections with theme labels
- Milestones marked (Day 7, 30, 100, 365)
- Stats: Streak, Completed, Time Learned

**Settings**
- Your Kelly preview card with "Change" button
- Age slider (2-102)
- Language, Voice Speed
- Notifications toggle + time
- Achievements, Bookmarks, Downloads links
- Profile, Family, Subscription
- About, Help, Feedback

**Bottom Navigation**
- 3 items: Journey (📅), Play (▶), Settings (⚙️)
- Center Play button is elevated/prominent
- Sticky at bottom with safe-area support

---

## PART 2: SUPABASE INTEGRATION

### Replace Static Data with Live Queries

**1. Kelly Personas (Already have this)**
```javascript
// Use existing kelly-personas-manifest.json
// Location: /assets/kelly/kelly-personas-manifest.json

async function loadKellyManifest() {
  const resp = await fetch('/assets/kelly/kelly-personas-manifest.json?v=2.0.0');
  return await resp.json();
}
```

**2. Lesson Content**
```javascript
async function loadLesson(dayNumber, archetype) {
  // Get core lesson
  const { data: coreLesson } = await supabase
    .from('core_lessons')
    .select('id, topic, universal_truth, marketing_headline')
    .eq('day_number', dayNumber)
    .single();
  
  if (!coreLesson) return null;
  
  // Get atoms for this archetype
  const { data: atoms } = await supabase
    .from('lesson_atoms')
    .select('phase, content, hd_video_url, visual_url, archetype')
    .eq('core_lesson_id', coreLesson.id)
    .eq('archetype', archetype)
    .order('phase');
  
  // Map to phases
  const phaseOrder = { Hook: 0, Fact1: 1, Fact2: 2, Fact3: 3, Wisdom: 4 };
  const phases = atoms.map(atom => ({
    name: atom.phase,
    index: phaseOrder[atom.phase],
    script: atom.content?.script || '',
    videoUrl: atom.hd_video_url,
    visualUrl: atom.visual_url,
    archetype: atom.archetype
  })).sort((a, b) => a.index - b.index);
  
  return {
    dayNumber,
    topic: coreLesson.topic,
    headline: coreLesson.marketing_headline,
    phases
  };
}
```

**3. Audio Playback**
```javascript
async function getAudioUrl(dayNumber, phase, personaId, ageBucket, language = 'en') {
  // Try pre-generated audio first
  const { data } = await supabase
    .from('kelly_video_assets')
    .select('public_url')
    .eq('day_number', dayNumber)
    .eq('phase', phase) // 'Hook', 'Fact1', etc.
    .eq('template', personaId)
    .eq('age_bucket', ageBucket)
    .eq('asset_type', 'audio')
    .eq('language', language)
    .in('status', ['validated', 'published', 'generated'])
    .limit(1);
  
  if (data?.[0]?.public_url) {
    return data[0].public_url;
  }
  
  // Fallback to /api/tts
  return null; // Will trigger TTS generation
}
```

**4. Video Playback (When HeyGen Ready)**
```javascript
async function getVideoUrl(dayNumber, phase, personaId, ageBucket) {
  const { data } = await supabase
    .from('kelly_video_assets')
    .select('public_url')
    .eq('day_number', dayNumber)
    .eq('phase', phase)
    .eq('template', personaId)
    .eq('age_bucket', ageBucket)
    .eq('asset_type', 'video')
    .in('status', ['validated', 'published'])
    .limit(1);
  
  return data?.[0]?.public_url || null;
}
```

---

## PART 3: KELLY HEAD IMAGES

### Replace Emoji with Actual Images

**Image Location**: Kelly heads are in the manifest
```javascript
// From kelly-personas-manifest.json
const cdnBase = manifest.cdnBase;
const persona = manifest.personas[personaId];
const headUrl = `${cdnBase}/${persona.images.headByAge[ageBucket] || persona.images.head}`;
```

**Age Buckets** (map user age to bucket):
```javascript
function getAgeBucket(age) {
  if (age <= 12) return 'kid';
  if (age <= 17) return 'teen';
  if (age <= 49) return 'adult';
  if (age <= 75) return 'elder';
  return 'super_elder';
}
```

**In Carousel** - Replace emoji with <img>:
```html
<!-- Before -->
<div class="avatar">🔬</div>

<!-- After -->
<img class="avatar-img" src="${headUrl}" alt="${kelly.name}" />
```

**CSS for avatar images**:
```css
.avatar-img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  border-radius: 50%;
  filter: drop-shadow(0 20px 40px rgba(0,0,0,0.4));
}
```

---

## PART 4: PERSONA TO ARCHETYPE MAPPING

```javascript
const PERSONA_TO_ARCHETYPE = {
  'scientist': 'The Scientist',
  'explorer': 'The Explorer',
  'rebel': 'The Rebel',
  'architect': 'The Architect',
  'diplomat': 'The Diplomat',
  'empath': 'The Empath',
  'macgyver': 'The MacGyver',
  'mystic': 'The Mystic',
  'provider': 'The Provider',
  'storyteller': 'The Storyteller',
  'strategist': 'The Strategist',
  'survivor': 'The Survivor'
};

// Usage
const archetype = PERSONA_TO_ARCHETYPE[state.kelly.id];
const lesson = await loadLesson(state.day, archetype);
```

---

## PART 5: STATE MANAGEMENT

```javascript
const state = {
  // User preferences (persist to localStorage + Supabase)
  kelly: null,           // Selected Kelly persona object
  age: 30,               // User's learning age (2-102)
  language: 'en',        // 'en', 'es', 'fr'
  
  // Progress (persist to Supabase user_progress)
  currentDay: 1,         // Current lesson day (1-365)
  currentPhase: 0,       // Current phase index (0-4)
  streak: 0,             // Consecutive days
  completedLessons: [],  // Array of completed day numbers
  bookmarks: [],         // Saved moments
  
  // Session (ephemeral)
  scene: 'character',    // Current scene
  carouselIndex: 0,      // Carousel position
  lesson: null,          // Loaded lesson data
  weekOffset: 0,         // Week view pagination
  viewMode: 'week',      // 'week' or 'grid'
};

// Persist on change
function saveState() {
  localStorage.setItem('kellyState', JSON.stringify({
    kelly: state.kelly?.id,
    age: state.age,
    language: state.language,
    currentDay: state.currentDay,
    streak: state.streak,
    completedLessons: state.completedLessons,
    bookmarks: state.bookmarks
  }));
}

// Load on init
function loadState() {
  const saved = JSON.parse(localStorage.getItem('kellyState') || '{}');
  if (saved.kelly) state.kelly = KELLYS.find(k => k.id === saved.kelly);
  if (saved.age) state.age = saved.age;
  // ... etc
}
```

---

## PART 6: AUDIO SYSTEM

```javascript
class KellyAudio {
  constructor() {
    this.audio = new Audio();
    this.audio.addEventListener('play', () => this.onSpeakStart());
    this.audio.addEventListener('ended', () => this.onSpeakEnd());
    this.audio.addEventListener('error', () => this.onError());
  }
  
  async speak(text, { audioUrl, language = 'en' }) {
    // If we have pre-generated audio, use it
    if (audioUrl) {
      this.audio.src = audioUrl;
      await this.audio.play();
      return;
    }
    
    // Otherwise, call /api/tts
    const response = await fetch('/api/tts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        text,
        voice_id: 'wAdymQH5YucAkXwmrdL0', // Kelly's ElevenLabs voice
        language
      })
    });
    
    const blob = await response.blob();
    this.audio.src = URL.createObjectURL(blob);
    await this.audio.play();
  }
  
  onSpeakStart() {
    document.getElementById('lesson-kelly').classList.add('speaking');
    document.getElementById('lesson-kelly').classList.remove('idle');
  }
  
  onSpeakEnd() {
    document.getElementById('lesson-kelly').classList.remove('speaking');
    document.getElementById('lesson-kelly').classList.add('idle');
  }
  
  onError() {
    console.error('Audio playback failed');
    this.onSpeakEnd();
  }
  
  stop() {
    this.audio.pause();
    this.audio.currentTime = 0;
    this.onSpeakEnd();
  }
}
```

---

## PART 7: LESSON FLOW

```javascript
async function startLesson(dayNumber) {
  state.currentDay = dayNumber;
  state.currentPhase = 0;
  
  // Get archetype from selected Kelly
  const archetype = PERSONA_TO_ARCHETYPE[state.kelly.id];
  const ageBucket = getAgeBucket(state.age);
  
  // Load lesson
  state.lesson = await loadLesson(dayNumber, archetype);
  
  if (!state.lesson) {
    showError("Let me try that again...");
    return;
  }
  
  // Update UI
  document.getElementById('day-badge').innerHTML = `
    <span class="day-num">Day ${dayNumber}</span>
    <span class="topic">${state.lesson.topic}</span>
  `;
  
  // Build phase progress
  buildPhaseProgress();
  
  // Show lesson scene
  showScene('lesson');
  
  // Play first phase
  playPhase(0);
}

async function playPhase(index) {
  const phase = state.lesson.phases[index];
  if (!phase) return;
  
  state.currentPhase = index;
  updatePhaseProgress();
  
  // Update caption
  document.getElementById('caption-phase').innerHTML = `
    <span class="phase-icon">${getPhaseIcon(phase.name)}</span>
    <span class="phase-name">${phase.name}</span>
  `;
  
  // Typewriter effect for caption
  await typewriterEffect(document.getElementById('caption-text'), phase.script);
  
  // Get and play audio
  const ageBucket = getAgeBucket(state.age);
  const audioUrl = await getAudioUrl(
    state.currentDay, 
    phase.name, 
    state.kelly.id, 
    ageBucket, 
    state.language
  );
  
  await kellyAudio.speak(phase.script, { audioUrl, language: state.language });
}

function getPhaseIcon(phaseName) {
  const icons = {
    'Hook': '🪝',
    'Fact1': '💡',
    'Fact2': '💡',
    'Fact3': '💡',
    'Wisdom': '✨'
  };
  return icons[phaseName] || '📚';
}

async function typewriterEffect(element, text, speed = 30) {
  element.classList.add('typing');
  element.textContent = '';
  
  for (let i = 0; i < text.length; i++) {
    element.textContent += text[i];
    await new Promise(r => setTimeout(r, speed));
  }
  
  element.classList.remove('typing');
}
```

---

## PART 8: PHASE NAVIGATION

```javascript
function advancePhase() {
  if (state.currentPhase < state.lesson.phases.length - 1) {
    state.currentPhase++;
    playPhase(state.currentPhase);
    createRipple('right');
  } else {
    // Lesson complete!
    completeLesson();
  }
}

function previousPhase() {
  if (state.currentPhase > 0) {
    state.currentPhase--;
    playPhase(state.currentPhase);
    createRipple('left');
  }
}

function completeLesson() {
  // Update progress
  if (!state.completedLessons.includes(state.currentDay)) {
    state.completedLessons.push(state.currentDay);
  }
  
  // Update streak (simplified - real logic needs date tracking)
  state.streak++;
  
  // Save state
  saveState();
  
  // Also save to Supabase if user is authenticated
  saveProgressToSupabase();
  
  // Show completion scene
  document.getElementById('complete-kelly').innerHTML = `
    <img src="${getKellyHeadUrl(state.kelly.id)}" class="complete-avatar" />
  `;
  document.getElementById('complete-streak').textContent = state.streak;
  
  // Set tomorrow's teaser
  const tomorrowLesson = SAMPLE_LESSONS[state.currentDay]; // Or fetch from DB
  if (tomorrowLesson) {
    document.getElementById('tomorrow-topic').textContent = tomorrowLesson.topic;
  }
  
  showScene('complete');
  triggerConfetti();
}
```

---

## PART 9: JOURNEY/CALENDAR

```javascript
async function buildWeekView() {
  const container = document.getElementById('week-days');
  container.innerHTML = '';
  
  const startDay = state.weekOffset * 7 + 1;
  document.getElementById('week-label').textContent = `Week ${state.weekOffset + 1}`;
  
  // Fetch lesson topics for this week
  const { data: lessons } = await supabase
    .from('core_lessons')
    .select('day_number, topic, marketing_headline')
    .gte('day_number', startDay)
    .lte('day_number', startDay + 6)
    .order('day_number');
  
  const lessonMap = Object.fromEntries(lessons.map(l => [l.day_number, l]));
  
  for (let i = 0; i < 7; i++) {
    const dayNum = startDay + i;
    if (dayNum > 365) break;
    
    const lesson = lessonMap[dayNum] || { topic: `Day ${dayNum}`, marketing_headline: '' };
    const isCompleted = state.completedLessons.includes(dayNum);
    const isCurrent = dayNum === state.currentDay;
    const isLocked = dayNum > state.currentDay + 1;
    
    const el = document.createElement('div');
    el.className = `week-day ${isCompleted ? 'completed' : ''} ${isCurrent ? 'current' : ''} ${isLocked ? 'locked' : ''}`;
    
    el.innerHTML = `
      <div class="day-num">${dayNum}</div>
      <div class="day-info">
        <div class="day-topic">${lesson.topic}</div>
        <div class="day-preview">${lesson.marketing_headline || ''}</div>
      </div>
      <div class="day-status">${isCompleted ? '✓' : isCurrent ? '▶' : '🔒'}</div>
    `;
    
    if (!isLocked) {
      el.addEventListener('click', () => startLesson(dayNum));
    }
    
    container.appendChild(el);
  }
}
```

---

## PART 10: CRITICAL IMPLEMENTATION NOTES

### DO NOT CHANGE
- Scene transition system (CSS-based, smooth)
- Bottom navigation structure
- Carousel mechanics (swipe, scale, glow)
- Phase progress bar (Stories-style)
- Tap zone navigation
- Confetti system
- Overall color scheme (blue accent: #3b82f6)

### MUST IMPLEMENT
1. Replace all emoji avatars with <img> tags using Kelly head URLs
2. Connect loadLesson() to Supabase
3. Connect audio playback to pre-generated assets first, /api/tts fallback
4. Persist state to localStorage
5. Build week view from actual core_lessons data
6. Update day badge with real topic names

### CAN DEFER (Post-launch)
- HeyGen video playback (use image+audio for now)
- Achievements system (show UI, track later)
- Quiz (find your Kelly match)
- Onboarding flow
- Family accounts
- Downloads/offline mode
- Supabase auth integration

---

## PART 11: FILE STRUCTURE

```
public/
├── learn.html              ← REPLACE with new unified app
├── assets/
│   └── kelly/
│       └── kelly-personas-manifest.json  ← Already exists
├── js/
│   ├── kelly-audio.js      ← Extract audio class
│   ├── kelly-state.js      ← Extract state management  
│   └── kelly-supabase.js   ← Extract data fetching
└── css/
    └── kelly-app.css       ← Extract styles (optional)
```

Or keep as single file (current approach) for simplicity.

---

## PART 12: TESTING CHECKLIST

- [ ] Carousel swipes smoothly between 12 Kellys
- [ ] Selecting a Kelly updates the color theme
- [ ] "Let's Learn" button starts Day 1
- [ ] Phase progress bars update correctly
- [ ] Tap right advances phase, tap left goes back
- [ ] Completing all 5 phases shows Complete scene
- [ ] Confetti triggers on completion
- [ ] Journey week view shows 7 days with topics
- [ ] Clicking a day starts that lesson
- [ ] Settings age slider updates state
- [ ] Settings Kelly preview shows current Kelly
- [ ] Bottom nav switches between scenes
- [ ] All scenes transition smoothly (no jarring cuts)

---

## PART 13: ACCENT COLOR

**Primary**: #3b82f6 (Blue)
**Use for**: 
- Kelly glow rings
- Selected states
- Primary buttons background on hover
- Progress bar fills
- Toggle switches
- Stats highlights

**CSS Variables**:
```css
:root {
  --kelly-color: #3b82f6;
  --kelly-color-rgb: 59, 130, 246;
}
```

---

## QUICK START

1. Copy the contents of `kelly-app-enhanced.html` to `public/learn.html`
2. Update accent color to blue (already done in provided file)
3. Add Supabase client initialization at top of script
4. Replace KELLYS array with data from manifest
5. Implement loadLesson() with actual Supabase query
6. Replace emoji avatars with <img> tags
7. Test carousel → lesson → complete flow
8. Test journey week view with real data
9. Deploy and verify on mobile

---

## THE GOAL

When a user opens curiouskelly.com/learn.html:

1. They see a **video-game character select** screen
2. They swipe through 12 beautiful Kelly personas
3. They tap "Let's Learn" and smoothly transition to today's lesson
4. Kelly **speaks** to them (audio plays, Kelly "animates")
5. They tap through 5 phases like Instagram Stories
6. On completion, **confetti** falls and they see their streak
7. They can browse their **Journey** (365 days of lessons)
8. Everything feels like a **mobile app**, not a website

This is the December 17 launch experience.

---

*Generated by Claude for Cursor - December 2024*
