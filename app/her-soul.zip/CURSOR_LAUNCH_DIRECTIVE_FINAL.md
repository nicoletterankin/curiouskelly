# CURIOUS KELLY - FINAL LAUNCH DIRECTIVE
## Last Time the Plane is on the Ground

**Date:** December 11, 2025  
**Launch:** December 17, 2025 (6 DAYS)  
**Status:** SHIP IT

---

## PART 0: IMMEDIATE CLEANUP (CURSOR DOES THIS)

### Cloudflare Pages: IGNORE IT

Cloudflare Pages is failing but **it doesn't matter** - Vercel is production. 
Don't waste time deleting projects. Just leave them failing.

### Disable Wrangler (Cursor Task)

```bash
# Cursor: Rename wrangler.toml so Cloudflare stops trying to build
mv wrangler.toml wrangler.toml.DISABLED 2>/dev/null || echo "Already disabled or not found"

git add -A
git commit -m "Disable Cloudflare Pages - Vercel only"
git push origin main
```

---

## PART 1: DEFINITIVE ANSWERS - SINGLE SOURCE OF TRUTH

### 1. Deployment (Single Source of Truth)

**Q1: What is production hosting for curiouskelly.com?**
→ **C) Vercel** - ONLY Vercel. Cloudflare Pages is ignored (let it fail).

**Q2: Permission to disconnect/delete duplicate Cloudflare Pages projects?**
→ **SKIP** - Don't bother. Just ignore the failing builds.

**Q3: Preview builds or production-only?**
→ **B) Production-only** - Every push to main goes live on Vercel.

### 2. What "The App" Is at Launch

**Q4: Web-first or mobile-required?**
→ **B) Mobile-required** - Both web AND mobile ship now. TikTok-style player works on both.

**Q5: Unity/3D mode shipping this month?**
→ **A) Not shipping (park it)** - 2D video player is primary. Unity is Phase 2 post-launch.

### 3. Kelly Variants

**Q6: Are the 12 archetypes fixed?**
→ **A) Fixed** - The 12 persona/archetype mappings are canonical:

| DB Archetype | Persona ID | Head File |
|--------------|------------|-----------|
| The Architect | architect | kelly_architect_head.png |
| The Diplomat | diplomat | kelly_diplomat_head.png |
| The Empath | empath | kelly_empath_head.png |
| The Explorer | explorer | kelly_explorer_head.png |
| The MacGyver | macgyver | kelly_macgyver_head.png |
| The Mystic | mystic | kelly_mystic_head.png |
| The Provider | provider | kelly_provider_head.png |
| The Rebel | rebel | kelly_rebel_head.png |
| The Scientist | scientist | kelly_scientist_head.png |
| The Storyteller | storyteller | kelly_storyteller_head.png |
| The Strategist | strategist | kelly_strategist_head.png |
| The Survivor | survivor | kelly_survivor_head.png |

**Q7: "Kelly changes her age" means:**
→ **A) 5 age buckets (matching generated heads):**
- **Kid** (2-12) - 12 heads in `age/kid/`
- **Teen** (13-17) - 12 heads in `age/teen/`
- **Adult** (18-49, default) - 12 heads in `age/adult/`
- **Elder** (50-75) - 12 heads in `age/elder/`
- **Super-Elder** (76-102) - 12 heads in `age/super_elder/`

Total: **60 Kelly talking photos** (5 ages × 12 archetypes)

**Q8: Web player visuals standardized on:**
→ **D) Hybrid** - HeyGen lip-synced video PRIMARY, 2D static images as fallback.

### 4. Permission to Cut

**Q9: Delete/move legacy folders after snapshot?**
→ **A) Delete/move allowed** - Snapshot first, then clean house. No more cruft.

---

## PART 2: VIDEO COMPILATION DIRECTIVE

### MISSION: Compile Day 1 Kelly Videos

We have lesson atoms in Supabase. We have 36 Kelly talking photos in HeyGen. Now generate lip-synced videos for each lesson variant.

### Architecture Overview (ACTUAL PIPELINE)

```
SUPABASE (lesson_atoms)
    ↓
HEYGEN TALKING PHOTOS (36 Kelly heads: 12 archetypes × 3 ages)
    ↓
HEYGEN VIDEO GENERATION (lipsync + voice in one API call)
    ↓
SUPABASE STORAGE (video files)
    ↓
VERCEL (serve to player)
```

### What Already Exists

**Kelly Head Assets (60 total):**
```
generated-images/kelly-archetypes-head-only/
├── age/
│   ├── kid/         (12 heads - ages 2-12)
│   ├── teen/        (12 heads - ages 13-17)
│   ├── adult/       (12 heads - ages 18-49)
│   ├── elder/       (12 heads - ages 50-75)
│   └── super_elder/ (12 heads - ages 76-102)
├── archetype_head_urls.json
└── manifest.age-variants.json
```

**HeyGen Talking Photo IDs:**
```
generated-images/kelly-archetypes-head-only/age/kid/heygen_talking_photo_ids.json
generated-images/kelly-archetypes-head-only/age/teen/heygen_talking_photo_ids.json
generated-images/kelly-archetypes-head-only/age/adult/heygen_talking_photo_ids.json
generated-images/kelly-archetypes-head-only/age/elder/heygen_talking_photo_ids.json
generated-images/kelly-archetypes-head-only/age/super_elder/heygen_talking_photo_ids.json
```

### ⚠️ HEYGEN TALKING PHOTO IDS (FILL IN AFTER AVATAR SETUP)

After upscaling and adding motion in HeyGen, record the talking_photo_id for each:

```json
// heygen_talking_photo_ids.json template (one per age folder)
// Persona names MUST match the file names (without kelly_ prefix and _head.png suffix)
{
  "architect": "PASTE_ID_HERE",
  "diplomat": "PASTE_ID_HERE",
  "empath": "PASTE_ID_HERE",
  "explorer": "PASTE_ID_HERE",
  "macgyver": "PASTE_ID_HERE",
  "mystic": "PASTE_ID_HERE",
  "provider": "PASTE_ID_HERE",
  "rebel": "PASTE_ID_HERE",
  "scientist": "PASTE_ID_HERE",
  "storyteller": "PASTE_ID_HERE",
  "strategist": "PASTE_ID_HERE",
  "survivor": "PASTE_ID_HERE"
}
```

**To get talking_photo_id from HeyGen:**
1. Upload each head image to HeyGen (kelly_architect_head.png, etc.)
2. Add motion/upscale
3. Go to API → Talking Photos → Copy the ID
4. Paste into the JSON files above

### VOICE PIPELINE (CRITICAL)

**We do NOT use HeyGen's voice. Instead:**
1. ElevenLabs generates audio from script text
2. HeyGen lip-syncs Kelly's face to that audio URL

**Kelly's ElevenLabs Voice ID:** `wAdymQH5YucAkXwmrdL0`

The pipeline is:
```
lesson_atoms.content.script → ElevenLabs TTS → audio.mp3 → upload to R2 → audio_url → HeyGen talking photo
```

**LoRA Model:**
- Local: `models/lora/Curious_Kelly.safetensors`
- Remote: `https://huggingface.co/CuriousKellycom/curious-kelly-lora/resolve/main/curious_kelly.safetensors`

**Existing Scripts:**
- `scripts/generate-12-kellys-head-accessories.ts` - Generate Kelly head images
- `scripts/heygen-match-talking-photos.py` - Match heads to HeyGen talking photo IDs
- `scripts/heygen-kelly-pipeline-v2.ts` - Video generation (supports --language, --age)
- `public/js/kelly-personas.js` - `getPersonaImage(personaId, variant, ageVariant)`
- `public/assets/kelly/kelly-personas-manifest.json` - Persona metadata with age variants

### Database Schema Decision (RESOLVED)

**Using existing table: `kelly_video_assets`**

Your schema already has the right structure:
```sql
-- kelly_video_assets (ALREADY EXISTS)
- id uuid
- day_number integer (1-365)
- phase text ('hook', 'q1', 'q2', 'q3', 'wisdom')
- template text (archetype/persona name)
- asset_type text ('image', 'animation', 'audio', 'video', 'video_4k')
- age_bucket text ('kid', 'teen', 'adult', 'elder', 'super_elder')
- language text (default 'en')
- storage_path text
- public_url text
- status text ('generating', 'generated', 'validated', 'published')
- duration_seconds numeric
- generation_cost_usd numeric
```

**No new table needed.** We'll use `kelly_video_assets` for all generated videos.

---

### CURSOR TASK 1: Verify Asset Folder Structure

```bash
# Check what age folders exist
ls -la generated-images/kelly-archetypes-head-only/age/

# Expected output (5 folders):
# kid/         (12 heads)
# teen/        (12 heads)  
# adult/       (12 heads)
# elder/       (12 heads)
# super_elder/ (12 heads)

# Count total heads
find generated-images/kelly-archetypes-head-only/age -name "*.png" | wc -l
# Should be 60 (5 ages × 12 archetypes)
```

### CURSOR TASK 2: Audit Existing Content

```typescript
// scripts/audit-day1-for-heygen.ts

import { createClient } from '@supabase/supabase-js';
import * as fs from 'fs';
import * as path from 'path';

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_KEY!
);

async function auditDay1() {
  console.log('=== CURIOUS KELLY - DAY 1 HEYGEN AUDIT ===\n');
  
  // 1. Check lesson atoms
  const { data: atoms, count } = await supabase
    .from('lesson_atoms')
    .select('*', { count: 'exact' })
    .eq('core_lesson_id', /* day 1 lesson id */);
  
  console.log(`[Supabase] Day 1 atoms: ${count}`);
  
  // Group by archetype
  const byArchetype: Record<string, number> = {};
  atoms?.forEach(a => {
    byArchetype[a.archetype] = (byArchetype[a.archetype] || 0) + 1;
  });
  console.log('\nAtoms by archetype:');
  Object.entries(byArchetype).forEach(([k, v]) => console.log(`  ${k}: ${v}`));
  
  // 2. Check HeyGen talking photo IDs for all 5 age buckets
  const ageVariants = ['kid', 'teen', 'adult', 'elder', 'super_elder'];
  console.log('\n[HeyGen] Talking Photo IDs:');
  
  for (const age of ageVariants) {
    const idMapPath = path.join(
      'generated-images/kelly-archetypes-head-only/age',
      age,
      'heygen_talking_photo_ids.json'
    );
    
    if (fs.existsSync(idMapPath)) {
      const idMap = JSON.parse(fs.readFileSync(idMapPath, 'utf-8'));
      console.log(`  ${age}: ${Object.keys(idMap).length} talking photos ✓`);
    } else {
      console.log(`  ${age}: ❌ ID map not found at ${idMapPath}`);
    }
  }
  
  // 3. Check existing kelly_video_assets for day 1
  const { data: existingVideos, count: videoCount } = await supabase
    .from('kelly_video_assets')
    .select('*', { count: 'exact' })
    .eq('day_number', 1);
  
  console.log(`\n[kelly_video_assets] Day 1 existing: ${videoCount || 0}`);
  
  if (existingVideos?.length) {
    const byPhase: Record<string, number> = {};
    existingVideos.forEach(v => {
      byPhase[v.phase] = (byPhase[v.phase] || 0) + 1;
    });
    console.log('By phase:', byPhase);
  }
  
  // 4. Sample content for HeyGen script generation
  console.log('\n=== SAMPLE SCRIPTS FOR HEYGEN ===');
  // ACTUAL PHASES IN DATABASE: Hook, Fact1, Fact2, Fact3, Wisdom
  const phases = ['Hook', 'Fact1', 'Fact2', 'Fact3', 'Wisdom'];
  for (const phase of phases) {
    const atom = atoms?.find(a => a.phase === phase);
    if (atom) {
      // Content is stored as JSON with a "script" field
      const script = atom.content?.script || JSON.stringify(atom.content);
      console.log(`\n${phase} (${atom.archetype}):`);
      console.log(`"${script.substring(0, 200)}..."`);
    }
  }
  
  return { atoms, count, byArchetype };
}

auditDay1().then(() => console.log('\n✅ Audit complete'));
```

### CURSOR TASK 3: HeyGen Video Generation

**CRITICAL: Voice Pipeline**
- ElevenLabs generates audio from script text
- HeyGen lip-syncs Kelly's face to that audio
- We pass `audio_url` to HeyGen, NOT a voice_id

```typescript
// scripts/generate-day-videos-heygen.ts

import { createClient } from '@supabase/supabase-js';
import * as fs from 'fs';
import * as path from 'path';

const HEYGEN_API_KEY = process.env.HEYGEN_API_KEY!;
const HEYGEN_API_URL = 'https://api.heygen.com/v2';
const ELEVENLABS_API_KEY = process.env.ELEVENLABS_API_KEY!;
const ELEVENLABS_VOICE_ID = 'wAdymQH5YucAkXwmrdL0';  // Kelly's voice

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_KEY!
);

// Map DB archetypes to persona file names (they're the same!)
const ARCHETYPE_TO_PERSONA: Record<string, string> = {
  'The Architect': 'architect',
  'The Diplomat': 'diplomat',
  'The Empath': 'empath',
  'The Explorer': 'explorer',
  'The MacGyver': 'macgyver',
  'The Mystic': 'mystic',
  'The Provider': 'provider',
  'The Rebel': 'rebel',
  'The Scientist': 'scientist',
  'The Storyteller': 'storyteller',
  'The Strategist': 'strategist',
  'The Survivor': 'survivor'
};

// Phase mapping: DB uses capitalized names
const PHASES = ['Hook', 'Fact1', 'Fact2', 'Fact3', 'Wisdom'];

interface GenerationOptions {
  dayNumber: number;
  ageVariant: 'kid' | 'teen' | 'adult' | 'elder' | 'super_elder';
  language: string;
  archetype?: string;  // If specified, only generate for this archetype
}

// Map user age to age bucket
function getAgeBucket(age: number): 'kid' | 'teen' | 'adult' | 'elder' | 'super_elder' {
  if (age <= 12) return 'kid';
  if (age <= 17) return 'teen';
  if (age <= 49) return 'adult';
  if (age <= 75) return 'elder';
  return 'super_elder';
}

async function getTalkingPhotoId(persona: string, age: string): Promise<string | null> {
  const idMapPath = path.join(
    'generated-images/kelly-archetypes-head-only/age',
    age,
    'heygen_talking_photo_ids.json'
  );
  
  if (!fs.existsSync(idMapPath)) {
    console.error(`❌ ID map not found: ${idMapPath}`);
    return null;
  }
  
  const idMap = JSON.parse(fs.readFileSync(idMapPath, 'utf-8'));
  return idMap[persona] || idMap[`kelly_${persona}_head`] || null;
}

// Step 1: Generate audio with ElevenLabs
async function generateElevenLabsAudio(script: string): Promise<string> {
  const response = await fetch(
    `https://api.elevenlabs.io/v1/text-to-speech/${ELEVENLABS_VOICE_ID}`,
    {
      method: 'POST',
      headers: {
        'xi-api-key': ELEVENLABS_API_KEY,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        text: script,
        model_id: 'eleven_multilingual_v2',
        voice_settings: {
          stability: 0.5,
          similarity_boost: 0.75
        }
      })
    }
  );
  
  if (!response.ok) {
    throw new Error(`ElevenLabs error: ${response.statusText}`);
  }
  
  // Get audio as blob and upload to R2 or temp storage
  const audioBuffer = await response.arrayBuffer();
  // TODO: Upload to R2 and get public URL
  // For now, you may need to use a temp file or your existing audio upload logic
  
  return 'AUDIO_URL_HERE'; // Replace with actual upload logic
}

// Step 2: Generate video with HeyGen using audio_url
async function generateHeyGenVideo(
  talkingPhotoId: string,
  audioUrl: string
): Promise<{ videoId: string; status: string }> {
  
  const response = await fetch(`${HEYGEN_API_URL}/video/generate`, {
    method: 'POST',
    headers: {
      'X-Api-Key': HEYGEN_API_KEY,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      video_inputs: [{
        character: {
          type: 'talking_photo',
          talking_photo_id: talkingPhotoId
        },
        voice: {
          type: 'audio',
          audio_url: audioUrl  // Use ElevenLabs audio, NOT HeyGen voice
        }
      }],
      dimension: {
        width: 1080,
        height: 1920  // 9:16 for mobile-first TikTok style
      }
    })
  });
  
  const data = await response.json();
  
  if (data.error) {
    throw new Error(`HeyGen error: ${data.error.message}`);
  }
  
  return {
    videoId: data.data.video_id,
    status: data.data.status
  };
}

async function checkVideoStatus(videoId: string): Promise<{
  status: string;
  videoUrl?: string;
  duration?: number;
}> {
  const response = await fetch(`${HEYGEN_API_URL}/video_status.get?video_id=${videoId}`, {
    headers: { 'X-Api-Key': HEYGEN_API_KEY }
  });
  
  const data = await response.json();
  
  return {
    status: data.data.status,
    videoUrl: data.data.video_url,
    duration: data.data.duration
  };
}

async function generateDayVideos(options: GenerationOptions) {
  const { dayNumber, ageVariant, language } = options;
  
  console.log(`\n========================================`);
  console.log(`GENERATING: Day ${dayNumber}, Age: ${ageVariant}, Lang: ${language}`);
  console.log(`========================================\n`);
  
  // First, get the core_lesson_id for this day
  const { data: lesson } = await supabase
    .from('core_lessons')
    .select('id')
    .eq('day_number', dayNumber)
    .single();
  
  if (!lesson) {
    console.error(`❌ No core_lesson found for day ${dayNumber}`);
    return;
  }
  
  // Get lesson atoms for this lesson
  let query = supabase
    .from('lesson_atoms')
    .select('*')
    .eq('core_lesson_id', lesson.id);
  
  if (options.archetype) {
    query = query.eq('archetype', options.archetype);
  }
  
  const { data: atoms, error } = await query.order('phase');
  
  if (error || !atoms?.length) {
    console.error(`❌ No atoms found for day ${dayNumber}`);
    return;
  }
  
  console.log(`Found ${atoms.length} atoms to process\n`);
  
  for (const atom of atoms) {
    const persona = ARCHETYPE_TO_PERSONA[atom.archetype] || 'diplomat';
    const talkingPhotoId = await getTalkingPhotoId(persona, ageVariant);
    
    if (!talkingPhotoId) {
      console.error(`❌ No talking photo for ${persona}/${ageVariant}`);
      continue;
    }
    
    // Extract script from content JSON (content has {script: "..."} structure)
    const script = atom.content?.script || '';
    if (!script) {
      console.error(`❌ No script in content for ${atom.phase}/${atom.archetype}`);
      continue;
    }
    
    console.log(`[${atom.phase}] ${atom.archetype} → ${persona}`);
    console.log(`    Script: "${script.substring(0, 50)}..."`);
    
    try {
      // Step 1: Generate audio with ElevenLabs
      console.log(`    Generating audio with ElevenLabs...`);
      const audioUrl = await generateElevenLabsAudio(script);
      
      // Step 2: Generate video with HeyGen using audio
      console.log(`    Generating video with HeyGen...`);
      const { videoId, status } = await generateHeyGenVideo(
        talkingPhotoId,
        audioUrl
      );
      
      console.log(`    ✓ Video queued: ${videoId} (${status})`);
      
      // Record in kelly_video_assets (existing table)
      await supabase.from('kelly_video_assets').upsert({
        day_number: dayNumber,
        phase: atom.phase,  // Will be 'Hook', 'Fact1', etc.
        template: persona,  // archetype/persona name
        asset_type: 'video',
        age_bucket: ageVariant,
        language: language,
        storage_path: `heygen/${videoId}`,  // Will update with real path after completion
        public_url: '',  // Will update after HeyGen completes
        replicate_prediction_id: videoId,  // Reusing field for HeyGen video ID
        generation_prompt: script,
        status: 'generating'
      }, {
        onConflict: 'day_number,phase,template,age_bucket,language'
      });
      
      // Rate limit: HeyGen allows ~2 concurrent generations
      await new Promise(r => setTimeout(r, 2000));
      
    } catch (err) {
      console.error(`    ❌ Error: ${err}`);
      
      await supabase.from('kelly_video_assets').upsert({
        day_number: dayNumber,
        phase: atom.phase,
        template: persona,
        asset_type: 'video',
        age_bucket: ageVariant,
        language: language,
        storage_path: '',
        public_url: '',
        status: 'archived'  // Using 'archived' to indicate failed
      }, {
        onConflict: 'day_number,phase,template,age_bucket,language'
      });
    }
  }
  
  console.log(`\n✅ Day ${dayNumber} generation queued`);
}

// Run with: npx tsx scripts/generate-day-videos-heygen.ts --day=1 --age=adult --lang=en
const args = process.argv.slice(2);
const day = parseInt(args.find(a => a.startsWith('--day='))?.split('=')[1] || '1');
const age = (args.find(a => a.startsWith('--age='))?.split('=')[1] || 'adult') as 'kid' | 'teen' | 'adult' | 'elder' | 'super_elder';
const lang = args.find(a => a.startsWith('--lang='))?.split('=')[1] || 'en';

generateDayVideos({ dayNumber: day, ageVariant: age, language: lang });
```

### CURSOR TASK 4: Poll & Update Video Status

```typescript
// scripts/poll-heygen-status.ts

import { createClient } from '@supabase/supabase-js';

const HEYGEN_API_KEY = process.env.HEYGEN_API_KEY!;
const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_KEY!
);

async function pollPendingVideos() {
  // Get all videos still generating from kelly_video_assets
  const { data: pending } = await supabase
    .from('kelly_video_assets')
    .select('*')
    .eq('status', 'generating')
    .eq('asset_type', 'video');
  
  if (!pending?.length) {
    console.log('No pending videos');
    return;
  }
  
  console.log(`Checking ${pending.length} pending videos...\n`);
  
  for (const video of pending) {
    const response = await fetch(
      `https://api.heygen.com/v2/video_status.get?video_id=${video.replicate_prediction_id}`,
      { headers: { 'X-Api-Key': HEYGEN_API_KEY } }
    );
    
    const data = await response.json();
    const status = data.data?.status;
    
    console.log(`[${video.day_number}-${video.phase}] ${video.template}: ${status}`);
    
    if (status === 'completed') {
      await supabase
        .from('kelly_video_assets')
        .update({
          status: 'validated',  // Using existing status enum
          public_url: data.data.video_url,
          duration_seconds: data.data.duration,
          updated_at: new Date().toISOString()
        })
        .eq('id', video.id);
      
      console.log(`    ✓ Ready: ${data.data.video_url}`);
      
    } else if (status === 'failed') {
      await supabase
        .from('kelly_video_assets')
        .update({
          status: 'archived',  // Mark as failed/archived
          updated_at: new Date().toISOString()
        })
        .eq('id', video.id);
      
      console.log(`    ❌ Failed`);
    }
    
    await new Promise(r => setTimeout(r, 500));
  }
}

// Run continuously or as cron
pollPendingVideos();
```

### CURSOR TASK 5: Frontend Video Loader

```javascript
// public/js/kelly-video-loader.js

const KellyVideoLoader = {
  supabaseUrl: 'https://tvjalxxsyryjphkforjv.supabase.co',
  supabaseKey: null, // Set from config
  
  // Age bucket mapping for user age → asset age_bucket
  getAgeBucket(age) {
    if (age <= 12) return 'kid';
    if (age <= 17) return 'teen';
    if (age <= 49) return 'adult';
    if (age <= 75) return 'elder';
    return 'super_elder';
  },
  
  async init(anonKey) {
    this.supabaseKey = anonKey;
  },
  
  async getVideo(dayNumber, phase, options = {}) {
    const {
      ageBucket = 'adult',  // 'kid', 'teen', 'adult', 'elder', 'super_elder'
      language = 'en',
      template = null  // archetype/persona name
    } = options;
    
    let query = `day_number=eq.${dayNumber}&phase=eq.${phase}&age_bucket=eq.${ageBucket}&language=eq.${language}&status=in.(validated,published)&asset_type=eq.video`;
    
    if (template) {
      query += `&template=eq.${template}`;
    }
    
    const response = await fetch(
      `${this.supabaseUrl}/rest/v1/kelly_video_assets?${query}&limit=1`,
      {
        headers: {
          'apikey': this.supabaseKey,
          'Authorization': `Bearer ${this.supabaseKey}`
        }
      }
    );
    
    const [video] = await response.json();
    return video || null;
  },
  
  async getLessonVideos(dayNumber, options = {}) {
    const { ageBucket = 'adult', language = 'en' } = options;
    
    const response = await fetch(
      `${this.supabaseUrl}/rest/v1/kelly_video_assets?day_number=eq.${dayNumber}&age_bucket=eq.${ageBucket}&language=eq.${language}&status=in.(validated,published)&asset_type=eq.video&order=phase.asc`,
      {
        headers: {
          'apikey': this.supabaseKey,
          'Authorization': `Bearer ${this.supabaseKey}`
        }
      }
    );
    
    return response.json();
  },
  
  async preloadLesson(dayNumber, options = {}) {
    const videos = await this.getLessonVideos(dayNumber, options);
    
    // Preload video URLs
    for (const video of videos) {
      if (video.video_url) {
        const link = document.createElement('link');
        link.rel = 'preload';
        link.as = 'video';
        link.href = video.video_url;
        document.head.appendChild(link);
      }
    }
    
    return videos;
  }
};

// Export for use in player
window.KellyVideoLoader = KellyVideoLoader;
```

### CURSOR TASK 6: Master Generation Script

```bash
#!/bin/bash
# scripts/compile-day-heygen.sh

DAY=${1:-1}
AGES=${2:-"adult"}
LANGS=${3:-"en"}

echo "=========================================="
echo "HEYGEN VIDEO COMPILATION - DAY $DAY"
echo "Ages: $AGES | Languages: $LANGS"
echo "=========================================="

# Parse comma-separated values
IFS=',' read -ra AGE_ARRAY <<< "$AGES"
IFS=',' read -ra LANG_ARRAY <<< "$LANGS"

echo "\n[1/4] Auditing content..."
npx tsx scripts/audit-day1-for-heygen.ts

echo "\n[2/4] Generating videos..."
for age in "${AGE_ARRAY[@]}"; do
  for lang in "${LANG_ARRAY[@]}"; do
    echo "\n>>> Generating: age=$age, lang=$lang"
    npx tsx scripts/generate-day-videos-heygen.ts --day=$DAY --age=$age --lang=$lang
  done
done

echo "\n[3/4] Waiting for HeyGen processing (checking every 30s)..."
for i in {1..20}; do
  sleep 30
  echo "Poll attempt $i..."
  npx tsx scripts/poll-heygen-status.ts
  
  # Check if all done (using kelly_video_assets)
  PENDING=$(npx tsx -e "
    const { createClient } = require('@supabase/supabase-js');
    const sb = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_KEY);
    sb.from('kelly_video_assets').select('id', { count: 'exact' })
      .eq('status', 'generating').eq('day_number', $DAY).eq('asset_type', 'video')
      .then(r => console.log(r.count || 0));
  ")
  
  if [ "$PENDING" = "0" ]; then
    echo "All videos processed!"
    break
  fi
done

echo "\n[4/4] Summary..."
npx tsx -e "
  const { createClient } = require('@supabase/supabase-js');
  const sb = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_KEY);
  sb.from('kelly_video_assets')
    .select('status', { count: 'exact' })
    .eq('day_number', $DAY)
    .eq('asset_type', 'video')
    .then(async () => {
      const ready = await sb.from('kelly_video_assets').select('*', {count:'exact'}).eq('day_number',$DAY).eq('asset_type','video').in('status',['validated','published']);
      const failed = await sb.from('kelly_video_assets').select('*', {count:'exact'}).eq('day_number',$DAY).eq('asset_type','video').eq('status','archived');
      console.log('Ready:', ready.count);
      console.log('Failed:', failed.count);
    });
"

echo "\n=========================================="
echo "✅ DAY $DAY COMPILATION COMPLETE"
echo "=========================================="
```

### Usage Examples

```bash
# Generate Day 1, adult age, English only
./scripts/compile-day-heygen.sh 1 adult en

# Generate Day 1, all 5 ages, English and Spanish
./scripts/compile-day-heygen.sh 1 kid,teen,adult,elder,super_elder en,es

# Generate just kid and teen for testing younger audiences
./scripts/compile-day-heygen.sh 1 kid,teen en

# Generate elder ages for senior testing
./scripts/compile-day-heygen.sh 1 elder,super_elder en
```

---

## PART 3: CLEANUP DIRECTIVE

### Delete These Now (After Snapshot)

```bash
# Snapshot first
mkdir -p ~/curiouskelly-backup-$(date +%Y%m%d)
cp -r . ~/curiouskelly-backup-$(date +%Y%m%d)/

# Then delete legacy
rm -rf unity-builds/
rm -rf old-players/
rm -rf archived/
rm -rf temp-*/
rm -rf .next/
rm -rf node_modules/ && npm install

# Remove duplicate Vercel projects via dashboard:
# - Delete curiouskelly-1mv5
# - Keep only curiouskelly

# Remove duplicate Cloudflare Pages projects via dashboard:
# - Keep only ONE that builds per push
```

### Environment Variables Required (Vercel Dashboard)

```
# Supabase
SUPABASE_URL=https://tvjalxxsyryjphkforjv.supabase.co
SUPABASE_ANON_KEY=<your_key>
SUPABASE_SERVICE_KEY=<your_service_key>  # For server-side scripts

# HeyGen (Video Generation)
HEYGEN_API_KEY=<your_key>

# ElevenLabs (Voice - if using standalone audio)
ELEVENLABS_API_KEY=<your_key>

# Cloudflare R2 (Asset Storage)
CLOUDFLARE_R2_ACCOUNT_ID=47ebb2a1adc311cb106acc89720e352c
CLOUDFLARE_R2_ACCESS_KEY_ID=<your_key>
CLOUDFLARE_R2_SECRET_ACCESS_KEY=<your_key>
CLOUDFLARE_R2_BUCKET=my-quantum-bucket
CLOUDFLARE_R2_PUBLIC_URL=https://pub-b5e7a8ca0071406fa65faebf47a39bd8.r2.dev

# Replicate (LoRA Image Generation)
REPLICATE_API_TOKEN=<your_key>
```

---

## PART 4: LAUNCH CHECKLIST

### Before December 17

- [ ] **CLEANUP DONE:**
  - [ ] All Cloudflare Pages projects DELETED
  - [ ] wrangler.toml renamed to wrangler.toml.DISABLED
  - [ ] Vercel deploying green
- [ ] **KELLY HEADS DONE:**
  - [ ] 60 head images generated (12 archetypes × 5 ages) ✓
  - [ ] All 60 uploaded to HeyGen with motion
  - [ ] All 60 talking_photo_ids recorded in JSON files
- [ ] **DAY 1 VIDEOS:**
  - [ ] Day 1 HeyGen videos generated (start with adult/en)
  - [ ] Videos stored in kelly_video_assets table
  - [ ] Player loading videos correctly
- [ ] **PLAYER WORKING:**
  - [ ] TikTok player loads on curiouskelly.com
  - [ ] Age slider changes Kelly's appearance
  - [ ] 2D fallback working when video not ready
  - [ ] Mobile responsive verified
- [ ] **PAYMENTS:**
  - [ ] Stripe integration working
  - [ ] COPPA compliance verified

### Launch Day

- [ ] curiouskelly.com loads
- [ ] Day 1 lesson plays with Kelly video
- [ ] Kelly speaks (HeyGen lip-sync)
- [ ] Age slider works (kid → teen → adult → elder → super_elder)
- [ ] Language selector works
- [ ] Users can sign up
- [ ] Users can pay
- [ ] Works on iOS Safari
- [ ] Works on Android Chrome
- [ ] Works on desktop browsers

---

## PART 5: VERIFIED ANSWERS (FROM PRE-FLIGHT CHECK)

These have been verified and are now facts:

### ✅ Voice Pipeline
- **No HeyGen voice_id** - We use ElevenLabs audio
- **Kelly's ElevenLabs voice_id:** `wAdymQH5YucAkXwmrdL0`
- Pipeline: script → ElevenLabs TTS → audio_url → HeyGen lip-sync

### ✅ Database Schema (lesson_atoms)
- **Phases are TEXT:** `Hook`, `Fact1`, `Fact2`, `Fact3`, `Wisdom`
- **Content structure:** `{script: "..."}`  (JSON with script field)
- **Archetypes in DB:** The Architect, The Diplomat, The Empath, The Explorer, The MacGyver, The Mystic, The Provider, The Rebel, The Scientist, The Storyteller, The Strategist, The Survivor

### ✅ File Structure
Files in `age/adult/` (same pattern for all age folders):
- `kelly_architect_head.png` + `kelly_architect_prop_head.png`
- `kelly_diplomat_head.png` + `kelly_diplomat_prop_head.png`
- `kelly_empath_head.png` + `kelly_empath_prop_head.png`
- `kelly_explorer_head.png` + `kelly_explorer_prop_head.png`
- `kelly_macgyver_head.png` + `kelly_macgyver_prop_head.png`
- `kelly_mystic_head.png` + `kelly_mystic_prop_head.png`
- `kelly_provider_head.png` + `kelly_provider_prop_head.png`
- `kelly_rebel_head.png` + `kelly_rebel_prop_head.png`
- `kelly_scientist_head.png` + `kelly_scientist_prop_head.png`
- `kelly_storyteller_head.png` + `kelly_storyteller_prop_head.png`
- `kelly_strategist_head.png` + `kelly_strategist_prop_head.png`
- `kelly_survivor_head.png` + `kelly_survivor_prop_head.png`
- `heygen_talking_photo_ids.json` (to be populated after HeyGen setup)

### ✅ Environment Variables
- `HEYGEN_API_KEY` ✓ Set
- `ELEVENLABS_API_KEY` ✓ Set
- `SUPABASE_URL` ✓ Set
- `SUPABASE_SERVICE_KEY` ✓ Set

---

## EXECUTE NOW

**Step 0:** Cursor disables wrangler.toml (see PART 0)

**Step 1:** Verify head count:
```bash
ls generated-images/kelly-archetypes-head-only/age/
# Should show: kid/ teen/ adult/ elder/ super_elder/

find generated-images/kelly-archetypes-head-only/age -name "*_head.png" | wc -l
# Should be 60 (12 personas × 5 ages)
```

**Step 2:** Upload heads to HeyGen, add motion, record talking_photo_ids

**Step 3:** Run audit: `npx tsx scripts/audit-day1-for-heygen.ts`

**Step 4:** Generate Day 1 videos: `./scripts/compile-day-heygen.sh 1 adult en`

**Step 5:** Poll until ready: `npx tsx scripts/poll-heygen-status.ts`

**Step 6:** Test in player: Load lesson, verify Kelly video plays

---

## ZERO-SHOT PROMPT FOR NEW AGENT

Copy this into a fresh Cursor agent:

```
CURIOUS KELLY - FINAL LAUNCH SPRINT
====================================

CONTEXT:
- Launch date: December 17, 2025 (6 days)
- 60 Kelly head images are DONE (12 archetypes × 5 ages)
- Deployment: VERCEL ONLY (Cloudflare Pages ignored - let it fail)
- Production URL: curiouskelly.com

VERIFIED FACTS (DO NOT RE-CHECK):
- Voice: ElevenLabs voice_id = wAdymQH5YucAkXwmrdL0 (NOT HeyGen voice)
- Pipeline: script → ElevenLabs TTS → audio_url → HeyGen lip-sync
- Phases in DB: Hook, Fact1, Fact2, Fact3, Wisdom (capitalized, TEXT type)
- Content structure: {script: "..."} - extract script field
- 12 Archetypes: The Architect, The Diplomat, The Empath, The Explorer, 
  The MacGyver, The Mystic, The Provider, The Rebel, The Scientist, 
  The Storyteller, The Strategist, The Survivor

CURRENT STATE:
- Kelly heads: generated-images/kelly-archetypes-head-only/age/{kid,teen,adult,elder,super_elder}/
- Each folder: 12 personas × 2 variants (head + prop_head) = 24 PNGs
- HeyGen talking_photo_ids: PENDING (Nicolette is adding motion in HeyGen now)

YOUR FIRST TASKS:
1. Rename wrangler.toml to wrangler.toml.DISABLED (stop Cloudflare builds)
2. Push that change to get a clean Vercel deploy
3. Wait for Nicolette to finish HeyGen setup and provide talking_photo_ids
4. Then run video generation pipeline

IMPORTANT: Do NOT generate videos until HeyGen talking_photo_ids are populated.

Read the full CURSOR_LAUNCH_DIRECTIVE_FINAL.md for complete pipeline details.
```

---

This is the last time the plane is on the ground. Ship it. 🚀
