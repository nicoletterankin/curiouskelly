# CURIOUS KELLY APP DIRECTIVE
## Complete Learn.html Implementation — December 2024

---

## MISSION

Replace `public/learn.html` with a production-ready, learner-first mobile app experience. This isn't a website—it's a daily learning companion that should feel as polished as Duolingo, as engaging as TikTok, and as personal as a one-on-one tutor.

**Launch Date:** December 17, 2024  
**Accent Color:** Blue (#3b82f6)  
**Core Principle:** Kelly is always present. The learner never feels lost.

---

## PART 1: FILES & ARCHITECTURE

### Source Files

| File | Purpose |
|------|---------|
| `kelly-app-complete.html` | Complete UI shell — copy to `public/learn.html` |
| `/assets/kelly/kelly-personas-manifest.json` | Kelly personas with image URLs |
| Supabase `core_lessons` table | 365 lesson topics |
| Supabase `lesson_atoms` table | Phase content by archetype |
| Supabase `kelly_video_assets` table | Pre-generated audio/video |

### Tech Stack

```
Frontend: Vanilla JS (single HTML file for now)
Backend: Supabase (Postgres + Storage + Auth)
CDN: Supabase Storage
Voice: ElevenLabs (voice ID: wAdymQH5YucAkXwmrdL0)
Video: HeyGen (when ready)
```

### Critical URLs

```javascript
const CONFIG = {
  SUPABASE_URL: 'https://tvjalxxsyryjphkforjv.supabase.co',
  SUPABASE_ANON_KEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InR2amFseHhzeXJ5anBoa2ZvcnZ2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzI1NTg0MDAsImV4cCI6MjA0ODEzNDQwMH0.VsgWOWur8R4G2eFX8lXCaGwYGPuNeDoWQwFrqczGvvI',
  MANIFEST_URL: '/assets/kelly/kelly-personas-manifest.json',
  CDN_BASE: 'https://tvjalxxsyryjphkforjv.supabase.co/storage/v1/object/public/kelly-templates'
};
```

---

## PART 2: KELLY IMAGE SYSTEM

### Manifest Structure

The manifest at `/assets/kelly/kelly-personas-manifest.json` contains:

```json
{
  "cdnBase": "https://tvjalxxsyryjphkforjv.supabase.co/storage/v1/object/public/kelly-templates",
  "personas": {
    "scientist": {
      "id": "scientist",
      "name": "The Scientist",
      "icon": "🔬",
      "tagline": "Data-driven precision",
      "color": "#3b82f6",
      "images": {
        "head": "heygen/archetypes-head-only/kelly_scientist_head.png",
        "headByAge": {
          "kid": "heygen/archetypes-head-only/age/kid/kelly_scientist_head.png",
          "teen": "heygen/archetypes-head-only/age/teen/kelly_scientist_head.png",
          "adult": "heygen/archetypes-head-only/kelly_scientist_head.png",
          "elder": "heygen/archetypes-head-only/age/elder/kelly_scientist_head.png",
          "super_elder": "heygen/archetypes-head-only/age/super_elder/kelly_scientist_head.png"
        }
      }
    }
    // ... 11 more personas
  },
  "personaOrder": ["scientist", "explorer", "rebel", "architect", "diplomat", "empath", "macgyver", "mystic", "provider", "storyteller", "strategist", "survivor"]
}
```

### Age Bucket Mapping

```javascript
function getAgeBucket(age) {
  if (age <= 12) return 'kid';
  if (age <= 17) return 'teen';
  if (age <= 49) return 'adult';
  if (age <= 75) return 'elder';
  return 'super_elder';
}
```

### Building Image URLs

```javascript
function getKellyImageUrl(personaId, ageBucket = 'adult') {
  const persona = manifest.personas[personaId];
  if (!persona) return null;
  
  const path = persona.images.headByAge?.[ageBucket] || persona.images.head;
  return `${manifest.cdnBase}/${path}`;
}
```

### Where Kelly Images Appear

1. **Character Select Carousel** — 180×180px circular avatar
2. **Lesson Player** — 200×200px with speaking animation
3. **Settings Preview** — 60×60px next to "Your Kelly"
4. **Completion Screen** — 120×120px with celebration animation

**IMPORTANT:** Always use `<img>` tags with `onerror` fallback to emoji:
```html
<img src="${imgUrl}" alt="${name}" onerror="this.parentElement.innerHTML='${icon}'">
```

---

## PART 3: PERSONA ↔ ARCHETYPE MAPPING

The database uses archetype names like "The Scientist". The UI uses persona IDs like "scientist".

```javascript
const PERSONA_TO_ARCHETYPE = {
  'scientist': 'The Scientist',
  'explorer': 'The Explorer',
  'rebel': 'The Rebel',
  'architect': 'The Architect',
  'diplomat': 'The Diplomat',
  'empath': 'The Empath',
  'macgyver': 'The MacGyver',
  'mystic': 'The Mystic',
  'provider': 'The Provider',
  'storyteller': 'The Storyteller',
  'strategist': 'The Strategist',
  'survivor': 'The Survivor'
};
```

When loading lesson content, convert:
```javascript
const archetype = PERSONA_TO_ARCHETYPE[state.kellyId]; // "The Scientist"
```

---

## PART 4: SUPABASE QUERIES

### Load Lesson Content

```javascript
async function loadLesson(dayNumber) {
  const archetype = PERSONA_TO_ARCHETYPE[state.kellyId];
  
  // 1. Get core lesson
  const { data: lesson } = await supabase
    .from('core_lessons')
    .select('id, topic, universal_truth, marketing_headline')
    .eq('day_number', dayNumber)
    .single();
  
  if (!lesson) return null;
  
  // 2. Get atoms for this archetype
  const { data: atoms } = await supabase
    .from('lesson_atoms')
    .select('phase, content, hd_video_url, visual_url')
    .eq('core_lesson_id', lesson.id)
    .eq('archetype', archetype);
  
  // 3. Map to phases (Hook, Fact1, Fact2, Fact3, Wisdom)
  const PHASE_ORDER = ['Hook', 'Fact1', 'Fact2', 'Fact3', 'Wisdom'];
  
  const phases = PHASE_ORDER.map(phaseName => {
    const atom = atoms?.find(a => a.phase === phaseName);
    return {
      name: phaseName,
      script: atom?.content?.script || '',
      videoUrl: atom?.hd_video_url,
      visualUrl: atom?.visual_url
    };
  });
  
  return { ...lesson, phases };
}
```

### Load Week of Lessons (for Journey view)

```javascript
async function loadWeekLessons(startDay) {
  const { data } = await supabase
    .from('core_lessons')
    .select('day_number, topic, marketing_headline')
    .gte('day_number', startDay)
    .lte('day_number', startDay + 6)
    .order('day_number');
  
  return data || [];
}
```

### Get Pre-Generated Audio

```javascript
async function getAudioUrl(dayNumber, phase, personaId, ageBucket, language = 'en') {
  const { data } = await supabase
    .from('kelly_video_assets')
    .select('public_url')
    .eq('day_number', dayNumber)
    .eq('phase', phase)
    .eq('template', personaId)
    .eq('age_bucket', ageBucket)
    .eq('asset_type', 'audio')
    .eq('language', language)
    .in('status', ['validated', 'published', 'generated'])
    .limit(1);
  
  return data?.[0]?.public_url || null;
}
```

---

## PART 5: STATE MANAGEMENT

### State Shape

```javascript
const state = {
  // Identity
  kellyId: 'scientist',           // Selected persona
  age: 30,                        // Learning age (2-102)
  language: 'en',                 // 'en', 'es', 'fr'
  
  // Progress
  currentDay: 1,                  // Current lesson (1-365)
  currentPhase: 0,                // Current phase (0-4)
  streak: 0,                      // Consecutive days
  completedLessons: [],           // Array of day numbers
  bookmarks: [],                  // Saved moments
  unlockedBadges: [],             // Achievement IDs
  totalMinutes: 0,                // Total learning time
  
  // Settings
  voiceSpeed: 'normal',           // 'slow', 'normal', 'fast'
  reminderEnabled: false,
  reminderTime: '09:00',
  autoAdvance: true,              // Auto-advance after audio
  reducedMotion: false,           // Accessibility
  
  // Session
  scene: 'character',             // Current scene
  carouselIndex: 0,               // Carousel position
  weekOffset: 0,                  // Journey week pagination
  sessionStart: null,             // For tracking time
};
```

### Persistence

```javascript
function saveState() {
  localStorage.setItem('kellyState', JSON.stringify(state));
}

function loadState() {
  const saved = localStorage.getItem('kellyState');
  if (saved) Object.assign(state, JSON.parse(saved));
}
```

### Save on Every Change

Call `saveState()` after:
- Selecting a Kelly
- Changing age
- Completing a phase
- Completing a lesson
- Changing any setting
- Adding a bookmark

---

## PART 6: AUDIO SYSTEM

### Priority Chain

1. **Pre-generated audio** from `kelly_video_assets` table
2. **Real-time TTS** via `/api/tts` endpoint
3. **Silent mode** with text-only (if all else fails)

### Audio Class

```javascript
class KellyAudio {
  constructor() {
    this.audio = new Audio();
    this.isPlaying = false;
    
    this.audio.addEventListener('play', () => {
      this.isPlaying = true;
      document.getElementById('lesson-kelly').classList.add('speaking');
      document.getElementById('lesson-kelly').classList.remove('idle');
    });
    
    this.audio.addEventListener('ended', () => {
      this.isPlaying = false;
      document.getElementById('lesson-kelly').classList.remove('speaking');
      document.getElementById('lesson-kelly').classList.add('idle');
      
      // Auto-advance if enabled
      if (state.autoAdvance) {
        setTimeout(() => advancePhase(), 800);
      }
    });
  }
  
  async play(audioUrl) {
    if (!audioUrl) return false;
    
    try {
      this.audio.src = audioUrl;
      this.audio.playbackRate = state.voiceSpeed === 'slow' ? 0.8 : 
                                 state.voiceSpeed === 'fast' ? 1.2 : 1.0;
      await this.audio.play();
      return true;
    } catch (e) {
      console.error('Audio playback failed:', e);
      return false;
    }
  }
  
  stop() {
    this.audio.pause();
    this.audio.currentTime = 0;
    this.isPlaying = false;
  }
}
```

### TTS Fallback

```javascript
async function generateTTS(text) {
  const response = await fetch('/api/tts', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      text,
      voice_id: 'wAdymQH5YucAkXwmrdL0',
      language: state.language
    })
  });
  
  if (!response.ok) return null;
  
  const blob = await response.blob();
  return URL.createObjectURL(blob);
}
```

---

## PART 7: LEARNER EXPERIENCE ENHANCEMENTS

### 7.1 Smart Resume

When app loads, check if learner was mid-lesson:

```javascript
function checkResume() {
  if (state.currentPhase > 0 && state.currentPhase < 5) {
    // Show resume prompt
    showToast(`Continue Day ${state.currentDay}?`, {
      action: 'Resume',
      onAction: () => {
        loadLesson(state.currentDay);
        showScene('lesson');
      }
    });
  }
}
```

### 7.2 Time-Aware Greetings

```javascript
function getGreeting() {
  const hour = new Date().getHours();
  if (hour < 6) return "Burning the midnight oil? Let's learn something amazing.";
  if (hour < 12) return "Good morning! Ready to grow your mind?";
  if (hour < 17) return "Afternoon wisdom awaits!";
  if (hour < 21) return "Evening is perfect for learning.";
  return "A curious mind never rests. Let's go!";
}
```

Display in character select speech bubble.

### 7.3 Haptic Feedback (Mobile)

```javascript
function haptic(type = 'light') {
  if (!navigator.vibrate) return;
  
  const patterns = {
    light: [10],
    medium: [20],
    success: [10, 50, 20],
    celebration: [50, 30, 50, 30, 100]
  };
  
  navigator.vibrate(patterns[type] || patterns.light);
}
```

Call on:
- Phase advance: `haptic('light')`
- Lesson complete: `haptic('celebration')`
- Bookmark: `haptic('medium')`
- Achievement unlock: `haptic('success')`

### 7.4 Progress Celebration Thresholds

```javascript
const MILESTONES = [1, 7, 30, 50, 100, 150, 200, 250, 300, 365];

function checkMilestone(completedCount) {
  if (MILESTONES.includes(completedCount)) {
    triggerMilestoneAnimation(completedCount);
    
    if (completedCount === 7) unlockBadge('week-streak');
    if (completedCount === 30) unlockBadge('month-master');
    if (completedCount === 100) unlockBadge('century');
    if (completedCount === 365) unlockBadge('legend');
  }
}
```

### 7.5 Kelly's Encouraging Voice

Replace all error/loading messages with Kelly's personality:

| System Message | Kelly's Voice |
|----------------|---------------|
| "Loading..." | "One moment—getting your lesson..." |
| "Error loading" | "Let me try that again..." |
| "No internet" | "Hmm, I can't reach my library. Check your connection?" |
| "Lesson complete" | "You learned something beautiful today." |
| "Streak lost" | "Every day is a fresh start. Let's begin again!" |

### 7.6 Visual Feedback for Every Tap

```javascript
function createTapFeedback(element, x, y) {
  const ripple = document.createElement('div');
  ripple.className = 'tap-feedback';
  ripple.style.left = x + 'px';
  ripple.style.top = y + 'px';
  element.appendChild(ripple);
  setTimeout(() => ripple.remove(), 400);
}
```

```css
.tap-feedback {
  position: absolute;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: rgba(255,255,255,0.3);
  transform: translate(-50%, -50%) scale(0);
  animation: tapPulse 0.4s ease forwards;
  pointer-events: none;
}

@keyframes tapPulse {
  to { transform: translate(-50%, -50%) scale(2); opacity: 0; }
}
```

### 7.7 Reduced Motion Support

```javascript
const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

if (prefersReducedMotion) {
  document.documentElement.classList.add('reduced-motion');
}
```

```css
.reduced-motion * {
  animation-duration: 0.01ms !important;
  transition-duration: 0.01ms !important;
}
```

### 7.8 Keyboard Navigation (Desktop)

```javascript
document.addEventListener('keydown', (e) => {
  if (state.scene !== 'lesson') return;
  
  if (e.key === 'ArrowRight' || e.key === ' ') {
    e.preventDefault();
    advancePhase();
  }
  
  if (e.key === 'ArrowLeft') {
    e.preventDefault();
    prevPhase();
  }
  
  if (e.key === 'b') {
    toggleBookmark();
  }
  
  if (e.key === 'Escape') {
    showScene('journey');
  }
});
```

### 7.9 Session Time Tracking

```javascript
function startSession() {
  state.sessionStart = Date.now();
}

function endSession() {
  if (state.sessionStart) {
    const minutes = Math.floor((Date.now() - state.sessionStart) / 60000);
    state.totalMinutes += minutes;
    state.sessionStart = null;
    saveState();
  }
}

// Track on visibility change
document.addEventListener('visibilitychange', () => {
  if (document.hidden) {
    endSession();
  } else {
    startSession();
  }
});
```

### 7.10 Skeleton Loading States

Instead of spinners, use content-shaped skeletons:

```css
.skeleton {
  background: linear-gradient(90deg, 
    var(--bg-card) 25%, 
    var(--bg-card-hover) 50%, 
    var(--bg-card) 75%
  );
  background-size: 200% 100%;
  animation: shimmer 1.5s infinite;
  border-radius: 8px;
}

@keyframes shimmer {
  0% { background-position: 200% 0; }
  100% { background-position: -200% 0; }
}

.skeleton-text {
  height: 16px;
  margin-bottom: 8px;
}

.skeleton-avatar {
  width: 60px;
  height: 60px;
  border-radius: 50%;
}
```

### 7.11 Offline Indicator

```javascript
function updateOnlineStatus() {
  const isOnline = navigator.onLine;
  document.body.classList.toggle('offline', !isOnline);
  
  if (!isOnline) {
    showToast("You're offline. Some features may be limited.", { duration: 5000 });
  }
}

window.addEventListener('online', updateOnlineStatus);
window.addEventListener('offline', updateOnlineStatus);
```

### 7.12 Share What You Learned

```javascript
async function shareLesson() {
  const text = `I just learned about "${currentLesson.topic}" on Day ${state.currentDay} of my Curious Kelly journey! 🧠✨`;
  
  if (navigator.share) {
    await navigator.share({
      title: 'Curious Kelly',
      text,
      url: 'https://curiouskelly.com'
    });
  } else {
    // Fallback: copy to clipboard
    await navigator.clipboard.writeText(text);
    showToast('Copied to clipboard!');
  }
}
```

---

## PART 8: UI COMPONENTS

### 8.1 Toast Notifications

```javascript
function showToast(message, options = {}) {
  const { duration = 3000, action, onAction } = options;
  
  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.innerHTML = `
    <span>${message}</span>
    ${action ? `<button class="toast-action">${action}</button>` : ''}
  `;
  
  if (action && onAction) {
    toast.querySelector('.toast-action').addEventListener('click', onAction);
  }
  
  document.body.appendChild(toast);
  
  setTimeout(() => {
    toast.classList.add('fade-out');
    setTimeout(() => toast.remove(), 300);
  }, duration);
}
```

```css
.toast {
  position: fixed;
  bottom: 100px;
  left: 50%;
  transform: translateX(-50%);
  background: var(--bg-card);
  padding: 12px 20px;
  border-radius: 30px;
  display: flex;
  align-items: center;
  gap: 12px;
  box-shadow: 0 4px 20px rgba(0,0,0,0.3);
  z-index: 1000;
  animation: slideUp 0.3s ease;
}

@keyframes slideUp {
  from { transform: translateX(-50%) translateY(20px); opacity: 0; }
  to { transform: translateX(-50%) translateY(0); opacity: 1; }
}
```

### 8.2 Phase Transition Animation

```javascript
function animatePhaseTransition(direction) {
  const caption = document.getElementById('caption-text');
  
  // Slide out
  caption.style.transform = `translateX(${direction === 'next' ? '-20px' : '20px'})`;
  caption.style.opacity = '0';
  
  setTimeout(() => {
    // Update content
    updatePhaseContent();
    
    // Slide in from opposite side
    caption.style.transform = `translateX(${direction === 'next' ? '20px' : '-20px'})`;
    
    requestAnimationFrame(() => {
      caption.style.transform = 'translateX(0)';
      caption.style.opacity = '1';
    });
  }, 150);
}
```

### 8.3 Streak Fire Animation

When streak increases:

```css
.streak-fire {
  animation: fireGrow 0.5s ease;
}

@keyframes fireGrow {
  0% { transform: scale(1); }
  50% { transform: scale(1.5) rotate(-10deg); }
  100% { transform: scale(1) rotate(0); }
}
```

### 8.4 Achievement Unlock Animation

```javascript
function showAchievementUnlock(badge) {
  const overlay = document.createElement('div');
  overlay.className = 'achievement-unlock-overlay';
  overlay.innerHTML = `
    <div class="achievement-unlock">
      <div class="badge-glow"></div>
      <div class="badge-icon">${badge.icon}</div>
      <div class="badge-name">${badge.name}</div>
      <div class="badge-desc">${badge.desc}</div>
      <button class="btn-dismiss">Nice!</button>
    </div>
  `;
  
  document.body.appendChild(overlay);
  haptic('success');
  
  overlay.querySelector('.btn-dismiss').addEventListener('click', () => {
    overlay.classList.add('fade-out');
    setTimeout(() => overlay.remove(), 300);
  });
}
```

---

## PART 9: COMPLETE SETTINGS WIRING

### Age Slider

```javascript
document.getElementById('age-slider').addEventListener('input', (e) => {
  state.age = parseInt(e.target.value);
  
  // Update display
  document.getElementById('age-value').textContent = state.age;
  document.getElementById('age-emoji').textContent = getAgeEmoji(state.age);
  
  // Rebuild carousel with new age-appropriate images
  rebuildCarouselImages();
  
  saveState();
});
```

### Language Selector

```javascript
document.getElementById('btn-language').addEventListener('click', () => {
  showPicker('Language', [
    { value: 'en', label: 'English' },
    { value: 'es', label: 'Español' },
    { value: 'fr', label: 'Français' }
  ], state.language, (value) => {
    state.language = value;
    saveState();
    updateSettingsUI();
  });
});
```

### Voice Speed

```javascript
document.getElementById('btn-voice-speed').addEventListener('click', () => {
  showPicker('Voice Speed', [
    { value: 'slow', label: 'Slow' },
    { value: 'normal', label: 'Normal' },
    { value: 'fast', label: 'Fast' }
  ], state.voiceSpeed, (value) => {
    state.voiceSpeed = value;
    saveState();
    updateSettingsUI();
  });
});
```

### Reminder Toggle

```javascript
document.getElementById('toggle-reminder').addEventListener('click', async function() {
  this.classList.toggle('active');
  state.reminderEnabled = this.classList.contains('active');
  
  if (state.reminderEnabled) {
    // Request notification permission
    const permission = await Notification.requestPermission();
    if (permission !== 'granted') {
      this.classList.remove('active');
      state.reminderEnabled = false;
      showToast('Please enable notifications in your browser settings');
    }
  }
  
  saveState();
});
```

### Reminder Time

```javascript
document.getElementById('btn-reminder-time').addEventListener('click', () => {
  showTimePicker(state.reminderTime, (time) => {
    state.reminderTime = time;
    saveState();
    updateSettingsUI();
    scheduleReminder();
  });
});
```

---

## PART 10: TESTING CHECKLIST

### Character Select
- [ ] Carousel shows 12 Kelly personas
- [ ] Kelly images load from manifest (not emoji)
- [ ] Swipe navigates between Kellys
- [ ] Arrow buttons work
- [ ] Selected Kelly has glow animation
- [ ] Stats bars animate on center
- [ ] Speech bubble shows on center
- [ ] Color theme updates with each Kelly
- [ ] "Let's Learn" starts lesson

### Lesson Player
- [ ] Phase progress shows 5 bars
- [ ] Day badge shows correct day + topic
- [ ] Kelly image matches selected persona
- [ ] Kelly image matches age bucket
- [ ] Tap right advances phase
- [ ] Tap left goes back
- [ ] Ripple feedback on tap
- [ ] Caption updates with phase content
- [ ] Bookmark button toggles
- [ ] Phase 5 complete → Celebration screen

### Journey
- [ ] Stats show streak, completed, time
- [ ] Week view shows 7 days
- [ ] Week navigation works
- [ ] Calendar view shows 12 months
- [ ] Completed days are highlighted
- [ ] Current day has border
- [ ] Locked days are dimmed
- [ ] Tapping day loads that lesson

### Settings
- [ ] Kelly preview shows current Kelly
- [ ] Age slider updates images everywhere
- [ ] Language selector works
- [ ] Voice speed selector works
- [ ] Reminder toggle works
- [ ] Reminder time picker works
- [ ] Achievements shows correct count
- [ ] Bookmarks shows correct count

### Completion
- [ ] Confetti triggers
- [ ] Kelly image shows
- [ ] Streak count is correct
- [ ] Tomorrow's topic loads
- [ ] Continue button advances day
- [ ] Review button replays lesson

### Persistence
- [ ] Refresh page → Same Kelly selected
- [ ] Refresh page → Same age
- [ ] Refresh page → Progress preserved
- [ ] Close tab and reopen → State preserved

### Mobile
- [ ] Works on iOS Safari
- [ ] Works on Android Chrome
- [ ] No horizontal scroll
- [ ] Bottom nav respects safe area
- [ ] Touch targets are 44px minimum

---

## PART 11: ERROR HANDLING

### Graceful Degradation

```javascript
async function loadLesson(dayNumber) {
  try {
    // Try Supabase
    const lesson = await loadLessonFromSupabase(dayNumber);
    if (lesson) return lesson;
  } catch (e) {
    console.warn('Supabase load failed:', e);
  }
  
  // Fallback to embedded content
  return loadFallbackLesson(dayNumber);
}
```

### Kelly-Voiced Errors

```javascript
function showError(message) {
  const kellyMessages = {
    'network': "I'm having trouble connecting. Let's try again in a moment.",
    'audio': "My voice is taking a break. You can still read along!",
    'video': "The video is being shy. Here's the lesson in text form.",
    'generic': "Something went sideways. Let me try that again..."
  };
  
  showToast(kellyMessages[message] || kellyMessages.generic);
}
```

---

## PART 12: PERFORMANCE

### Lazy Load Images

```javascript
const imageObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const img = entry.target;
      img.src = img.dataset.src;
      imageObserver.unobserve(img);
    }
  });
});

// Use data-src for images outside viewport
<img data-src="${imageUrl}" class="lazy">
```

### Preload Next Lesson

```javascript
function preloadNextLesson() {
  const nextDay = state.currentDay + 1;
  if (nextDay <= 365) {
    loadLesson(nextDay).then(lesson => {
      lessonsCache[nextDay] = lesson;
    });
  }
}
```

### Cache Manifest

```javascript
let manifestCache = null;

async function loadManifest() {
  if (manifestCache) return manifestCache;
  
  const resp = await fetch(CONFIG.MANIFEST_URL);
  manifestCache = await resp.json();
  return manifestCache;
}
```

---

## PART 13: DEPLOYMENT

### Files to Update

1. Copy `kelly-app-complete.html` → `public/learn.html`
2. Ensure `/assets/kelly/kelly-personas-manifest.json` is accessible
3. Verify Supabase tables have data
4. Verify `/api/tts` endpoint exists

### Environment Variables

```
SUPABASE_URL=https://tvjalxxsyryjphkforjv.supabase.co
SUPABASE_ANON_KEY=...
ELEVENLABS_API_KEY=...
```

### Vercel Deploy

```bash
vercel --prod
```

---

## PART 14: SUCCESS METRICS

After launch, track:

1. **Daily Active Learners** — Unique users who start a lesson
2. **Lesson Completion Rate** — Finish all 5 phases
3. **Streak Retention** — 7-day, 30-day streak rates
4. **Kelly Selection** — Most popular personas
5. **Age Distribution** — Learning age demographics
6. **Session Duration** — Average time per session
7. **Phase Drop-off** — Which phase loses learners

---

## EXECUTE NOW

1. **Copy** `kelly-app-complete.html` to `public/learn.html`
2. **Verify** manifest loads at `/assets/kelly/kelly-personas-manifest.json`
3. **Test** Supabase connection with `loadLesson(1)`
4. **Run through** the full testing checklist
5. **Fix** any broken interactions
6. **Deploy** to Vercel
7. **Test** on real mobile device

---

## PHILOSOPHY

This isn't just a lesson player. It's a daily ritual.

- **Kelly is the constant** — She's always there, always encouraging
- **Progress is visible** — Learners see how far they've come
- **Every tap feels good** — Haptics, animations, sounds
- **Failure is forgiven** — Streaks can restart, no shame
- **Learning is play** — Video game feel, not homework feel

The goal: Make learning as habitual as checking Instagram, but infinitely more rewarding.

---

*For Cursor — December 2024*
*Ship it for Nicolette. Ship it for the learners.*
