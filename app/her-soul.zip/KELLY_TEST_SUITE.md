# CURIOUS KELLY — GLOBAL DEPLOYMENT TEST SUITE
## Pre-Launch Quality Assurance & Edge Case Coverage

**Version:** 1.0.0  
**Launch Date:** December 17, 2024  
**Production URL:** https://curiouskelly.com  
**Staging URL:** https://curiouskelly-3mfcx18hs-lotd.vercel.app

---

## TABLE OF CONTENTS

1. [Test Environment Matrix](#1-test-environment-matrix)
2. [Core Functionality Tests](#2-core-functionality-tests)
3. [Edge Cases](#3-edge-cases)
4. [Global Deployment Scenarios](#4-global-deployment-scenarios)
5. [Performance Benchmarks](#5-performance-benchmarks)
6. [Accessibility Compliance](#6-accessibility-compliance)
7. [Security Testing](#7-security-testing)
8. [Native App Testing (iOS/Android)](#8-native-app-testing)
9. [Offline & Network Resilience](#9-offline--network-resilience)
10. [Localization Testing](#10-localization-testing)
11. [Audio/Video Pipeline Tests](#11-audiovideo-pipeline-tests)
12. [State Persistence Tests](#12-state-persistence-tests)
13. [Age-Specific Content Tests](#13-age-specific-content-tests)
14. [Load & Stress Testing](#14-load--stress-testing)
15. [Regression Test Suite](#15-regression-test-suite)
16. [Sign-Off Checklist](#16-sign-off-checklist)

---

## 1. TEST ENVIRONMENT MATRIX

### 1.1 Mobile Devices (Primary Target)

| Device | OS Version | Browser | Priority |
|--------|------------|---------|----------|
| iPhone 15 Pro | iOS 17.x | Safari | P0 |
| iPhone 14 | iOS 17.x | Safari | P0 |
| iPhone 13 | iOS 16.x | Safari | P0 |
| iPhone SE (3rd gen) | iOS 17.x | Safari | P1 |
| iPhone 12 mini | iOS 16.x | Safari | P1 |
| Samsung Galaxy S24 | Android 14 | Chrome | P0 |
| Samsung Galaxy S23 | Android 14 | Chrome | P0 |
| Google Pixel 8 | Android 14 | Chrome | P0 |
| Google Pixel 7a | Android 13 | Chrome | P1 |
| Samsung Galaxy A54 | Android 13 | Chrome | P1 |
| OnePlus 12 | Android 14 | Chrome | P2 |

### 1.2 Tablets

| Device | OS Version | Browser | Priority |
|--------|------------|---------|----------|
| iPad Pro 12.9" | iPadOS 17.x | Safari | P1 |
| iPad Air | iPadOS 17.x | Safari | P1 |
| iPad mini | iPadOS 17.x | Safari | P2 |
| Samsung Galaxy Tab S9 | Android 14 | Chrome | P2 |

### 1.3 Desktop (Secondary)

| OS | Browser | Version | Priority |
|----|---------|---------|----------|
| macOS Sonoma | Safari | 17.x | P1 |
| macOS Sonoma | Chrome | 120+ | P1 |
| Windows 11 | Chrome | 120+ | P1 |
| Windows 11 | Edge | 120+ | P2 |
| Windows 11 | Firefox | 120+ | P2 |
| Ubuntu 22.04 | Chrome | 120+ | P3 |

### 1.4 Screen Sizes

| Category | Width Range | Test Devices |
|----------|-------------|--------------|
| Small Mobile | 320-375px | iPhone SE, older Androids |
| Standard Mobile | 376-428px | iPhone 14, Galaxy S24 |
| Large Mobile | 429-480px | iPhone Pro Max |
| Tablet Portrait | 768-834px | iPad mini, iPad Air |
| Tablet Landscape | 1024-1194px | iPad Pro |
| Desktop | 1200px+ | MacBook, Windows |

---

## 2. CORE FUNCTIONALITY TESTS

### 2.1 Character Select Scene

| ID | Test Case | Expected Result | Priority |
|----|-----------|-----------------|----------|
| CS-001 | Load character select on fresh visit | 12 Kelly personas visible in carousel | P0 |
| CS-002 | Swipe left on carousel | Previous Kelly centers with animation | P0 |
| CS-003 | Swipe right on carousel | Next Kelly centers with animation | P0 |
| CS-004 | Tap left arrow | Previous Kelly centers | P0 |
| CS-005 | Tap right arrow | Next Kelly centers | P0 |
| CS-006 | Tap on centered Kelly | Bounce animation plays | P1 |
| CS-007 | Tap on side Kelly | That Kelly centers | P1 |
| CS-008 | Verify Kelly images load | Real photos, not emoji fallbacks | P0 |
| CS-009 | Verify Kelly image fallback | Emoji shows if image fails to load | P1 |
| CS-010 | Speech bubble shows quote | Quote visible for centered Kelly | P1 |
| CS-011 | Stats bars animate | 4 bars fill on center Kelly | P1 |
| CS-012 | Background color changes | Gradient matches Kelly's color | P1 |
| CS-013 | Tap "Let's Learn" | Navigates to lesson scene | P0 |
| CS-014 | Tap "Take the Match Quiz" | Quiz flow initiates (or coming soon) | P2 |
| CS-015 | Carousel dots update | Active dot highlights current Kelly | P1 |

### 2.2 Lesson Player Scene

| ID | Test Case | Expected Result | Priority |
|----|-----------|-----------------|----------|
| LP-001 | Load lesson | Day badge shows day number + topic | P0 |
| LP-002 | Phase progress bars | 5 bars visible, first active | P0 |
| LP-003 | Kelly image displays | Correct persona + age variant | P0 |
| LP-004 | Caption text loads | Script from lesson_atoms displayed | P0 |
| LP-005 | Tap right zone | Advances to next phase | P0 |
| LP-006 | Tap left zone | Goes to previous phase | P0 |
| LP-007 | Tap progress bar | Jumps to that phase | P1 |
| LP-008 | Ripple effect on tap | Visual feedback appears | P1 |
| LP-009 | Bookmark button | Toggles bookmarked state | P1 |
| LP-010 | Infographic button | Opens overlay with visual | P1 |
| LP-011 | Ask Kelly button | Opens chat/question interface | P2 |
| LP-012 | Reaction buttons | Visual feedback on tap | P2 |
| LP-013 | Complete all 5 phases | Navigates to completion scene | P0 |
| LP-014 | Kelly idle animation | Gentle floating when not speaking | P1 |
| LP-015 | Kelly speaking animation | Pulse/scale when audio plays | P1 |
| LP-016 | Typewriter effect | Text appears letter by letter | P2 |
| LP-017 | Day badge tap | Opens journey calendar | P1 |

### 2.3 Journey Scene

| ID | Test Case | Expected Result | Priority |
|----|-----------|-----------------|----------|
| JN-001 | Stats display | Streak, completed, time shown | P0 |
| JN-002 | Week view loads | 7 days with topics visible | P0 |
| JN-003 | Week navigation | Previous/next week buttons work | P0 |
| JN-004 | Completed day styling | Purple background, checkmark | P0 |
| JN-005 | Current day styling | Border highlight, play icon | P0 |
| JN-006 | Locked day styling | Dimmed, lock icon | P0 |
| JN-007 | Tap completed day | Replays that lesson | P1 |
| JN-008 | Tap current day | Starts current lesson | P0 |
| JN-009 | Tap locked day | No action (or unlock prompt) | P1 |
| JN-010 | Calendar view toggle | Switches to 12-month grid | P1 |
| JN-011 | Calendar view navigation | Can scroll through months | P1 |
| JN-012 | Milestone markers | Stars on Day 7, 30, 100, 365 | P2 |
| JN-013 | Month themes display | Theme labels under month names | P2 |

### 2.4 Settings Scene

| ID | Test Case | Expected Result | Priority |
|----|-----------|-----------------|----------|
| ST-001 | Kelly preview shows | Current Kelly image + name | P0 |
| ST-002 | Change Kelly button | Returns to character select | P0 |
| ST-003 | Age slider moves | Value updates 2-102 | P0 |
| ST-004 | Age slider updates images | Kelly images change to age variant | P0 |
| ST-005 | Age emoji updates | 👶🧒👤👴🧓 based on range | P1 |
| ST-006 | Language selector | Opens picker, changes language | P1 |
| ST-007 | Voice speed selector | Opens picker, changes speed | P1 |
| ST-008 | Reminder toggle | Toggles on/off with permission | P1 |
| ST-009 | Reminder time picker | Opens time picker, saves time | P1 |
| ST-010 | Achievements count | Shows X of 24 unlocked | P1 |
| ST-011 | Achievements tap | Opens achievements scene | P1 |
| ST-012 | Bookmarks count | Shows X saved moments | P1 |
| ST-013 | Downloads tap | Opens downloads (or coming soon) | P2 |
| ST-014 | Profile tap | Opens profile (or coming soon) | P2 |
| ST-015 | Family tap | Opens family management | P2 |
| ST-016 | Subscription status | Shows current plan | P1 |
| ST-017 | About tap | Shows about info | P2 |
| ST-018 | Help tap | Opens help/FAQ | P2 |
| ST-019 | Feedback tap | Opens feedback form | P2 |

### 2.5 Completion Scene

| ID | Test Case | Expected Result | Priority |
|----|-----------|-----------------|----------|
| CP-001 | Kelly avatar shows | Current Kelly with celebration | P0 |
| CP-002 | Streak count accurate | Matches actual streak | P0 |
| CP-003 | Confetti triggers | 60 pieces fall on load | P1 |
| CP-004 | Tomorrow's topic loads | Fetches next day from DB | P1 |
| CP-005 | Continue button | Advances to next day lesson | P0 |
| CP-006 | Review button | Replays current lesson | P1 |
| CP-007 | Fire emoji wiggles | Animation on streak display | P2 |
| CP-008 | Milestone celebration | Special animation at 7, 30, 100 | P2 |

### 2.6 Achievements Scene

| ID | Test Case | Expected Result | Priority |
|----|-----------|-----------------|----------|
| AC-001 | Badge grid displays | 12+ badges in 3-column grid | P1 |
| AC-002 | Unlocked badges colored | Full color with description | P1 |
| AC-003 | Locked badges greyed | Grayscale, 40% opacity | P1 |
| AC-004 | Progress count | "X of 24 unlocked" accurate | P1 |
| AC-005 | Back button | Returns to settings | P1 |
| AC-006 | Badge unlock animation | Shows when new badge earned | P2 |

### 2.7 Bottom Navigation

| ID | Test Case | Expected Result | Priority |
|----|-----------|-----------------|----------|
| BN-001 | Journey button | Navigates to journey scene | P0 |
| BN-002 | Play button | Navigates to lesson scene | P0 |
| BN-003 | Settings button | Navigates to settings scene | P0 |
| BN-004 | Active state | Current scene button highlighted | P0 |
| BN-005 | Play button elevated | Center button raised, glowing | P1 |
| BN-006 | Safe area inset | Respects iPhone notch/home indicator | P0 |

---

## 3. EDGE CASES

### 3.1 State Edge Cases

| ID | Edge Case | Expected Behavior |
|----|-----------|-------------------|
| EC-001 | First-time visitor (no localStorage) | Default state: scientist, age 30, day 1 |
| EC-002 | Corrupted localStorage | Gracefully reset to defaults |
| EC-003 | localStorage full | Warn user, continue without saving |
| EC-004 | Day 365 completion | Show "Journey Complete" special screen |
| EC-005 | Day 366+ attempt | Loop to Day 1 or show completion |
| EC-006 | Negative day number | Clamp to Day 1 |
| EC-007 | Age < 2 | Clamp to 2 |
| EC-008 | Age > 102 | Clamp to 102 |
| EC-009 | Non-integer age | Round to nearest integer |
| EC-010 | Unknown persona ID | Default to 'scientist' |
| EC-011 | Phase > 4 | Trigger completion |
| EC-012 | Phase < 0 | Clamp to 0 |
| EC-013 | Empty completedLessons array | Show 0 completed |
| EC-014 | Duplicate lesson in completedLessons | Deduplicate silently |

### 3.2 Network Edge Cases

| ID | Edge Case | Expected Behavior |
|----|-----------|-------------------|
| EC-020 | No internet on load | Show offline indicator, use cached data |
| EC-021 | Internet drops mid-lesson | Continue with current content, toast notification |
| EC-022 | Slow connection (3G) | Show skeleton loading, timeout after 10s |
| EC-023 | Manifest fetch fails | Use fallback KELLYS array |
| EC-024 | Supabase query fails | Use fallback lesson content |
| EC-025 | Audio fetch fails | Fall back to TTS, then text-only |
| EC-026 | TTS API fails | Continue with text-only mode |
| EC-027 | CDN image fails | Show emoji fallback |
| EC-028 | Partial manifest (missing persona) | Skip that persona in carousel |
| EC-029 | CORS error | Log error, use fallback |
| EC-030 | 429 rate limit | Show "Take a breath" message, retry after delay |

### 3.3 Content Edge Cases

| ID | Edge Case | Expected Behavior |
|----|-----------|-------------------|
| EC-040 | Missing lesson_atoms for archetype | Show generic content or different archetype |
| EC-041 | Empty script text | Show "Content loading..." placeholder |
| EC-042 | Very long script (500+ chars) | Truncate or paginate caption |
| EC-043 | Script with special characters | Properly escape HTML entities |
| EC-044 | Script with emoji | Render emoji correctly |
| EC-045 | Script in wrong language | Show in whatever language returned |
| EC-046 | Missing core_lesson for day | Show "Lesson not available" |
| EC-047 | Null topic | Show "Day X" as fallback |
| EC-048 | Missing image for age bucket | Fall back to adult image |
| EC-049 | Invalid image URL | Trigger onerror, show emoji |

### 3.4 Interaction Edge Cases

| ID | Edge Case | Expected Behavior |
|----|-----------|-------------------|
| EC-060 | Double-tap on phase advance | Debounce, advance only once |
| EC-061 | Rapid swipe on carousel | Smooth deceleration, no jank |
| EC-062 | Tap during animation | Queue action or ignore |
| EC-063 | Swipe during scene transition | Ignore until transition complete |
| EC-064 | Back button during lesson | Return to journey (not browser back) |
| EC-065 | Refresh mid-lesson | Resume from same phase (smart resume) |
| EC-066 | Tab switch and return | Continue where left off |
| EC-067 | Screen lock and unlock | Pause audio, resume on unlock |
| EC-068 | Phone call interruption | Pause audio, resume after |
| EC-069 | Notification banner | App continues underneath |

### 3.5 Device Edge Cases

| ID | Edge Case | Expected Behavior |
|----|-----------|-------------------|
| EC-080 | 320px width screen | All content visible, no horizontal scroll |
| EC-081 | Landscape orientation | Adapt layout or show rotation prompt |
| EC-082 | Dynamic Island (iPhone 14 Pro+) | Content below Dynamic Island |
| EC-083 | Home indicator (iPhone X+) | Bottom nav above indicator |
| EC-084 | Foldable phone (Galaxy Fold) | Handle fold/unfold gracefully |
| EC-085 | High refresh rate (120Hz) | Smooth 120fps animations |
| EC-086 | Low-end device (2GB RAM) | Graceful degradation, reduced effects |
| EC-087 | Dark mode system setting | Respect or maintain dark theme |
| EC-088 | Large text accessibility | Scale appropriately |
| EC-089 | Bold text accessibility | Apply system bold preference |

---

## 4. GLOBAL DEPLOYMENT SCENARIOS

### 4.1 Timezone Testing

| ID | Scenario | Test |
|----|----------|------|
| TZ-001 | User in PST (UTC-8) | Streak resets at midnight PST |
| TZ-002 | User in EST (UTC-5) | Streak resets at midnight EST |
| TZ-003 | User in UTC | Streak resets at midnight UTC |
| TZ-004 | User in IST (UTC+5:30) | Streak resets at midnight IST |
| TZ-005 | User in JST (UTC+9) | Streak resets at midnight JST |
| TZ-006 | User in AEST (UTC+11) | Streak resets at midnight AEST |
| TZ-007 | Timezone change (travel) | Streak based on original timezone |
| TZ-008 | DST transition | Handle spring forward/fall back |
| TZ-009 | Reminder at 9 AM local | Fires at correct local time |
| TZ-010 | "Yesterday" calculation | Correct for user's timezone |

### 4.2 Regional Content Delivery

| ID | Region | CDN Test |
|----|--------|----------|
| RG-001 | North America | Supabase edge serves < 100ms |
| RG-002 | Europe | Supabase edge serves < 150ms |
| RG-003 | Asia Pacific | Supabase edge serves < 200ms |
| RG-004 | South America | Supabase edge serves < 200ms |
| RG-005 | Africa | Supabase edge serves < 300ms |
| RG-006 | Australia | Supabase edge serves < 200ms |

### 4.3 Language/Locale Testing

| ID | Locale | Tests |
|----|--------|-------|
| LO-001 | en-US | Default language, US date format |
| LO-002 | en-GB | UK date format (DD/MM/YYYY) |
| LO-003 | es-ES | Spanish UI strings |
| LO-004 | es-MX | Spanish (Latin American) |
| LO-005 | fr-FR | French UI strings |
| LO-006 | de-DE | German UI strings |
| LO-007 | pt-BR | Portuguese (Brazilian) |
| LO-008 | zh-CN | Simplified Chinese |
| LO-009 | ja-JP | Japanese |
| LO-010 | ko-KR | Korean |
| LO-011 | ar-SA | Arabic (RTL support) |
| LO-012 | he-IL | Hebrew (RTL support) |

### 4.4 Currency/Payment Testing

| ID | Region | Payment Test |
|----|--------|--------------|
| PY-001 | USA | USD Stripe payment |
| PY-002 | UK | GBP Stripe payment |
| PY-003 | EU | EUR Stripe payment |
| PY-004 | Japan | JPY Stripe payment |
| PY-005 | India | INR Stripe payment |
| PY-006 | Brazil | BRL Stripe payment |
| PY-007 | Apple Pay | iOS in-app purchase |
| PY-008 | Google Pay | Android in-app purchase |

---

## 5. PERFORMANCE BENCHMARKS

### 5.1 Load Time Targets

| Metric | Target | Maximum |
|--------|--------|---------|
| First Contentful Paint (FCP) | < 1.0s | 1.5s |
| Largest Contentful Paint (LCP) | < 2.0s | 2.5s |
| Time to Interactive (TTI) | < 2.5s | 3.5s |
| Cumulative Layout Shift (CLS) | < 0.1 | 0.15 |
| First Input Delay (FID) | < 100ms | 150ms |
| Total Blocking Time (TBT) | < 200ms | 300ms |

### 5.2 Asset Size Budgets

| Asset Type | Target | Maximum |
|------------|--------|---------|
| HTML (learn.html) | < 100KB | 150KB |
| CSS (inline) | < 30KB | 50KB |
| JavaScript (inline) | < 80KB | 120KB |
| Kelly head image | < 100KB | 200KB |
| Manifest JSON | < 20KB | 30KB |
| Audio clip (per phase) | < 500KB | 1MB |

### 5.3 Animation Performance

| Animation | Target FPS | Minimum FPS |
|-----------|------------|-------------|
| Carousel swipe | 60 fps | 30 fps |
| Kelly float | 60 fps | 30 fps |
| Scene transition | 60 fps | 30 fps |
| Confetti | 60 fps | 24 fps |
| Progress bar fill | 60 fps | 30 fps |

### 5.4 Memory Usage

| Scenario | Target | Maximum |
|----------|--------|---------|
| Initial load | < 50MB | 80MB |
| During lesson | < 80MB | 120MB |
| After 10 lessons | < 100MB | 150MB |
| Memory leak after 1 hour | None | < 10MB growth |

---

## 6. ACCESSIBILITY COMPLIANCE

### 6.1 WCAG 2.1 AA Requirements

| ID | Requirement | Test |
|----|-------------|------|
| A11Y-001 | Color contrast 4.5:1 | All text meets ratio |
| A11Y-002 | Touch targets 44×44px | All buttons meet minimum |
| A11Y-003 | Focus indicators | Visible keyboard focus |
| A11Y-004 | Screen reader labels | All images have alt text |
| A11Y-005 | Reduced motion | Animations disabled when preferred |
| A11Y-006 | Text scaling | Content readable at 200% |
| A11Y-007 | No seizure triggers | No flashing > 3 times/sec |
| A11Y-008 | Audio controls | Pause/stop available |
| A11Y-009 | Error identification | Clear error messages |
| A11Y-010 | Consistent navigation | Same location across scenes |

### 6.2 Screen Reader Testing

| Reader | Platform | Status |
|--------|----------|--------|
| VoiceOver | iOS | Must test |
| TalkBack | Android | Must test |
| VoiceOver | macOS | Should test |
| NVDA | Windows | Should test |
| JAWS | Windows | Optional |

### 6.3 Accessibility Test Cases

| ID | Test Case | Expected |
|----|-----------|----------|
| SR-001 | Navigate carousel with VoiceOver | Announces Kelly name + position |
| SR-002 | Advance phase with VoiceOver | Announces phase name |
| SR-003 | Complete lesson with VoiceOver | Announces completion |
| SR-004 | Navigate settings with VoiceOver | All options announced |
| SR-005 | Keyboard-only navigation | All features accessible |
| SR-006 | Tab order logical | Flows top-to-bottom, left-to-right |

---

## 7. SECURITY TESTING

### 7.1 Client-Side Security

| ID | Test | Expected |
|----|------|----------|
| SEC-001 | No secrets in HTML source | Config loaded from config.js |
| SEC-002 | Supabase anon key only | No service key exposed |
| SEC-003 | XSS prevention | User input sanitized |
| SEC-004 | localStorage encryption | Sensitive data encrypted (if any) |
| SEC-005 | HTTPS enforcement | HTTP redirects to HTTPS |
| SEC-006 | CSP headers | Content Security Policy set |
| SEC-007 | No eval() usage | No dynamic code execution |

### 7.2 API Security

| ID | Test | Expected |
|----|------|----------|
| SEC-010 | Supabase RLS enabled | Row Level Security on all tables |
| SEC-011 | Rate limiting | API rate limited per IP |
| SEC-012 | Input validation | Server-side validation on /api/tts |
| SEC-013 | No SQL injection | Parameterized queries only |
| SEC-014 | CORS configured | Only curiouskelly.com allowed |

### 7.3 Privacy (COPPA Compliance)

| ID | Requirement | Status |
|----|-------------|--------|
| COPPA-001 | No personal data from < 13 without consent | Implemented |
| COPPA-002 | Parental consent flow | Required for young learners |
| COPPA-003 | Data minimization | Only essential data collected |
| COPPA-004 | Deletion capability | User can delete all data |
| COPPA-005 | No behavioral advertising | No ad tracking |
| COPPA-006 | Privacy policy accessible | Link in settings |

---

## 8. NATIVE APP TESTING (iOS/Android)

### 8.1 iOS (WebView / PWA)

| ID | Test | Expected |
|----|------|----------|
| IOS-001 | Add to Home Screen | Creates app icon |
| IOS-002 | Standalone mode | No Safari UI |
| IOS-003 | Status bar styling | Matches app theme |
| IOS-004 | Safe area insets | Content avoids notch |
| IOS-005 | Swipe back gesture | Disabled or handled |
| IOS-006 | Pull to refresh | Disabled or handled |
| IOS-007 | Audio in silent mode | Plays with unmute prompt |
| IOS-008 | Background audio | Continues when screen off |
| IOS-009 | Push notifications | Work via web push |
| IOS-010 | App Store guidelines | Compliant for WebView app |

### 8.2 Android (WebView / PWA)

| ID | Test | Expected |
|----|------|----------|
| AND-001 | Add to Home Screen | Creates app icon |
| AND-002 | Standalone mode | No Chrome UI |
| AND-003 | Status bar color | Matches app theme |
| AND-004 | Navigation bar color | Matches app theme |
| AND-005 | Back button | Navigates within app |
| AND-006 | Recent apps preview | Shows app content |
| AND-007 | Audio playback | Works reliably |
| AND-008 | Push notifications | Work via Firebase |
| AND-009 | Play Store guidelines | Compliant for WebView app |
| AND-010 | Android Auto | Not applicable |

### 8.3 Native Wrapper Testing (Capacitor/Cordova)

| ID | Test | Expected |
|----|------|----------|
| NW-001 | Splash screen | Custom splash displays |
| NW-002 | App icon | Correct icon all sizes |
| NW-003 | Deep links | curiouskelly.com/learn opens app |
| NW-004 | Share extension | Can receive shared content |
| NW-005 | Haptic feedback | Native haptics work |
| NW-006 | In-app purchases | Native payment flow |
| NW-007 | App Store submission | Passes review |
| NW-008 | Play Store submission | Passes review |

---

## 9. OFFLINE & NETWORK RESILIENCE

### 9.1 Offline Capabilities

| ID | Feature | Offline Behavior |
|----|---------|------------------|
| OFF-001 | App shell | Loads from cache |
| OFF-002 | Kelly images | Shows cached or emoji |
| OFF-003 | Current lesson | Continues if already loaded |
| OFF-004 | Progress | Persists to localStorage |
| OFF-005 | Settings | All settings accessible |
| OFF-006 | New lesson | Shows "Connect to continue" |
| OFF-007 | Audio | Shows text-only mode |
| OFF-008 | Sync on reconnect | Uploads pending progress |

### 9.2 Network Transition Tests

| ID | Scenario | Expected |
|----|----------|----------|
| NET-001 | WiFi → Offline | Toast notification, continue |
| NET-002 | Offline → WiFi | Silent reconnect, sync |
| NET-003 | WiFi → Cellular | Continue seamlessly |
| NET-004 | Cellular → WiFi | Continue seamlessly |
| NET-005 | Airplane mode toggle | Handle gracefully |
| NET-006 | VPN connect/disconnect | Continue seamlessly |

### 9.3 Service Worker Tests

| ID | Test | Expected |
|----|------|----------|
| SW-001 | First load caches shell | App works on second load offline |
| SW-002 | Cache invalidation | New version detected, updated |
| SW-003 | Background sync | Progress synced when online |
| SW-004 | Cache size limit | Old assets pruned |

---

## 10. LOCALIZATION TESTING

### 10.1 UI String Coverage

| Language | UI Strings | Content | Audio |
|----------|------------|---------|-------|
| English (en) | 100% | 100% | 100% |
| Spanish (es) | 0% (v1.1) | 0% | 0% |
| French (fr) | 0% (v1.1) | 0% | 0% |

### 10.2 Localization Test Cases

| ID | Test | Expected |
|----|------|----------|
| L10N-001 | Switch language in settings | UI updates immediately |
| L10N-002 | Language persists | Same on reload |
| L10N-003 | Long strings (German) | No overflow, proper wrapping |
| L10N-004 | RTL languages (Arabic) | Layout mirrors correctly |
| L10N-005 | Date formatting | Matches locale (MM/DD vs DD/MM) |
| L10N-006 | Number formatting | Correct decimal/thousand separators |
| L10N-007 | Currency formatting | Correct symbol + placement |

---

## 11. AUDIO/VIDEO PIPELINE TESTS

### 11.1 Audio Tests

| ID | Test | Expected |
|----|------|----------|
| AUD-001 | Pre-generated audio loads | Plays within 1s |
| AUD-002 | TTS fallback triggers | Plays within 3s |
| AUD-003 | Text-only fallback | Shows text immediately |
| AUD-004 | Voice speed slow | 0.8x playback rate |
| AUD-005 | Voice speed normal | 1.0x playback rate |
| AUD-006 | Voice speed fast | 1.2x playback rate |
| AUD-007 | Audio pause on tab switch | Pauses, resumes on return |
| AUD-008 | Audio pause on phone call | Pauses, resumes after |
| AUD-009 | Audio with headphones | Plays to headphones |
| AUD-010 | Bluetooth audio | Plays to BT device |
| AUD-011 | Silent mode (iOS) | Respects or prompts |
| AUD-012 | Do Not Disturb | Audio still plays |

### 11.2 Video Tests (When HeyGen Ready)

| ID | Test | Expected |
|----|------|----------|
| VID-001 | HeyGen video loads | Plays within 2s |
| VID-002 | Video fallback to image+audio | Works when video unavailable |
| VID-003 | Video in portrait | Displays correctly |
| VID-004 | Video in landscape | Adapts or letterboxes |
| VID-005 | Video buffering | Shows loading indicator |
| VID-006 | Video error | Falls back gracefully |

---

## 12. STATE PERSISTENCE TESTS

### 12.1 localStorage Tests

| ID | Test | Expected |
|----|------|----------|
| LS-001 | Save on Kelly change | kellyId persisted |
| LS-002 | Save on age change | age persisted |
| LS-003 | Save on phase advance | currentPhase persisted |
| LS-004 | Save on lesson complete | completedLessons updated |
| LS-005 | Save on bookmark | bookmarks updated |
| LS-006 | Load on app start | All state restored |
| LS-007 | Clear site data | Resets to defaults |
| LS-008 | Incognito mode | Works without persistence |

### 12.2 Cross-Tab Sync

| ID | Test | Expected |
|----|------|----------|
| CT-001 | Change Kelly in Tab A | Tab B reflects on focus |
| CT-002 | Complete lesson in Tab A | Tab B updates on focus |
| CT-003 | Both tabs active | Last write wins |

### 12.3 Supabase Sync (When Auth Added)

| ID | Test | Expected |
|----|------|----------|
| DB-001 | Login syncs server state | Overwrites local if newer |
| DB-002 | Logout clears server state | Local state remains |
| DB-003 | Conflict resolution | Server wins for progress |
| DB-004 | Offline queue | Syncs when online |

---

## 13. AGE-SPECIFIC CONTENT TESTS

### 13.1 Age Bucket Mapping

| Age Range | Bucket | Kelly Image | Content Style |
|-----------|--------|-------------|---------------|
| 2-12 | kid | /age/kid/ | Simple, playful |
| 13-17 | teen | /age/teen/ | Engaging, relatable |
| 18-49 | adult | (default) | Standard |
| 50-75 | elder | /age/elder/ | Clear, respectful |
| 76-102 | super_elder | /age/super_elder/ | Large text option |

### 13.2 Age-Specific Test Cases

| ID | Test | Expected |
|----|------|----------|
| AGE-001 | Set age to 5 | Kid Kelly images load |
| AGE-002 | Set age to 15 | Teen Kelly images load |
| AGE-003 | Set age to 30 | Adult Kelly images load |
| AGE-004 | Set age to 60 | Elder Kelly images load |
| AGE-005 | Set age to 85 | Super Elder Kelly images load |
| AGE-006 | Change age mid-lesson | Kelly image updates |
| AGE-007 | Age slider edge (2) | Works correctly |
| AGE-008 | Age slider edge (102) | Works correctly |

---

## 14. LOAD & STRESS TESTING

### 14.1 Concurrent User Targets

| Tier | Users | Response Time |
|------|-------|---------------|
| Normal | 1,000 | < 200ms |
| Peak | 10,000 | < 500ms |
| Viral | 100,000 | < 2s (degraded) |

### 14.2 Load Test Scenarios

| ID | Scenario | Target |
|----|----------|--------|
| LOAD-001 | 1,000 users load app | 95% < 2s LCP |
| LOAD-002 | 1,000 users query lesson | 95% < 200ms |
| LOAD-003 | 100 users request TTS | No failures |
| LOAD-004 | 10,000 users load manifest | CDN handles |
| LOAD-005 | Supabase connection pool | No exhaustion |

### 14.3 Stress Test Scenarios

| ID | Scenario | Expected |
|----|----------|----------|
| STR-001 | 10x normal traffic | Graceful degradation |
| STR-002 | CDN failure | Fallback to origin |
| STR-003 | Supabase outage | Offline mode activates |
| STR-004 | ElevenLabs outage | Text-only mode |

---

## 15. REGRESSION TEST SUITE

### 15.1 Smoke Tests (Run Every Deploy)

| ID | Test | Automated |
|----|------|-----------|
| SMOKE-001 | App loads | ✅ |
| SMOKE-002 | Carousel displays | ✅ |
| SMOKE-003 | Kelly images load | ✅ |
| SMOKE-004 | Lesson loads from DB | ✅ |
| SMOKE-005 | Phase navigation works | ✅ |
| SMOKE-006 | Settings accessible | ✅ |
| SMOKE-007 | State persists | ✅ |

### 15.2 Full Regression (Run Before Release)

All tests in sections 2-14.

### 15.3 Automated Test Framework

```javascript
// Example Playwright test
test('carousel navigation', async ({ page }) => {
  await page.goto('/learn.html');
  
  // Initial Kelly
  const initialKelly = await page.locator('.kelly-card.center .name').textContent();
  expect(initialKelly).toBe('The Scientist');
  
  // Swipe right
  await page.locator('#carousel-next').click();
  await page.waitForTimeout(500);
  
  // New Kelly
  const newKelly = await page.locator('.kelly-card.center .name').textContent();
  expect(newKelly).toBe('The Explorer');
});
```

---

## 16. SIGN-OFF CHECKLIST

### 16.1 Pre-Launch Approval

| Category | Owner | Sign-Off |
|----------|-------|----------|
| Core Functionality | Dev | ☐ |
| Mobile Experience | QA | ☐ |
| Performance | Dev | ☐ |
| Accessibility | QA | ☐ |
| Security | Dev | ☐ |
| Content | Content | ☐ |
| Legal/COPPA | Legal | ☐ |
| App Store Compliance | Dev | ☐ |

### 16.2 Launch Readiness

| Item | Status |
|------|--------|
| All P0 tests passing | ☐ |
| All P1 tests passing | ☐ |
| No critical bugs open | ☐ |
| Performance benchmarks met | ☐ |
| Security audit complete | ☐ |
| COPPA compliance verified | ☐ |
| App Store approved (iOS) | ☐ |
| Play Store approved (Android) | ☐ |
| DNS configured | ☐ |
| SSL certificates valid | ☐ |
| Monitoring enabled | ☐ |
| Rollback plan documented | ☐ |

### 16.3 Post-Launch Monitoring

| Metric | Alert Threshold |
|--------|-----------------|
| Error rate | > 1% |
| LCP | > 3s (p95) |
| API latency | > 500ms (p95) |
| Crash rate | > 0.1% |
| Bounce rate | > 70% |

---

## APPENDIX A: TEST DATA

### Sample Users

```json
{
  "new_user": {
    "kellyId": "scientist",
    "age": 30,
    "currentDay": 1,
    "completedLessons": []
  },
  "week_one_user": {
    "kellyId": "explorer",
    "age": 25,
    "currentDay": 7,
    "completedLessons": [1, 2, 3, 4, 5, 6],
    "streak": 6
  },
  "power_user": {
    "kellyId": "strategist",
    "age": 42,
    "currentDay": 100,
    "completedLessons": [/* 1-99 */],
    "streak": 30
  },
  "child_user": {
    "kellyId": "storyteller",
    "age": 8,
    "currentDay": 3,
    "completedLessons": [1, 2]
  },
  "elder_user": {
    "kellyId": "mystic",
    "age": 78,
    "currentDay": 50,
    "completedLessons": [/* 1-49 */]
  }
}
```

### Sample Lesson Response

```json
{
  "id": "uuid",
  "day_number": 1,
  "topic": "Starting Fresh",
  "marketing_headline": "Every journey begins with a single step",
  "phases": [
    {
      "name": "Hook",
      "script": "Welcome to your first day of learning...",
      "videoUrl": null,
      "audioUrl": "https://..."
    }
  ]
}
```

---

## APPENDIX B: BUG SEVERITY DEFINITIONS

| Severity | Definition | Response |
|----------|------------|----------|
| P0 - Critical | App crashes, data loss, security issue | Fix immediately, hotfix |
| P1 - High | Major feature broken, no workaround | Fix before launch |
| P2 - Medium | Feature broken, workaround exists | Fix in v1.1 |
| P3 - Low | Minor issue, cosmetic | Backlog |

---

## APPENDIX C: CONTACT MATRIX

| Role | Contact | Escalation |
|------|---------|------------|
| Product Owner | Nicolette | CEO |
| Lead Developer | Cursor/Claude | Nicolette |
| QA | Manual | Nicolette |
| DevOps | Vercel | Vercel Support |
| Database | Supabase | Supabase Support |
| Voice/Audio | ElevenLabs | ElevenLabs Support |

---

*Generated for Curious Kelly Global Launch*  
*December 2024*
