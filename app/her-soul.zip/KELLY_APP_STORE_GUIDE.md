# CURIOUS KELLY — APP STORE SUBMISSION GUIDE
## iOS App Store & Google Play Store Requirements

---

## PART 1: iOS APP STORE (Apple)

### 1.1 Required Assets

| Asset | Specification | Status |
|-------|---------------|--------|
| App Icon | 1024×1024 PNG, no alpha | ☐ |
| iPhone Screenshots (6.7") | 1290×2796 PNG | ☐ |
| iPhone Screenshots (6.5") | 1284×2778 PNG | ☐ |
| iPhone Screenshots (5.5") | 1242×2208 PNG | ☐ |
| iPad Screenshots (12.9") | 2048×2732 PNG | ☐ |
| App Preview Video (optional) | 1920×1080 or device res | ☐ |

### 1.2 App Store Connect Metadata

```
App Name: Curious Kelly
Subtitle: Daily Learning for Everyone (30 chars max)
Category: Education
Secondary Category: Lifestyle

Keywords (100 chars max):
learning,education,daily,lessons,kids,adults,curiosity,knowledge,wisdom,habit

Description (4000 chars max):
[See below]

What's New (4000 chars max):
Initial release

Support URL: https://curiouskelly.com/support
Marketing URL: https://curiouskelly.com
Privacy Policy URL: https://curiouskelly.com/privacy
```

### 1.3 App Description Template

```
Meet Kelly — your personal learning companion who delivers one beautiful lesson every day, 365 days a year.

🎯 DAILY MICRO-LESSONS
Each day, spend just 5 minutes learning something new. Kelly breaks down fascinating topics into 5 easy phases: Hook, Facts, and Wisdom.

👩‍🔬 12 UNIQUE KELLYS
Choose the teaching style that matches your personality. From The Scientist (data-driven) to The Storyteller (narrative magic), find your perfect guide.

👶👴 AGES 2 TO 102
Kelly adapts her teaching style and appearance to match your learning age. Never too young, never too old to be curious.

🔥 BUILD YOUR STREAK
Track your progress through 365 lessons. Earn achievements. Build a habit that lasts a lifetime.

✨ FEATURES
• 365 unique daily lessons
• 12 teaching personas
• Age-adaptive content
• Offline mode
• Progress tracking
• Beautiful animations
• Family-friendly (COPPA compliant)

Start your curiosity journey today. One lesson at a time.

Made with 💜 for curious minds everywhere.
```

### 1.4 Age Rating Questionnaire

| Question | Answer |
|----------|--------|
| Cartoon or Fantasy Violence | None |
| Realistic Violence | None |
| Sexual Content | None |
| Profanity | None |
| Drug Use | None |
| Mature/Suggestive Themes | None |
| Gambling | None |
| Horror/Fear Themes | None |
| Medical Information | Infrequent/Mild (educational) |
| Unrestricted Web Access | No |

**Result: Rated 4+ (Everyone)**

### 1.5 App Privacy

| Data Type | Collected | Linked to User | Used for Tracking |
|-----------|-----------|----------------|-------------------|
| Name | No | - | - |
| Email | Yes (optional) | Yes | No |
| User ID | Yes | Yes | No |
| Device ID | No | - | - |
| Purchase History | Yes | Yes | No |
| Usage Data | Yes | No | No |
| Crash Data | Yes | No | No |

### 1.6 Review Guidelines Compliance

| Guideline | Status | Notes |
|-----------|--------|-------|
| 1.1 App Completeness | ☐ | All features work |
| 1.2 Beta/Demo | ☐ | Not a beta |
| 2.1 App Store Review | ☐ | Will pass review |
| 2.3 Accurate Metadata | ☐ | Description matches app |
| 3.1 Payments | ☐ | Uses Apple IAP |
| 4.1 Copycats | ☐ | Original content |
| 4.2 Minimum Functionality | ☐ | Substantial app |
| 5.1 Privacy | ☐ | Privacy policy exists |
| 5.1.1 Data Collection | ☐ | Disclosed in App Privacy |

### 1.7 Certificates & Profiles

```
Apple Developer Account: [Your account]
Team ID: [Your team ID]
Bundle ID: com.curiouskelly.app

Certificates needed:
☐ iOS Distribution Certificate
☐ Push Notification Certificate (Production)
☐ App Store Provisioning Profile

Capabilities:
☐ Push Notifications
☐ Associated Domains (for universal links)
☐ In-App Purchase
```

---

## PART 2: GOOGLE PLAY STORE (Android)

### 2.1 Required Assets

| Asset | Specification | Status |
|-------|---------------|--------|
| App Icon | 512×512 PNG, 32-bit | ☐ |
| Feature Graphic | 1024×500 PNG/JPG | ☐ |
| Phone Screenshots | Min 320px, max 3840px | ☐ |
| Tablet Screenshots (7") | 1024×600 or higher | ☐ |
| Tablet Screenshots (10") | 1280×800 or higher | ☐ |
| Promo Video (YouTube) | Optional | ☐ |

### 2.2 Play Console Metadata

```
App Name: Curious Kelly
Short Description (80 chars):
Daily learning companion for ages 2-102. One beautiful lesson every day.

Full Description (4000 chars):
[Same as iOS]

Application Type: Application
Category: Education
Tags: Learning, Knowledge, Daily, Curiosity, Kids

Content Rating: Everyone
```

### 2.3 Content Rating Questionnaire

| Question | Answer |
|----------|--------|
| Violence | No |
| Sexual Content | No |
| Language | No |
| Controlled Substances | No |
| ESRB Privacy Certification | No (not required) |
| Advertisements | No ads |
| In-app purchases | Yes (subscriptions) |

**Result: Rated E (Everyone)**

### 2.4 Data Safety

| Data Type | Collected | Shared | Required |
|-----------|-----------|--------|----------|
| Email | Optional | No | No |
| User IDs | Yes | No | No |
| App interactions | Yes | No | No |
| Crash logs | Yes | No | No |
| App performance | Yes | No | No |

### 2.5 Target Audience

```
☑ Children under 13
☑ Older users

Appeals to children: Yes
Designed for children: Yes (also adults)
Family Policy compliance: Required
Teacher Approved: Consider applying
```

### 2.6 Play Store Policies Compliance

| Policy | Status | Notes |
|--------|--------|-------|
| Deceptive Behavior | ☐ | No deception |
| Monetization | ☐ | Clear pricing |
| Ads | ☐ | No ads |
| Privacy | ☐ | Policy posted |
| Families | ☐ | COPPA compliant |
| Sensitive Events | ☐ | No issues |
| User Data | ☐ | Minimal collection |

### 2.7 Signing & Release

```
Google Play Console: [Your account]
Package Name: com.curiouskelly.app

Signing:
☐ App Signing by Google Play (recommended)
☐ Upload key generated
☐ Keystore backed up securely

Release Track:
☐ Internal testing (first)
☐ Closed testing (beta users)
☐ Open testing (optional)
☐ Production (launch)
```

---

## PART 3: FAMILY POLICIES (COPPA)

### 3.1 Requirements for Apps Targeting Children

| Requirement | Implementation |
|-------------|----------------|
| Parental gate for settings | ☐ |
| No behavioral advertising | ☐ (no ads at all) |
| No personal data without consent | ☐ |
| Age-gated registration | ☐ |
| Privacy policy for children | ☐ |
| Data deletion capability | ☐ |

### 3.2 Parental Gate Implementation

```javascript
// Simple math gate for settings access
function showParentalGate(onSuccess) {
  const a = Math.floor(Math.random() * 10) + 5;
  const b = Math.floor(Math.random() * 10) + 5;
  
  const answer = prompt(`Parental verification: What is ${a} + ${b}?`);
  
  if (parseInt(answer) === a + b) {
    onSuccess();
  } else {
    showToast('Incorrect. Please ask a parent.');
  }
}
```

### 3.3 Age Verification Flow

```
If user selects age < 13:
1. Show "Ask a parent to help you set up"
2. Require parental gate for account creation
3. Limit data collection to essential only
4. No external links without parental gate
5. No social features
```

---

## PART 4: IN-APP PURCHASES

### 4.1 iOS Subscription Products

| Product ID | Type | Price | Duration |
|------------|------|-------|----------|
| curious_kelly_monthly | Auto-renewable | $9.99 | 1 month |
| curious_kelly_yearly | Auto-renewable | $79.99 | 1 year |
| curious_kelly_lifetime | Non-consumable | $199.99 | Forever |

### 4.2 Android Subscription Products

| Product ID | Type | Price | Duration |
|------------|------|-------|----------|
| curious_kelly_monthly | Subscription | $9.99 | 1 month |
| curious_kelly_yearly | Subscription | $79.99 | 1 year |
| curious_kelly_lifetime | One-time | $199.99 | Forever |

### 4.3 Subscription Benefits

```
FREE:
- Day 1 lesson
- Character select
- Settings

PREMIUM:
- All 365 lessons
- All 12 Kelly personas
- Offline mode
- Family accounts (up to 5)
- Future language support
- Priority support
```

---

## PART 5: PRE-SUBMISSION CHECKLIST

### iOS

```
☐ App tested on real device (not just simulator)
☐ All features work without crashing
☐ Push notifications work
☐ In-app purchases work
☐ Privacy policy URL accessible
☐ Support URL accessible
☐ No placeholder content
☐ No private APIs used
☐ App icon is unique
☐ Screenshots are accurate
☐ Metadata is accurate
☐ Age rating is correct
☐ App Privacy completed
☐ Export compliance answered
```

### Android

```
☐ App tested on real device
☐ All features work
☐ Push notifications work
☐ In-app purchases work
☐ Privacy policy URL accessible
☐ No crashes in pre-launch report
☐ 64-bit support included
☐ Target API level current
☐ App icon is unique
☐ Screenshots are accurate
☐ Content rating completed
☐ Data safety completed
☐ Ads declaration correct
☐ Family policy compliance (if applicable)
```

---

## PART 6: SUBMISSION TIMELINE

### Recommended Schedule

| Day | Action |
|-----|--------|
| D-7 | Finalize app build |
| D-6 | Submit to Apple (review takes 1-3 days) |
| D-5 | Submit to Google (review takes 1-3 days) |
| D-4 | Address any rejections |
| D-3 | Re-submit if needed |
| D-2 | Apps approved (hopefully) |
| D-1 | Set release for D-Day |
| D-0 | Launch! 🚀 |

### If Rejected

**Common iOS rejection reasons:**
- Crashes/bugs (fix and resubmit)
- Incomplete metadata (fix and resubmit)
- Guideline violations (fix and resubmit)
- Not enough features (add value)

**Common Android rejection reasons:**
- Policy violations (fix and resubmit)
- Impersonation (clarify branding)
- Privacy issues (update policy)
- Crashes (fix bugs)

---

## PART 7: POST-LAUNCH

### Monitoring

```
☐ App Store Connect analytics
☐ Google Play Console analytics
☐ Crash reporting (Firebase/Sentry)
☐ Review monitoring
☐ Rating monitoring
```

### Responding to Reviews

```
Positive (4-5 stars): Thank briefly
Negative (1-3 stars): Apologize, offer help, fix if valid
```

### Update Cadence

```
Week 1: Hotfixes if needed
Week 2-4: v1.1 with improvements
Monthly: New content, bug fixes
```

---

*App Store Submission Guide for Curious Kelly*  
*December 2024*
