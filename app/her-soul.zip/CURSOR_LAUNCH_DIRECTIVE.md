# CURIOUS KELLY - FINAL LAUNCH DIRECTIVE
## Last Time the Plane is on the Ground

**Date:** December 11, 2025  
**Launch:** December 17, 2025  
**Status:** SHIP IT

---

## PART 1: DEFINITIVE ANSWERS - SINGLE SOURCE OF TRUTH

### 1. Deployment (Single Source of Truth)

**Q1: What is production hosting for curiouskelly.com?**
→ **C) Vercel**

**Q2: Permission to disconnect/delete duplicate Cloudflare Pages projects?**
→ **YES** - Delete all duplicate projects. Only ONE build per push. Clean it up forever.

**Q3: Preview builds or production-only?**
→ **B) Production-only** - We are launching. No more previews. Every push goes live.

### 2. What "The App" Is at Launch

**Q4: Web-first or mobile-required?**
→ **B) Mobile-required** - Both web AND mobile ship now. TikTok-style player works on both.

**Q5: Unity/3D mode shipping this month?**
→ **A) Not shipping (park it)** - 2D video player is primary. Unity is Phase 2 post-launch.

### 3. Kelly Variants

**Q6: Are the 12 archetypes fixed?**
→ **A) Fixed** - The 12 persona/archetype mappings are canonical:

| Archetype | Persona ID | Head File | Notes |
|-----------|------------|-----------|-------|
| The Scientist | architect | kelly_architect_head.png | |
| The Survivor | explorer | kelly_explorer_head.png | |
| The Mystic | mystic | kelly_mystic_head.png | |
| The Sage | diplomat | kelly_diplomat_head.png | |
| The Jester | clown | kelly_clown_head.png | |
| The Ruler | judge | kelly_judge_head.png | |
| The Creator | macgyver | kelly_macgyver_head.png | |
| The Caregiver | provider | kelly_provider_head.png | |
| The Hero | perfectionist | kelly_perfectionist_head.png | |
| The Rebel | ghost | kelly_ghost_head.png | *(legacy name)* |
| The Lover | empath | kelly_empath_head.png | |
| The Explorer | diva | kelly_diva_head.png | *(legacy name)* |

**Note:** "ghost" and "diva" are legacy persona names but the files are still valid.

**Q7: "Kelly changes her age" means:**
→ **A) 5 age buckets (matching generated heads):**
- **Kid** (2-12) - 12 heads in `age/kid/`
- **Teen** (13-17) - 12 heads in `age/teen/`
- **Adult** (18-49, default) - 12 heads in `age/adult/`
- **Elder** (50-75) - 12 heads in `age/elder/`
- **Super-Elder** (76-102) - 12 heads in `age/super_elder/`

Total: **60 Kelly talking photos** (5 ages × 12 archetypes)

**Q8: Web player visuals standardized on:**
→ **D) Hybrid** - HeyGen lip-synced video PRIMARY, 2D static images as fallback.

### 4. Permission to Cut

**Q9: Delete/move legacy folders after snapshot?**
→ **A) Delete/move allowed** - Snapshot first, then clean house. No more cruft.

---

## PART 2: VIDEO COMPILATION DIRECTIVE

### MISSION: Compile Day 1 Kelly Videos

We have lesson atoms in Supabase. We have 36 Kelly talking photos in HeyGen. Now generate lip-synced videos for each lesson variant.

### Architecture Overview (ACTUAL PIPELINE)

```
SUPABASE (lesson_atoms)
    ↓
HEYGEN TALKING PHOTOS (36 Kelly heads: 12 archetypes × 3 ages)
    ↓
HEYGEN VIDEO GENERATION (lipsync + voice in one API call)
    ↓
SUPABASE STORAGE (video files)
    ↓
VERCEL (serve to player)
```

### What Already Exists

**Kelly Head Assets (60 total):**
```
generated-images/kelly-archetypes-head-only/
├── age/
│   ├── kid/         (12 heads - ages 2-12)
│   ├── teen/        (12 heads - ages 13-17)
│   ├── adult/       (12 heads - ages 18-49)
│   ├── elder/       (12 heads - ages 50-75)
│   └── super_elder/ (12 heads - ages 76-102)
├── archetype_head_urls.json
└── manifest.age-variants.json
```

**HeyGen Talking Photo IDs:**
```
generated-images/kelly-archetypes-head-only/age/kid/heygen_talking_photo_ids.json
generated-images/kelly-archetypes-head-only/age/teen/heygen_talking_photo_ids.json
generated-images/kelly-archetypes-head-only/age/adult/heygen_talking_photo_ids.json
generated-images/kelly-archetypes-head-only/age/elder/heygen_talking_photo_ids.json
generated-images/kelly-archetypes-head-only/age/super_elder/heygen_talking_photo_ids.json
```

**LoRA Model:**
- Local: `models/lora/Curious_Kelly.safetensors`
- Remote: `https://huggingface.co/CuriousKellycom/curious-kelly-lora/resolve/main/curious_kelly.safetensors`

**Existing Scripts:**
- `scripts/generate-12-kellys-head-accessories.ts` - Generate Kelly head images
- `scripts/heygen-match-talking-photos.py` - Match heads to HeyGen talking photo IDs
- `scripts/heygen-kelly-pipeline-v2.ts` - Video generation (supports --language, --age)
- `public/js/kelly-personas.js` - `getPersonaImage(personaId, variant, ageVariant)`
- `public/assets/kelly/kelly-personas-manifest.json` - Persona metadata with age variants

### Database Schema Decision (RESOLVED)

**Using existing table: `kelly_video_assets`**

Your schema already has the right structure:
```sql
-- kelly_video_assets (ALREADY EXISTS)
- id uuid
- day_number integer (1-365)
- phase text ('hook', 'q1', 'q2', 'q3', 'wisdom')
- template text (archetype/persona name)
- asset_type text ('image', 'animation', 'audio', 'video', 'video_4k')
- age_bucket text ('kid', 'teen', 'adult', 'elder', 'super_elder')
- language text (default 'en')
- storage_path text
- public_url text
- status text ('generating', 'generated', 'validated', 'published')
- duration_seconds numeric
- generation_cost_usd numeric
```

**No new table needed.** We'll use `kelly_video_assets` for all generated videos.

---

### CURSOR TASK 1: Verify Asset Folder Structure

```bash
# Check what age folders exist
ls -la generated-images/kelly-archetypes-head-only/age/

# Expected output (5 folders):
# kid/         (12 heads)
# teen/        (12 heads)  
# adult/       (12 heads)
# elder/       (12 heads)
# super_elder/ (12 heads)

# Count total heads
find generated-images/kelly-archetypes-head-only/age -name "*.png" | wc -l
# Should be 60 (5 ages × 12 archetypes)
```

### CURSOR TASK 2: Audit Existing Content

```typescript
// scripts/audit-day1-for-heygen.ts

import { createClient } from '@supabase/supabase-js';
import * as fs from 'fs';
import * as path from 'path';

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_KEY!
);

async function auditDay1() {
  console.log('=== CURIOUS KELLY - DAY 1 HEYGEN AUDIT ===\n');
  
  // 1. Check lesson atoms
  const { data: atoms, count } = await supabase
    .from('lesson_atoms')
    .select('*', { count: 'exact' })
    .eq('core_lesson_id', /* day 1 lesson id */);
  
  console.log(`[Supabase] Day 1 atoms: ${count}`);
  
  // Group by archetype
  const byArchetype: Record<string, number> = {};
  atoms?.forEach(a => {
    byArchetype[a.archetype] = (byArchetype[a.archetype] || 0) + 1;
  });
  console.log('\nAtoms by archetype:');
  Object.entries(byArchetype).forEach(([k, v]) => console.log(`  ${k}: ${v}`));
  
  // 2. Check HeyGen talking photo IDs for all 5 age buckets
  const ageVariants = ['kid', 'teen', 'adult', 'elder', 'super_elder'];
  console.log('\n[HeyGen] Talking Photo IDs:');
  
  for (const age of ageVariants) {
    const idMapPath = path.join(
      'generated-images/kelly-archetypes-head-only/age',
      age,
      'heygen_talking_photo_ids.json'
    );
    
    if (fs.existsSync(idMapPath)) {
      const idMap = JSON.parse(fs.readFileSync(idMapPath, 'utf-8'));
      console.log(`  ${age}: ${Object.keys(idMap).length} talking photos ✓`);
    } else {
      console.log(`  ${age}: ❌ ID map not found at ${idMapPath}`);
    }
  }
  
  // 3. Check existing kelly_video_assets for day 1
  const { data: existingVideos, count: videoCount } = await supabase
    .from('kelly_video_assets')
    .select('*', { count: 'exact' })
    .eq('day_number', 1);
  
  console.log(`\n[kelly_video_assets] Day 1 existing: ${videoCount || 0}`);
  
  if (existingVideos?.length) {
    const byPhase: Record<string, number> = {};
    existingVideos.forEach(v => {
      byPhase[v.phase] = (byPhase[v.phase] || 0) + 1;
    });
    console.log('By phase:', byPhase);
  }
  
  // 4. Sample content for HeyGen script generation
  console.log('\n=== SAMPLE SCRIPTS FOR HEYGEN ===');
  const phases = ['hook', 'q1', 'q2', 'q3', 'wisdom'];
  for (const phase of phases) {
    const atom = atoms?.find(a => a.phase === phase);
    if (atom) {
      const content = typeof atom.content === 'string' 
        ? atom.content 
        : JSON.stringify(atom.content);
      console.log(`\n${phase} (${atom.archetype}):`);
      console.log(`"${content.substring(0, 200)}..."`);
    }
  }
  
  return { atoms, count, byArchetype };
}

auditDay1().then(() => console.log('\n✅ Audit complete'));
```

### CURSOR TASK 3: HeyGen Video Generation

```typescript
// scripts/generate-day-videos-heygen.ts

import { createClient } from '@supabase/supabase-js';
import * as fs from 'fs';
import * as path from 'path';

const HEYGEN_API_KEY = process.env.HEYGEN_API_KEY!;
const HEYGEN_API_URL = 'https://api.heygen.com/v2';

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_KEY!
);

// Map archetypes to Kelly personas
const ARCHETYPE_TO_PERSONA: Record<string, string> = {
  'The Scientist': 'architect',
  'The Survivor': 'explorer',
  'The Mystic': 'mystic',
  'The Sage': 'diplomat',
  'The Jester': 'clown',
  'The Ruler': 'judge',
  'The Creator': 'macgyver',
  'The Caregiver': 'provider',
  'The Hero': 'perfectionist',
  'The Rebel': 'ghost',
  'The Lover': 'empath',
  'The Explorer': 'explorer'
};

// HeyGen voice IDs by language
const VOICE_IDS: Record<string, string> = {
  'en': 'YOUR_ENGLISH_VOICE_ID',   // Kelly's English voice
  'es': 'YOUR_SPANISH_VOICE_ID',   // Kelly's Spanish voice
  'zh': 'YOUR_CHINESE_VOICE_ID'    // Kelly's Chinese voice
};

interface GenerationOptions {
  dayNumber: number;
  ageVariant: 'kid' | 'teen' | 'adult' | 'elder' | 'super_elder';
  language: string;
  archetype?: string;  // If specified, only generate for this archetype
}

// Map user age to age bucket
function getAgeBucket(age: number): 'kid' | 'teen' | 'adult' | 'elder' | 'super_elder' {
  if (age <= 12) return 'kid';
  if (age <= 17) return 'teen';
  if (age <= 49) return 'adult';
  if (age <= 75) return 'elder';
  return 'super_elder';
}

async function getTalkingPhotoId(persona: string, age: string): Promise<string | null> {
  const idMapPath = path.join(
    'generated-images/kelly-archetypes-head-only/age',
    age,
    'heygen_talking_photo_ids.json'
  );
  
  if (!fs.existsSync(idMapPath)) {
    console.error(`❌ ID map not found: ${idMapPath}`);
    return null;
  }
  
  const idMap = JSON.parse(fs.readFileSync(idMapPath, 'utf-8'));
  return idMap[persona] || idMap[`kelly_${persona}_head`] || null;
}

async function generateHeyGenVideo(
  talkingPhotoId: string,
  script: string,
  voiceId: string
): Promise<{ videoId: string; status: string }> {
  
  const response = await fetch(`${HEYGEN_API_URL}/video/generate`, {
    method: 'POST',
    headers: {
      'X-Api-Key': HEYGEN_API_KEY,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      video_inputs: [{
        character: {
          type: 'talking_photo',
          talking_photo_id: talkingPhotoId
        },
        voice: {
          type: 'text',
          input_text: script,
          voice_id: voiceId
        }
      }],
      dimension: {
        width: 1080,
        height: 1920  // 9:16 for mobile-first TikTok style
      }
    })
  });
  
  const data = await response.json();
  
  if (data.error) {
    throw new Error(`HeyGen error: ${data.error.message}`);
  }
  
  return {
    videoId: data.data.video_id,
    status: data.data.status
  };
}

async function checkVideoStatus(videoId: string): Promise<{
  status: string;
  videoUrl?: string;
  duration?: number;
}> {
  const response = await fetch(`${HEYGEN_API_URL}/video_status.get?video_id=${videoId}`, {
    headers: { 'X-Api-Key': HEYGEN_API_KEY }
  });
  
  const data = await response.json();
  
  return {
    status: data.data.status,
    videoUrl: data.data.video_url,
    duration: data.data.duration
  };
}

async function generateDayVideos(options: GenerationOptions) {
  const { dayNumber, ageVariant, language } = options;
  
  console.log(`\n========================================`);
  console.log(`GENERATING: Day ${dayNumber}, Age: ${ageVariant}, Lang: ${language}`);
  console.log(`========================================\n`);
  
  // Get lesson atoms for this day
  let query = supabase
    .from('lesson_atoms')
    .select('*')
    .eq('day_number', dayNumber)
    .eq('language', language);
  
  if (options.archetype) {
    query = query.eq('archetype', options.archetype);
  }
  
  const { data: atoms, error } = await query.order('phase');
  
  if (error || !atoms?.length) {
    console.error(`❌ No atoms found for day ${dayNumber}`);
    return;
  }
  
  console.log(`Found ${atoms.length} atoms to process\n`);
  
  for (const atom of atoms) {
    const persona = ARCHETYPE_TO_PERSONA[atom.archetype] || 'diplomat';
    const talkingPhotoId = await getTalkingPhotoId(persona, ageVariant);
    
    if (!talkingPhotoId) {
      console.error(`❌ No talking photo for ${persona}/${ageVariant}`);
      continue;
    }
    
    const voiceId = VOICE_IDS[language] || VOICE_IDS['en'];
    
    console.log(`[${atom.phase}] ${atom.archetype} → ${persona}`);
    console.log(`    Script: "${atom.content.substring(0, 50)}..."`);
    
    try {
      // Generate video
      const { videoId, status } = await generateHeyGenVideo(
        talkingPhotoId,
        atom.content,
        voiceId
      );
      
      console.log(`    ✓ Video queued: ${videoId} (${status})`);
      
      // Record in kelly_video_assets (existing table)
      await supabase.from('kelly_video_assets').upsert({
        day_number: dayNumber,
        phase: atom.phase,
        template: persona,  // archetype/persona name
        asset_type: 'video',
        age_bucket: ageVariant,
        language: language,
        storage_path: `heygen/${videoId}`,  // Will update with real path after completion
        public_url: '',  // Will update after HeyGen completes
        replicate_prediction_id: videoId,  // Reusing field for HeyGen video ID
        generation_prompt: atom.content,
        status: 'generating'
      }, {
        onConflict: 'day_number,phase,template,age_bucket,language'
      });
      
      // Rate limit: HeyGen allows ~2 concurrent generations
      await new Promise(r => setTimeout(r, 2000));
      
    } catch (err) {
      console.error(`    ❌ Error: ${err}`);
      
      await supabase.from('kelly_video_assets').upsert({
        day_number: dayNumber,
        phase: atom.phase,
        template: persona,
        asset_type: 'video',
        age_bucket: ageVariant,
        language: language,
        storage_path: '',
        public_url: '',
        status: 'archived'  // Using 'archived' to indicate failed
      }, {
        onConflict: 'day_number,phase,template,age_bucket,language'
      });
    }
  }
  
  console.log(`\n✅ Day ${dayNumber} generation queued`);
}

// Run with: npx tsx scripts/generate-day-videos-heygen.ts --day=1 --age=adult --lang=en
const args = process.argv.slice(2);
const day = parseInt(args.find(a => a.startsWith('--day='))?.split('=')[1] || '1');
const age = (args.find(a => a.startsWith('--age='))?.split('=')[1] || 'adult') as 'kid' | 'teen' | 'adult' | 'elder' | 'super_elder';
const lang = args.find(a => a.startsWith('--lang='))?.split('=')[1] || 'en';

generateDayVideos({ dayNumber: day, ageVariant: age, language: lang });
```

### CURSOR TASK 4: Poll & Update Video Status

```typescript
// scripts/poll-heygen-status.ts

import { createClient } from '@supabase/supabase-js';

const HEYGEN_API_KEY = process.env.HEYGEN_API_KEY!;
const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_KEY!
);

async function pollPendingVideos() {
  // Get all videos still generating from kelly_video_assets
  const { data: pending } = await supabase
    .from('kelly_video_assets')
    .select('*')
    .eq('status', 'generating')
    .eq('asset_type', 'video');
  
  if (!pending?.length) {
    console.log('No pending videos');
    return;
  }
  
  console.log(`Checking ${pending.length} pending videos...\n`);
  
  for (const video of pending) {
    const response = await fetch(
      `https://api.heygen.com/v2/video_status.get?video_id=${video.replicate_prediction_id}`,
      { headers: { 'X-Api-Key': HEYGEN_API_KEY } }
    );
    
    const data = await response.json();
    const status = data.data?.status;
    
    console.log(`[${video.day_number}-${video.phase}] ${video.template}: ${status}`);
    
    if (status === 'completed') {
      await supabase
        .from('kelly_video_assets')
        .update({
          status: 'validated',  // Using existing status enum
          public_url: data.data.video_url,
          duration_seconds: data.data.duration,
          updated_at: new Date().toISOString()
        })
        .eq('id', video.id);
      
      console.log(`    ✓ Ready: ${data.data.video_url}`);
      
    } else if (status === 'failed') {
      await supabase
        .from('kelly_video_assets')
        .update({
          status: 'archived',  // Mark as failed/archived
          updated_at: new Date().toISOString()
        })
        .eq('id', video.id);
      
      console.log(`    ❌ Failed`);
    }
    
    await new Promise(r => setTimeout(r, 500));
  }
}

// Run continuously or as cron
pollPendingVideos();
```

### CURSOR TASK 5: Frontend Video Loader

```javascript
// public/js/kelly-video-loader.js

const KellyVideoLoader = {
  supabaseUrl: 'https://tvjalxxsyryjphkforjv.supabase.co',
  supabaseKey: null, // Set from config
  
  // Age bucket mapping for user age → asset age_bucket
  getAgeBucket(age) {
    if (age <= 12) return 'kid';
    if (age <= 17) return 'teen';
    if (age <= 49) return 'adult';
    if (age <= 75) return 'elder';
    return 'super_elder';
  },
  
  async init(anonKey) {
    this.supabaseKey = anonKey;
  },
  
  async getVideo(dayNumber, phase, options = {}) {
    const {
      ageBucket = 'adult',  // 'kid', 'teen', 'adult', 'elder', 'super_elder'
      language = 'en',
      template = null  // archetype/persona name
    } = options;
    
    let query = `day_number=eq.${dayNumber}&phase=eq.${phase}&age_bucket=eq.${ageBucket}&language=eq.${language}&status=in.(validated,published)&asset_type=eq.video`;
    
    if (template) {
      query += `&template=eq.${template}`;
    }
    
    const response = await fetch(
      `${this.supabaseUrl}/rest/v1/kelly_video_assets?${query}&limit=1`,
      {
        headers: {
          'apikey': this.supabaseKey,
          'Authorization': `Bearer ${this.supabaseKey}`
        }
      }
    );
    
    const [video] = await response.json();
    return video || null;
  },
  
  async getLessonVideos(dayNumber, options = {}) {
    const { ageBucket = 'adult', language = 'en' } = options;
    
    const response = await fetch(
      `${this.supabaseUrl}/rest/v1/kelly_video_assets?day_number=eq.${dayNumber}&age_bucket=eq.${ageBucket}&language=eq.${language}&status=in.(validated,published)&asset_type=eq.video&order=phase.asc`,
      {
        headers: {
          'apikey': this.supabaseKey,
          'Authorization': `Bearer ${this.supabaseKey}`
        }
      }
    );
    
    return response.json();
  },
  
  async preloadLesson(dayNumber, options = {}) {
    const videos = await this.getLessonVideos(dayNumber, options);
    
    // Preload video URLs
    for (const video of videos) {
      if (video.video_url) {
        const link = document.createElement('link');
        link.rel = 'preload';
        link.as = 'video';
        link.href = video.video_url;
        document.head.appendChild(link);
      }
    }
    
    return videos;
  }
};

// Export for use in player
window.KellyVideoLoader = KellyVideoLoader;
```

### CURSOR TASK 6: Master Generation Script

```bash
#!/bin/bash
# scripts/compile-day-heygen.sh

DAY=${1:-1}
AGES=${2:-"adult"}
LANGS=${3:-"en"}

echo "=========================================="
echo "HEYGEN VIDEO COMPILATION - DAY $DAY"
echo "Ages: $AGES | Languages: $LANGS"
echo "=========================================="

# Parse comma-separated values
IFS=',' read -ra AGE_ARRAY <<< "$AGES"
IFS=',' read -ra LANG_ARRAY <<< "$LANGS"

echo "\n[1/4] Auditing content..."
npx tsx scripts/audit-day1-for-heygen.ts

echo "\n[2/4] Generating videos..."
for age in "${AGE_ARRAY[@]}"; do
  for lang in "${LANG_ARRAY[@]}"; do
    echo "\n>>> Generating: age=$age, lang=$lang"
    npx tsx scripts/generate-day-videos-heygen.ts --day=$DAY --age=$age --lang=$lang
  done
done

echo "\n[3/4] Waiting for HeyGen processing (checking every 30s)..."
for i in {1..20}; do
  sleep 30
  echo "Poll attempt $i..."
  npx tsx scripts/poll-heygen-status.ts
  
  # Check if all done (using kelly_video_assets)
  PENDING=$(npx tsx -e "
    const { createClient } = require('@supabase/supabase-js');
    const sb = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_KEY);
    sb.from('kelly_video_assets').select('id', { count: 'exact' })
      .eq('status', 'generating').eq('day_number', $DAY).eq('asset_type', 'video')
      .then(r => console.log(r.count || 0));
  ")
  
  if [ "$PENDING" = "0" ]; then
    echo "All videos processed!"
    break
  fi
done

echo "\n[4/4] Summary..."
npx tsx -e "
  const { createClient } = require('@supabase/supabase-js');
  const sb = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_KEY);
  sb.from('kelly_video_assets')
    .select('status', { count: 'exact' })
    .eq('day_number', $DAY)
    .eq('asset_type', 'video')
    .then(async () => {
      const ready = await sb.from('kelly_video_assets').select('*', {count:'exact'}).eq('day_number',$DAY).eq('asset_type','video').in('status',['validated','published']);
      const failed = await sb.from('kelly_video_assets').select('*', {count:'exact'}).eq('day_number',$DAY).eq('asset_type','video').eq('status','archived');
      console.log('Ready:', ready.count);
      console.log('Failed:', failed.count);
    });
"

echo "\n=========================================="
echo "✅ DAY $DAY COMPILATION COMPLETE"
echo "=========================================="
```

### Usage Examples

```bash
# Generate Day 1, adult age, English only
./scripts/compile-day-heygen.sh 1 adult en

# Generate Day 1, all 5 ages, English and Spanish
./scripts/compile-day-heygen.sh 1 kid,teen,adult,elder,super_elder en,es

# Generate just kid and teen for testing younger audiences
./scripts/compile-day-heygen.sh 1 kid,teen en

# Generate elder ages for senior testing
./scripts/compile-day-heygen.sh 1 elder,super_elder en
```

---

## PART 3: CLEANUP DIRECTIVE

### Delete These Now (After Snapshot)

```bash
# Snapshot first
mkdir -p ~/curiouskelly-backup-$(date +%Y%m%d)
cp -r . ~/curiouskelly-backup-$(date +%Y%m%d)/

# Then delete legacy
rm -rf unity-builds/
rm -rf old-players/
rm -rf archived/
rm -rf temp-*/
rm -rf .next/
rm -rf node_modules/ && npm install

# Remove duplicate Vercel projects via dashboard:
# - Delete curiouskelly-1mv5
# - Keep only curiouskelly

# Remove duplicate Cloudflare Pages projects via dashboard:
# - Keep only ONE that builds per push
```

### Environment Variables Required (Vercel Dashboard)

```
# Supabase
SUPABASE_URL=https://tvjalxxsyryjphkforjv.supabase.co
SUPABASE_ANON_KEY=<your_key>
SUPABASE_SERVICE_KEY=<your_service_key>  # For server-side scripts

# HeyGen (Video Generation)
HEYGEN_API_KEY=<your_key>

# ElevenLabs (Voice - if using standalone audio)
ELEVENLABS_API_KEY=<your_key>

# Cloudflare R2 (Asset Storage)
CLOUDFLARE_R2_ACCOUNT_ID=47ebb2a1adc311cb106acc89720e352c
CLOUDFLARE_R2_ACCESS_KEY_ID=<your_key>
CLOUDFLARE_R2_SECRET_ACCESS_KEY=<your_key>
CLOUDFLARE_R2_BUCKET=my-quantum-bucket
CLOUDFLARE_R2_PUBLIC_URL=https://pub-b5e7a8ca0071406fa65faebf47a39bd8.r2.dev

# Replicate (LoRA Image Generation)
REPLICATE_API_TOKEN=<your_key>
```

---

## PART 4: LAUNCH CHECKLIST

### Before December 17

- [ ] Kelly head images generated (60 total: 12 archetypes × 5 ages)
- [ ] HeyGen talking photo IDs mapped for all 5 age buckets
- [ ] Day 1 HeyGen videos generated (all 5 ages: kid/teen/adult/elder/super_elder, English)
- [ ] Days 2-7 HeyGen videos queued
- [ ] TikTok player loading videos from `kelly_video_assets`
- [ ] `KellyVideoLoader.js` integrated into player (with 5-bucket age mapping)
- [ ] Mobile responsive verified
- [ ] Web responsive verified
- [ ] 2D fallback working when video not ready
- [ ] All duplicate Vercel/Cloudflare projects deleted
- [ ] Production-only builds enabled
- [ ] Environment variables set (HEYGEN_API_KEY, SUPABASE_*, etc.)
- [ ] COPPA compliance verified
- [ ] Stripe payments working

### Launch Day

- [ ] curiouskelly.com loads
- [ ] Day 1 lesson plays with Kelly video
- [ ] Kelly speaks (HeyGen lip-sync)
- [ ] Age slider changes Kelly's appearance (kid → teen → adult → elder → super_elder)
- [ ] Language selector works
- [ ] Users can sign up
- [ ] Users can pay
- [ ] App works on iOS Safari
- [ ] App works on Android Chrome
- [ ] App works on desktop browsers

---

## EXECUTE NOW

**Step 1:** Verify 60 heads exist:
```bash
ls generated-images/kelly-archetypes-head-only/age/
# Should show: kid/ teen/ adult/ elder/ super_elder/

find generated-images/kelly-archetypes-head-only/age -name "*.png" | wc -l
# Should be 60
```

**Step 2:** Run audit: `npx tsx scripts/audit-day1-for-heygen.ts`

**Step 3:** Generate Day 1 videos: `./scripts/compile-day-heygen.sh 1 adult en`

**Step 4:** Poll until ready: `npx tsx scripts/poll-heygen-status.ts`

**Step 5:** Test in player: Load lesson, verify Kelly video plays

This is the last time the plane is on the ground. Ship it.
