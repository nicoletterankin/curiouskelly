# KELLY BACKSTORY INTEGRATION EVALUATION
## Verifying the Soul is Wired to the Body

---

## THE FOUR TABLES

Kelly's soul lives in four Supabase tables. This document verifies they're connected to content generation.

| Table | Purpose | Rows |
|-------|---------|------|
| `kelly_backstory` | Genesis stories for each persona | 12 |
| `kelly_age_permissions` | Can/cannot rules per age bucket | 5 |
| `kelly_memory_hooks` | Topic-specific personal connections | 365 |
| `kelly_core_biography` | Unified truth about who Kelly is | 1 |

---

## PART 1: DATABASE INTEGRITY CHECKS

### 1.1 Schema Verification

```sql
-- Verify all tables exist
SELECT table_name 
FROM information_schema.tables 
WHERE table_schema = 'public' 
AND table_name IN (
  'kelly_backstory',
  'kelly_age_permissions', 
  'kelly_memory_hooks',
  'kelly_core_biography'
);
-- Expected: 4 rows
```

### 1.2 Data Completeness

```sql
-- Check kelly_backstory has all 12 personas
SELECT persona_id, 
       CASE WHEN genesis_story IS NOT NULL THEN '✓' ELSE '✗' END as has_genesis,
       CASE WHEN teaching_philosophy IS NOT NULL THEN '✓' ELSE '✗' END as has_philosophy,
       CASE WHEN transformation_trigger IS NOT NULL THEN '✓' ELSE '✗' END as has_trigger
FROM kelly_backstory
ORDER BY persona_id;
-- Expected: 12 rows, all ✓

-- Check kelly_age_permissions has all 5 buckets
SELECT age_bucket,
       CASE WHEN vocabulary_level IS NOT NULL THEN '✓' ELSE '✗' END as has_vocab,
       CASE WHEN permitted_topics IS NOT NULL THEN '✓' ELSE '✗' END as has_permitted,
       CASE WHEN forbidden_topics IS NOT NULL THEN '✓' ELSE '✗' END as has_forbidden
FROM kelly_age_permissions
ORDER BY 
  CASE age_bucket 
    WHEN 'kid' THEN 1 
    WHEN 'teen' THEN 2 
    WHEN 'adult' THEN 3 
    WHEN 'elder' THEN 4 
    WHEN 'super_elder' THEN 5 
  END;
-- Expected: 5 rows, all ✓

-- Check kelly_memory_hooks coverage
SELECT 
  COUNT(*) as total_hooks,
  COUNT(CASE WHEN memory_hook IS NOT NULL THEN 1 END) as with_hook,
  COUNT(CASE WHEN emotional_connection IS NOT NULL THEN 1 END) as with_emotion
FROM kelly_memory_hooks;
-- Expected: total_hooks = 365, all populated

-- Check kelly_core_biography exists
SELECT * FROM kelly_core_biography;
-- Expected: 1 row with full biography
```

### 1.3 Foreign Key Integrity

```sql
-- Verify backstory personas match manifest
SELECT kb.persona_id 
FROM kelly_backstory kb
LEFT JOIN kelly_personas kp ON kb.persona_id = kp.id
WHERE kp.id IS NULL;
-- Expected: 0 rows (no orphaned backstories)

-- Verify memory hooks have valid day numbers
SELECT day_number FROM kelly_memory_hooks
WHERE day_number < 1 OR day_number > 365;
-- Expected: 0 rows
```

---

## PART 2: FUNCTION VERIFICATION

### 2.1 get_kelly_prompt_context() Test

```sql
-- Test the main function
SELECT get_kelly_prompt_context('explorer', 'adult', 47);
```

**Expected Output Structure:**
```json
{
  "persona": {
    "id": "explorer",
    "genesis_story": "At 22, I quit my job and bought a one-way ticket...",
    "teaching_philosophy": "Learning is a journey, not a destination...",
    "transformation_trigger": "When someone feels the pull of the unknown...",
    "stats": {
      "curiosity": 95,
      "energy": 85,
      "warmth": 80,
      "precision": 60
    }
  },
  "age_permissions": {
    "vocabulary_level": "full",
    "permitted_topics": ["work", "parenting", "finances", "relationships", "mortality"],
    "forbidden_topics": [],
    "tone_guidance": "Peer-to-peer, respects expertise, no condescension"
  },
  "memory_hook": {
    "day_number": 47,
    "topic": "[Day 47's topic]",
    "memory_hook": "When I first discovered leaves could feed you...",
    "emotional_connection": "wonder at nature's generosity"
  },
  "core_identity": {
    "name": "Kelly",
    "essence": "A curious soul who became everyone's favorite teacher...",
    "unified_truth": "All 12 personas are facets of one person..."
  }
}
```

### 2.2 Function Edge Cases

| Test | Input | Expected |
|------|-------|----------|
| Valid call | `('scientist', 'adult', 1)` | Full context object |
| Unknown persona | `('unknown', 'adult', 1)` | Graceful fallback or error |
| Unknown age bucket | `('scientist', 'unknown', 1)` | Fallback to 'adult' |
| Invalid day | `('scientist', 'adult', 0)` | Fallback to day 1 |
| Day 366 | `('scientist', 'adult', 366)` | Fallback to day 365 or loop |
| Null persona | `(NULL, 'adult', 1)` | Default to 'scientist' |
| Null age | `('scientist', NULL, 1)` | Default to 'adult' |

---

## PART 3: CONTENT GENERATION INTEGRATION

### 3.1 Verify Prompts Include Backstory

When generating content, the system prompt should include:

```
✓ Genesis story for selected persona
✓ Teaching philosophy
✓ Transformation trigger
✓ Persona stats (curiosity, energy, warmth, precision)
✓ Age vocabulary level
✓ Permitted topics
✓ Forbidden topics
✓ Tone guidance
✓ Memory hook for specific day
✓ Emotional connection
✓ Core identity
```

**Test Method:** Capture a content generation prompt and verify all elements present.

### 3.2 Sample Integrated Prompt

For Day 47, Explorer, Adult:

```
You are Kelly, a 35-year-old teacher known as "The Explorer."

YOUR GENESIS:
At 22, I quit my job and bought a one-way ticket to Bangkok. Over the next 
3 years, I visited 47 countries with nothing but a backpack. I learned that 
every stranger has a story worth hearing, every food is worth trying once, 
and every wrong turn leads somewhere interesting. I came home not with 
souvenirs, but with a thousand ways to see the same world differently.

YOUR TEACHING PHILOSOPHY:
Learning is a journey, not a destination. I don't give you maps—I help you 
fall in love with getting lost. Wonder first, facts second, wisdom as the 
souvenir you bring home.

TODAY'S TOPIC: [Day 47 topic]

YOUR PERSONAL CONNECTION TO THIS TOPIC:
When I first discovered that leaves could feed you, I was three weeks into 
a solo trek in Borneo, out of food, out of options. A local grandmother 
showed me which plants were edible. That moment taught me: knowledge isn't 
just interesting, it's survival. Every lesson I teach could be the one that 
saves someone someday.

EMOTIONAL RESONANCE TO EVOKE: Wonder at nature's generosity

YOUR STATS (calibrate your delivery):
- Curiosity: 95 (lead with wonder)
- Energy: 85 (enthusiastic but not manic)
- Warmth: 80 (friendly, approachable)
- Precision: 60 (accurate but not clinical)

AGE CALIBRATION (Adult learner):
- Vocabulary: Full professional range
- Permitted: Work examples, parenting, finances, relationships, mortality
- Forbidden: None
- Tone: Peer-to-peer, respects their expertise

CORE IDENTITY:
You are one woman expressing 12 facets. When you teach as the Explorer, you 
are still Kelly—the same person who could have been the Scientist or the 
Storyteller. Your soul is constant; only your teaching mode changes.

Now write the Hook for Day 47...
```

---

## PART 4: OUTPUT VERIFICATION

### 4.1 Backstory Echoes Test

For each generated script, identify backstory echoes:

| Element | How It Appears | Present? |
|---------|----------------|----------|
| Genesis story | Reference to personal experience | ☐ |
| Teaching philosophy | Structure/approach reflects philosophy | ☐ |
| Memory hook | Personal connection to this topic | ☐ |
| Emotional connection | Intended feeling is evoked | ☐ |
| Stats influence | Delivery matches stat levels | ☐ |
| Age vocabulary | Language matches age bucket | ☐ |
| Permitted topics | Topics stay within bounds | ☐ |
| Forbidden topics | No violations | ☐ |

**Minimum:** 6/8 elements present

### 4.2 Persona Voice Comparison

Generate the same lesson (Day 47) as all 12 personas. Compare:

| Persona | Distinct Voice? | Genesis Echo? | Stats Reflected? |
|---------|-----------------|---------------|------------------|
| Scientist | ☐ | ☐ | ☐ |
| Explorer | ☐ | ☐ | ☐ |
| Rebel | ☐ | ☐ | ☐ |
| Architect | ☐ | ☐ | ☐ |
| Diplomat | ☐ | ☐ | ☐ |
| Empath | ☐ | ☐ | ☐ |
| MacGyver | ☐ | ☐ | ☐ |
| Mystic | ☐ | ☐ | ☐ |
| Provider | ☐ | ☐ | ☐ |
| Storyteller | ☐ | ☐ | ☐ |
| Strategist | ☐ | ☐ | ☐ |
| Survivor | ☐ | ☐ | ☐ |

**Test:** Could you identify which persona wrote each without being told?

### 4.3 Age Transformation Comparison

Generate the same lesson (Day 47, Explorer) for all 5 age buckets. Compare:

| Age Bucket | Different Voice? | Age-Appropriate? | Permissions Respected? |
|------------|------------------|------------------|------------------------|
| Kid | ☐ | ☐ | ☐ |
| Teen | ☐ | ☐ | ☐ |
| Adult | ☐ | ☐ | ☐ |
| Elder | ☐ | ☐ | ☐ |
| Super Elder | ☐ | ☐ | ☐ |

**Test:** Would you give the Kid version to an 8-year-old without editing?

---

## PART 5: MEMORY HOOK COVERAGE

### 5.1 Generate Remaining Memory Hooks

If `kelly_memory_hooks` has fewer than 365 entries:

```sql
-- Find missing days
SELECT d.day_number
FROM generate_series(1, 365) AS d(day_number)
LEFT JOIN kelly_memory_hooks kmh ON d.day_number = kmh.day_number
WHERE kmh.day_number IS NULL
ORDER BY d.day_number;
```

**Action:** Generate memory hooks for all missing days using this template:

```json
{
  "day_number": [N],
  "topic": "[From core_lessons]",
  "memory_hook": "[Kelly's personal experience with this topic]",
  "emotional_connection": "[The feeling this should evoke]"
}
```

### 5.2 Memory Hook Quality Check

For each memory hook, verify:

| Criteria | Pass | Fail |
|----------|------|------|
| Specific experience | "I remember when..." | Generic statement |
| Sensory detail | Sight, sound, smell, touch, taste | Abstract only |
| Emotional resonance | Feeling is clear | Emotionally flat |
| Topic connection | Clearly relates to day's topic | Tangential |
| Length appropriate | 1-3 sentences | Too long or too short |
| Voice is Kelly's | Sounds like her | Generic teacher voice |

### 5.3 Memory Hook Distribution

Verify memory hooks cover diverse experiences:

| Category | Count | Target |
|----------|-------|--------|
| Travel experiences | ___ | 60-80 |
| Childhood memories | ___ | 40-60 |
| Teaching moments | ___ | 50-70 |
| Relationships | ___ | 30-50 |
| Nature/outdoors | ___ | 40-60 |
| Urban/city | ___ | 20-40 |
| Scientific discovery | ___ | 30-50 |
| Creative/artistic | ___ | 20-40 |
| Practical/hands-on | ___ | 40-60 |
| Spiritual/reflective | ___ | 20-40 |

---

## PART 6: CONSISTENCY CHECKS

### 6.1 Cross-Reference Accuracy

Kelly's backstory must be internally consistent:

| Check | Method | Status |
|-------|--------|--------|
| Age consistency | Kelly is always ~35 in adult form | ☐ |
| Timeline coherence | Events don't contradict | ☐ |
| Geographic accuracy | Places mentioned are real | ☐ |
| Persona unity | All 12 feel like same person | ☐ |
| Biography alignment | Core bio matches all personas | ☐ |

### 6.2 Contradiction Detection

```sql
-- Example: Find memory hooks that contradict backstory
-- (This requires manual review, but SQL can flag candidates)

SELECT day_number, memory_hook
FROM kelly_memory_hooks
WHERE memory_hook ILIKE '%I never%'
   OR memory_hook ILIKE '%I don''t know how to%'
   OR memory_hook ILIKE '%I''ve never been%';
-- Review: Do these contradict any genesis stories?
```

### 6.3 The "Wikipedia Test"

If someone created a Wikipedia article for Kelly based on all tables, would it be:
- Internally consistent? ☐
- Believable as a real person? ☐
- Rich enough to feel real? ☐
- Sparse enough to leave room for mystery? ☐

---

## PART 7: RUNTIME INTEGRATION

### 7.1 API Endpoint Verification

If there's an API that generates content:

```bash
# Test the content generation endpoint
curl -X POST https://api.curiouskelly.com/generate \
  -H "Content-Type: application/json" \
  -d '{
    "day_number": 47,
    "persona": "explorer",
    "age_bucket": "adult",
    "phase": "Hook"
  }'
```

**Verify response includes backstory-influenced content.**

### 7.2 Caching Considerations

| Data | Cache Duration | Invalidation Trigger |
|------|----------------|---------------------|
| Backstory | 24 hours | Manual update |
| Age permissions | 24 hours | Manual update |
| Memory hooks | 24 hours | Manual update |
| Core biography | 7 days | Manual update |
| Generated content | 1 hour | User feedback |

### 7.3 Fallback Chain

If database is unavailable:

```
1. Try get_kelly_prompt_context() → Success: Use full context
2. Fail → Try cached context from last successful call
3. Fail → Use embedded fallback constants
4. Fail → Generate with minimal persona hint only
```

---

## PART 8: QUALITY GATES

### 8.1 Pre-Generation Check

Before generating any content, verify:

```javascript
async function preGenerationCheck(personaId, ageBucket, dayNumber) {
  const checks = {
    backstoryExists: await checkBackstory(personaId),
    agePermissionsExist: await checkAgePermissions(ageBucket),
    memoryHookExists: await checkMemoryHook(dayNumber),
    coreIdentityExists: await checkCoreIdentity()
  };
  
  const passed = Object.values(checks).every(v => v === true);
  
  if (!passed) {
    console.warn('Missing backstory data:', checks);
    // Proceed with fallbacks, but flag for review
  }
  
  return passed;
}
```

### 8.2 Post-Generation Check

After generating content, verify backstory integration:

```javascript
function postGenerationCheck(generatedContent, context) {
  const checks = {
    hasPersonaVoice: detectPersonaVoice(generatedContent, context.persona),
    hasMemoryEcho: detectMemoryHook(generatedContent, context.memoryHook),
    respectsAgeRules: checkAgeCompliance(generatedContent, context.agePermissions),
    maintainsIdentity: checkIdentityConsistency(generatedContent, context.coreIdentity)
  };
  
  return checks;
}
```

### 8.3 Human Review Queue

Flag content for human review if:

| Condition | Action |
|-----------|--------|
| Backstory data missing | Review before publish |
| Age permission violation detected | Block until fixed |
| Persona voice score < 3 | Regenerate or edit |
| Memory hook not evident | Add manually |
| Inconsistency with core identity | Rewrite |

---

## PART 9: MONITORING & ALERTS

### 9.1 Data Integrity Monitoring

```sql
-- Daily integrity check
SELECT 
  (SELECT COUNT(*) FROM kelly_backstory) as backstory_count,
  (SELECT COUNT(*) FROM kelly_age_permissions) as age_permissions_count,
  (SELECT COUNT(*) FROM kelly_memory_hooks WHERE memory_hook IS NOT NULL) as memory_hooks_populated,
  (SELECT COUNT(*) FROM kelly_core_biography) as core_biography_count;
  
-- Alert if:
-- backstory_count != 12
-- age_permissions_count != 5
-- memory_hooks_populated != 365
-- core_biography_count != 1
```

### 9.2 Function Health Check

```sql
-- Hourly function test
SELECT 
  CASE 
    WHEN get_kelly_prompt_context('scientist', 'adult', 1) IS NOT NULL 
    THEN 'HEALTHY' 
    ELSE 'FAILED' 
  END as function_status;
```

### 9.3 Content Quality Alerts

| Metric | Alert Threshold |
|--------|-----------------|
| Persona voice score | < 3.0 average over 10 lessons |
| Age compliance violations | > 0 in production |
| Missing memory hooks | Any day without hook |
| Backstory mismatch | Any inconsistency detected |

---

## PART 10: SIGN-OFF

### Backstory Integration Checklist

| Item | Status |
|------|--------|
| All 4 tables created | ☐ |
| kelly_backstory has 12 personas | ☐ |
| kelly_age_permissions has 5 buckets | ☐ |
| kelly_memory_hooks has 365 entries | ☐ |
| kelly_core_biography has 1 entry | ☐ |
| get_kelly_prompt_context() works | ☐ |
| Content generation uses context | ☐ |
| Persona voice is distinct | ☐ |
| Age transformation is evident | ☐ |
| Memory hooks appear in content | ☐ |
| Core identity is consistent | ☐ |
| Fallbacks work when DB unavailable | ☐ |
| Monitoring is in place | ☐ |

### The Soul Test

> **"When I read Kelly's content, do I feel like I'm learning from a person with a history, a perspective, and a genuine care for my growth—or from a content generation system?"**

If the answer is "system," the backstory isn't integrated deeply enough.

---

*"The 60 Kellys are now one woman with a soul."*

*December 2024*
